﻿========================================
  ADATT - Active Directory Automation Tool
  Version 1.5.0
========================================

WELCOME!

Thank you for purchasing ADATT! This tool helps you automate Active Directory tasks.

*** FIRST TIME SETUP (REQUIRED): ***

Before running ADATT for the first time:

1. Right-click on PowerShell and select "Run as Administrator"
2. Run this command to allow PowerShell scripts:
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
3. Type "Y" and press Enter to confirm

This is a one-time setup required by Windows security.

QUICK START:

1. Extract all files to a folder (e.g., C:\ADATT)
2. Complete "FIRST TIME SETUP" above (if you haven't already)
3. Right-click ADATT.ps1 and select "Run with PowerShell"
4. Click "Activate License" when prompted
5. Enter your license key from your purchase email
6. Start using ADATT!

SYSTEM REQUIREMENTS:

- Windows 10/11 or Windows Server 2016+
- PowerShell 5.1 or later
- Active Directory PowerShell module
- Internet connection (for license activation)

LICENSE ACTIVATION:

Your license key was sent to your email after purchase.
Format: XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX

License Types:
- Solo Admin: 1 device
- Team: 5 devices
- Business: 20 devices

You can activate ADATT on multiple devices based on your license type.

TRIAL MODE:

If you don't activate immediately, ADATT runs in trial mode for 30 days.
All features are available during the trial period.

SUPPORT:

Email: support@unifosec.com
Documentation: https://adatt.lemonsqueezy.com/docs
FAQ: https://adatt.lemonsqueezy.com/faq

TROUBLESHOOTING:

*** ERROR: "Cannot be loaded because running scripts is disabled" ***
This is the most common error on fresh Windows installations.

SOLUTION:
1. Open PowerShell as Administrator
2. Run: Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
3. Type "Y" to confirm
4. Close PowerShell and try running ADATT again

Why? Windows blocks downloaded scripts by default for security.
This one-time command allows trusted scripts to run.

---

If you encounter other issues:
1. Run PowerShell as Administrator
2. Check your internet connection
3. Ensure Active Directory module is installed
4. Contact support with error details

Thank you for choosing ADATT!

(c) 2025 UNIFOSEC. All rights reserved.
