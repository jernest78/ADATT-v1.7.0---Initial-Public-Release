﻿<#
  ADATT ? Professional GUI Template (UX-Focused)
  ------------------------------------------------
  ? High-DPI WinForms shell + gradient/image background
  ? Terminate, Bulk Offboarding (with validation/preview), Reset MFA, Activate License
  ? DataGridView preview & results
  ? Hooks (Invoke-*) to integrate your existing AD/EXO/Graph/LemonSqueezy logic
  Author: Jose Ernest (c) 2025
#>

#region ----- Config -----
$ErrorActionPreference = 'Stop'

# Version
$Script:ADATT_Version = "1.5.0"

# Brand / links / assets
$BrandName           = 'ADATT'
$BrandSub            = 'Automated Employee Offboarding Tool for Hybrid Environments'
$BuyUrl              = 'https://adatt.lemonsqueezy.com' # your Buy/Checkout page
$SupportEmail        = 'adatt@unifosec.com'  # Support contact email
$BackgroundImagePath = Join-Path $PSScriptRoot 'bg\adatt_blue_security_1920x1080.png' # optional, will fall back to gradient

# Bulk constraints
$MinBulk = 2
$MaxBulk = 100  # For larger batches, split into multiple files

# Operational paths
$ReportFolder = 'C:\Temp\ADATT\Reports'
$SingleTerminationReport = 'UserTermination_Report.csv'
$BulkTerminationReport = 'BulkTermination_Report.csv'

# License configuration
$LemonSqueezyActivationUrl = 'https://adatt-activator.adatt.workers.dev/'
$LicenseKeyMinLength = 10
$ValidationTimeoutSeconds = 15

# Performance & Caching
$MailboxCacheExpiryMinutes = 5
$LicenseRevalidationDays = 7
$MaxHardwareChanges = 2

# Grid column indices (for maintainability)
$GridColumns = @{
    SamAccountName = 0
    DisplayName = 1
    UserPrincipalName = 2
    Status = 3
}

# Logging
$LogPath = 'C:\Temp\ADATT\adatt-ui.log'
$logFilePath = $LogPath  # Compatibility alias for ADATT.ps1 code
$logDir  = Split-Path $LogPath -Parent

# Define Write-Log function BEFORE using it
function Write-Log { param([string]$Msg,[string]$Level='INFO')
  $line = '{0:u} [{1}] {2}' -f (Get-Date),$Level,$Msg
  Add-Content -Path $LogPath -Value $line
}

# Create log directory if needed
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }

# Ensure report folder exists
if (-not (Test-Path $ReportFolder)) {
    try {
        New-Item -ItemType Directory -Path $ReportFolder -Force | Out-Null
        Write-Log "Report folder created: $ReportFolder"
    } catch {
        Write-Log "Failed to create report folder: $_" 'WARN'
    }
}

# Validate background image
if (-not (Test-Path $BackgroundImagePath)) {
    Write-Log "Background image not found: $BackgroundImagePath (will use gradient fallback)" 'INFO'
}

function Write-StructuredLog {
    param(
        [Parameter(Mandatory)]
        [string]$Message,
        
        [ValidateSet('INFO','WARN','ERROR','DEBUG')]
        [string]$Level = 'INFO',
        
        [hashtable]$Data = @{},
        
        [string]$Category = 'General'
    )
    
    try {
        $entry = @{
            Timestamp = (Get-Date).ToString('o')
            Level = $Level
            Category = $Category
            Message = $Message
            User = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        }
        
        # Add custom data fields
        if ($Data.Count -gt 0) {
            $entry.Data = $Data
        }
        
        $jsonEntry = $entry | ConvertTo-Json -Compress
        Add-Content -Path $LogPath -Value $jsonEntry -ErrorAction SilentlyContinue
    } catch {
        # Fallback to simple logging if structured logging fails
        Write-Log -Msg $Message -Level $Level
    }
}

Write-Log "ADATT UI starting"

# Start transcript for audit compliance
$transcriptPath = "C:\Temp\ADATT\Transcripts\ADATT-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
$transcriptDir = Split-Path $transcriptPath -Parent
if (-not (Test-Path $transcriptDir)) { 
    try {
        New-Item -ItemType Directory -Path $transcriptDir -Force | Out-Null 
        Write-Log "Transcript directory created: $transcriptDir"
    } catch {
        Write-Log "Failed to create transcript directory: $_" 'WARN'
    }
}

try {
    Start-Transcript -Path $transcriptPath -Force -ErrorAction Stop
    Write-Log "Transcript started: $transcriptPath"
    Write-StructuredLog -Message "PowerShell transcript logging started" -Level 'INFO' -Category 'Audit' -Data @{Path=$transcriptPath}
} catch {
    Write-Log "Failed to start transcript: $_" 'WARN'
    Write-StructuredLog -Message "Transcript logging unavailable" -Level 'WARN' -Category 'Audit' -Data @{Error=$_.Exception.Message}
}

#endregion

#region ----- Prerequisites Check -----
function Test-Prerequisites {
    Write-Host "Checking prerequisites..." -ForegroundColor Yellow
    
    $missing = @()
    $warnings = @()
    
    # 1. Check PowerShell Execution Policy (check effective policy, not just CurrentUser)
    $effectivePolicy = Get-ExecutionPolicy
    $currentUserPolicy = Get-ExecutionPolicy -Scope CurrentUser
    
    # Only fail if BOTH effective AND CurrentUser are restricted
    # This allows Bypass from command line or Process scope to work
    if ($effectivePolicy -eq 'Restricted' -and $currentUserPolicy -eq 'Restricted') {
        $missing += "PowerShell Execution Policy needs to be set to RemoteSigned or Unrestricted"
    } elseif ($currentUserPolicy -eq 'Undefined' -and $effectivePolicy -eq 'Restricted') {
        $missing += "PowerShell Execution Policy needs to be set to RemoteSigned or Unrestricted"
    }
    
    # 2. Check for RSAT-AD-PowerShell module
    $adModule = Get-Module -ListAvailable -Name ActiveDirectory -ErrorAction SilentlyContinue
    if (-not $adModule) {
        $missing += "Active Directory PowerShell Module (RSAT) is not installed"
    }
    
    # 3. Check if running on Server or Workstation (for RSAT guidance)
    $osInfo = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction SilentlyContinue
    $isServer = $osInfo.ProductType -ne 1  # 1 = Workstation, 2 = Domain Controller, 3 = Server
    
    # Additional checks
    # 4. Check PowerShell version
    if ($PSVersionTable.PSVersion.Major -lt 5) {
        $missing += "PowerShell 5.1 or later is required (Current: $($PSVersionTable.PSVersion))"
    }
    
    # 5. Check if running as Administrator (warning only)
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) {
        $warnings += "ADATT is not running as Administrator. Some features may not work correctly."
    }
    
    # If there are missing prerequisites, show detailed installation guide
    if ($missing.Count -gt 0) {
        Add-Type -AssemblyName System.Windows.Forms
        
        # Build the message with installation instructions using string builder
        $nl = [Environment]::NewLine
        $message = "ADATT cannot start. The following prerequisites are missing:" + $nl + $nl
        
        foreach ($item in $missing) {
            $message += "X $item" + $nl
        }
        
        $message += $nl + ("=" * 60) + $nl
        $message += "INSTALLATION INSTRUCTIONS:" + $nl
        $message += ("=" * 60) + $nl + $nl
        
        # PowerShell Execution Policy fix
        if ($missing -match "Execution Policy") {
            $message += "1. FIX EXECUTION POLICY:" + $nl
            $message += "   - Close ADATT" + $nl
            $message += "   - Right-click PowerShell and 'Run as Administrator'" + $nl
            $message += "   - Run this command:" + $nl
            $message += "     Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser" + $nl
            $message += "   - Type 'Y' and press Enter" + $nl
            $message += "   - Restart ADATT" + $nl + $nl
        }
        
        # RSAT installation instructions
        if ($missing -match "Active Directory|RSAT") {
            $message += "2. INSTALL ACTIVE DIRECTORY MODULE:" + $nl + $nl
            
            if ($isServer) {
                # Server installation
                $message += "   FOR WINDOWS SERVER:" + $nl
                $message += "   - Open PowerShell as Administrator" + $nl
                $message += "   - Run this command:" + $nl
                $message += "     Install-WindowsFeature RSAT-AD-PowerShell" + $nl
                $message += "   - Wait for installation to complete" + $nl
                $message += "   - Restart ADATT" + $nl + $nl
            } else {
                # Workstation installation (Windows 10/11)
                $message += "   FOR WINDOWS 10/11:" + $nl + $nl
                $message += "   Option A - Settings (Recommended):" + $nl
                $message += "   - Open Settings > Apps > Optional Features" + $nl
                $message += "   - Click 'Add a feature'" + $nl
                $message += "   - Search for 'RSAT: Active Directory'" + $nl
                $message += "   - Select 'RSAT: Active Directory Domain Services and Lightweight Directory Services Tools'" + $nl
                $message += "   - Click 'Install'" + $nl
                $message += "   - Wait for installation (may take several minutes)" + $nl
                $message += "   - Restart ADATT" + $nl + $nl
                
                $message += "   Option B - PowerShell:" + $nl
                $message += "   - Open PowerShell as Administrator" + $nl
                $message += "   - Run this command:" + $nl
                $message += "     Get-WindowsCapability -Name RSAT.ActiveDirectory* -Online | Add-WindowsCapability -Online" + $nl
                $message += "   - Wait for installation to complete" + $nl
                $message += "   - Restart ADATT" + $nl + $nl
            }
        }
        
        # PowerShell version
        if ($missing -match "PowerShell.*required") {
            $message += "3. UPDATE POWERSHELL:" + $nl
            $message += "   - Download PowerShell 7 from:" + $nl
            $message += "     https://aka.ms/powershell" + $nl
            $message += "   - Install and restart ADATT" + $nl + $nl
        }
        
        $message += ("=" * 60) + $nl
        $message += "Need help? Contact: support@unifosec.com" + $nl
        $message += "Documentation: https://adatt.lemonsqueezy.com/docs"
        
        # Show the message box
        [System.Windows.Forms.MessageBox]::Show(
            $message,
            "ADATT - Prerequisites Required",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        
        Write-Host ""
        Write-Host "Prerequisite check failed. Please install the required components." -ForegroundColor Red
        Write-Host "See the message box for detailed instructions." -ForegroundColor Yellow
        Write-Host ""
        
        return $false
    }
    
    # Show warnings if any (but don't block startup)
    if ($warnings.Count -gt 0) {
        Write-Host "`nWARNINGS:" -ForegroundColor Yellow
        foreach ($warning in $warnings) {
            Write-Host "  - $warning" -ForegroundColor Yellow
        }
        Write-Host ""
        
        # If not running as administrator, ask if they want to restart as admin
        if ($warnings -match "Administrator") {
            Add-Type -AssemblyName System.Windows.Forms
            
            $nl = [Environment]::NewLine
            $message = "ADATT is not running with Administrator privileges." + $nl + $nl
            $message += "Some features may not work correctly:" + $nl
            $message += "- Disabling user accounts" + $nl
            $message += "- Modifying group memberships" + $nl
            $message += "- Resetting MFA settings" + $nl
            $message += "- Advanced Active Directory operations" + $nl + $nl
            $message += "Do you want to restart ADATT as Administrator?"
            
            $result = [System.Windows.Forms.MessageBox]::Show(
                $message,
                "Administrator Privileges Required",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            
            if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
                # Restart as Administrator
                Write-Host "Restarting ADATT as Administrator..." -ForegroundColor Yellow
                try {
                    $scriptPath = $PSCommandPath
                    Start-Process powershell.exe -ArgumentList "-ExecutionPolicy Bypass -File `"$scriptPath`"" -Verb RunAs
                    exit 0
                } catch {
                    Write-Host "Failed to restart as Administrator: $_" -ForegroundColor Red
                    Write-Host "Please manually right-click ADATT-UX.ps1 and select 'Run as Administrator'" -ForegroundColor Yellow
                    Write-Host "Press any key to exit..." -ForegroundColor Gray
                    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                    exit 1
                }
            }
            
            Write-Host "User chose to continue without Administrator privileges." -ForegroundColor Yellow
        }
    }
    
    Write-Host "All prerequisites met!" -ForegroundColor Green
    return $true
}

# Run prerequisite check
if (-not (Test-Prerequisites)) {
    Write-Host "Press any key to exit..." -ForegroundColor Gray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

#endregion

#region ----- Module Installation & Import -----

# Ensure Active Directory tools (RSAT) and import module
if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
    try {
        Write-Log "ActiveDirectory module not found; attempting RSAT install"
        Add-WindowsCapability -Online -Name Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0 -ErrorAction Stop | Out-Null
    } catch {
        Write-Log "WARN: RSAT install failed or not required: $_"
    }
}
try {
    Import-Module ActiveDirectory -ErrorAction Stop
    Write-Log "ActiveDirectory module imported"
} catch {
    Write-Log "ERROR: Failed to import ActiveDirectory: $_"
}

# Module install helper (non-fatal)
function Install-ModuleIfMissing {
    param($Name)
    if (-not (Get-Module -ListAvailable -Name $Name)) {
        Write-Log "Module $Name not found. Attempting Install-Module (CurrentUser)."
        try {
            Install-Module -Name $Name -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
            Write-Log "Installed $Name"
        } catch {
            Write-Log "WARN: Failed to install $Name : $_"
            return $false
        }
    } else {
        Write-Log "Module $Name is available"
    }
    return $true
}

# Microsoft Graph installation and connection
$script:GraphAvailable = $false
$script:GraphScopes = @('User.ReadWrite.All','Directory.Read.All','Group.ReadWrite.All','Device.ReadWrite.All','UserAuthenticationMethod.ReadWrite.All','Organization.ReadWrite.All','Mail.Send','MailboxSettings.ReadWrite')
# Check if module is available and attempt connection
if (Install-ModuleIfMissing -Name 'Microsoft.Graph') {
    Write-Host "Connecting to Microsoft Graph..." -ForegroundColor Yellow
    try {
        Connect-MgGraph -Scopes $script:GraphScopes -ErrorAction Stop -NoWelcome
        Write-Log "Connected to Microsoft Graph successfully"
        Write-Host "Connected to Microsoft Graph" -ForegroundColor Green
        $script:GraphAvailable = $true
    } catch {
        Write-Log "WARN: Connect-MgGraph failed or was cancelled: $_"
        Write-Host "Warning: Could not connect to Microsoft Graph. Cloud operations will require manual connection." -ForegroundColor Yellow
    }
}

function Connect-GraphIfNeeded {
    param([string[]]$RequiredScopes)
    try {
        if (-not (Get-Command -Name Get-MgContext -ErrorAction SilentlyContinue)) {
            Connect-MgGraph -Scopes $RequiredScopes -ErrorAction Stop | Out-Null
            $script:GraphAvailable = $true
            return $true
        }
        $ctx = Get-MgContext
        $haveScopes = $false
        if ($ctx -and $ctx.Account -and $ctx.Scopes) {
            $haveScopes = @($RequiredScopes | Where-Object { $ctx.Scopes -contains $_ }).Count -eq $RequiredScopes.Count
        }
        if (-not $ctx -or -not $ctx.Account -or -not $haveScopes) {
            Connect-MgGraph -Scopes $RequiredScopes -ErrorAction Stop | Out-Null
        }
        $script:GraphAvailable = $true
        return $true
    } catch {
        Write-Log "WARN: Connect-GraphIfNeeded failed: $_"
        return $false
    }
}

# ExchangeOnlineManagement installation and connection
$script:EXOAvailable = $false
if (Install-ModuleIfMissing -Name 'ExchangeOnlineManagement') {
    try {
        Import-Module ExchangeOnlineManagement -ErrorAction Stop
        Write-Host "Connecting to Exchange Online..." -ForegroundColor Yellow
        try {
            Connect-ExchangeOnline -ShowBanner:$false -ErrorAction Stop
            Write-Log "Connected to Exchange Online successfully"
            Write-Host "Connected to Exchange Online" -ForegroundColor Green
            $script:EXOAvailable = $true
        } catch {
            Write-Log "WARN: Connect-ExchangeOnline failed or was cancelled: $_"
            Write-Host "Warning: Could not connect to Exchange Online. Mailbox operations will require manual connection." -ForegroundColor Yellow
        }
    } catch {
        Write-Log "WARN: Failed to import ExchangeOnlineManagement: $_"
    }
}

# Helper function to connect to Exchange Online on demand
function Connect-EXOIfNeeded {
    try {
        $ok = $false
        if (Get-Command -Name Get-ConnectionInformation -ErrorAction SilentlyContinue) {
            $info = Get-ConnectionInformation -ErrorAction SilentlyContinue
            if ($info -and $info.TokenStatus -eq 'Active') { $ok = $true }
        }
        if (-not $ok) {
            Connect-ExchangeOnline -ShowBanner:$false -ErrorAction Stop | Out-Null
        }
        $script:EXOAvailable = $true
        return $true
    } catch {
        Write-Log "WARN: Connect-EXOIfNeeded failed: $_"
        return $false
    }
}

#endregion

#region ----- Graph API Retry Logic -----
function Invoke-GraphWithRetry {
    <#
    .SYNOPSIS
    Executes a Graph API command with retry logic and exponential backoff
    
    .PARAMETER ScriptBlock
    The command to execute (Graph API call)
    
    .PARAMETER MaxRetries
    Maximum number of retry attempts (default: 3)
    
    .PARAMETER InitialDelaySeconds
    Initial delay before first retry in seconds (default: 2)
    #>
    param(
        [Parameter(Mandatory)]
        [scriptblock]$ScriptBlock,
        
        [int]$MaxRetries = 3,
        
        [int]$InitialDelaySeconds = 2
    )
    
    $attempt = 0
    $delay = $InitialDelaySeconds
    
    while ($attempt -le $MaxRetries) {
        try {
            return & $ScriptBlock
        } catch {
            $attempt++
            $errorMessage = $_.Exception.Message
            
            # Check if it's a throttling error (429 or rate limit)
            $isThrottling = $errorMessage -match '429|throttl|rate limit|too many requests'
            
            if ($attempt -le $MaxRetries -and $isThrottling) {
                Write-Log "WARN: Graph API throttled (attempt $attempt/$MaxRetries). Retrying in $delay seconds..."
                Start-Sleep -Seconds $delay
                $delay = $delay * 2  # Exponential backoff
            } else {
                # Not a throttling error or max retries reached
                throw
            }
        }
    }
}
#endregion

#region ----- Licensing System -----
$licenseDir = Join-Path $env:APPDATA 'ADATT'
$script:LICENSE_FILE = Join-Path $licenseDir 'license.json'
$licenseFile = $script:LICENSE_FILE
$licenseLogFile = Join-Path $licenseDir 'license.log'
if (-not (Test-Path $licenseDir)) { New-Item -Path $licenseDir -ItemType Directory | Out-Null }

# Additional license settings
$script:OFFLINE_GRACE_DAYS = 30
$script:TRIAL_DAYS = 14

function Write-LicenseLog {
    param([string]$Message)
    try {
        $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
        $logEntry = "[$timestamp] $Message"
        Add-Content -Path $licenseLogFile -Value $logEntry -ErrorAction SilentlyContinue
    } catch {}
}

function Get-MachineId {
    try {
        $uuid = try { (Get-CimInstance -ClassName Win32_ComputerSystemProduct -ErrorAction Stop).UUID } catch { $null }
        if (-not $uuid) { $uuid = $env:COMPUTERNAME }
        $sid = try { ([System.Security.Principal.WindowsIdentity]::GetCurrent()).User.Value } catch { $env:USERNAME }
    } catch {
        $uuid = $env:COMPUTERNAME; $sid = $env:USERNAME
    }
    $raw = @($uuid, $sid) -join '|'
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($raw)
    $hash = $sha.ComputeHash($bytes)
    return [BitConverter]::ToString($hash).Replace('-','')
}

function Get-HardwareFingerprint {
    try {
        $cpu = try { (Get-CimInstance -ClassName Win32_Processor -ErrorAction Stop | Select-Object -First 1).ProcessorId } catch { "UNKNOWN" }
        $bios = try { (Get-CimInstance -ClassName Win32_BIOS -ErrorAction Stop).SerialNumber } catch { "UNKNOWN" }
        $mb = try { (Get-CimInstance -ClassName Win32_BaseBoard -ErrorAction Stop).SerialNumber } catch { "UNKNOWN" }
        $mac = try { (Get-NetAdapter -Physical -ErrorAction Stop | Where-Object Status -eq 'Up' | Select-Object -First 1).MacAddress } catch { "UNKNOWN" }
        
        $combined = @($cpu, $bios, $mb, $mac) -join '|'
        $sha = [System.Security.Cryptography.SHA256]::Create()
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($combined)
        $hash = $sha.ComputeHash($bytes)
        return [BitConverter]::ToString($hash).Replace('-','')
    } catch {
        Write-LicenseLog "WARNING: Hardware fingerprint generation failed: $($_.Exception.Message)"
        return "FALLBACK_" + (Get-MachineId)
    }
}

function Get-TrialStartHash {
    param([datetime]$TrialStart, [string]$MachineId)
    $combined = @($TrialStart.ToString('o'), $MachineId, 'ADATT_SALT_2025') -join '|'
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($combined)
    $hash = $sha.ComputeHash($bytes)
    return [BitConverter]::ToString($hash).Replace('-','')
}

function Set-TrialStartMultiLocation {
    param([datetime]$TrialStart, [string]$MachineId)
    try {
        $trialHash = Get-TrialStartHash -TrialStart $TrialStart -MachineId $MachineId
        $trialData = @{
            Start = $TrialStart.ToString('o')
            Hash = $trialHash
            MachineId = $MachineId
        } | ConvertTo-Json
        $trialFile = Join-Path $licenseDir 'trial.dat'
        Set-Content -Path $trialFile -Value $trialData -ErrorAction SilentlyContinue
        
        try {
            $regPath = "HKCU:\Software\ADATT"
            if (-not (Test-Path $regPath)) { New-Item -Path $regPath -Force | Out-Null }
            Set-ItemProperty -Path $regPath -Name "TrialStart" -Value $TrialStart.ToString('o') -ErrorAction SilentlyContinue
            Set-ItemProperty -Path $regPath -Name "TrialHash" -Value $trialHash -ErrorAction SilentlyContinue
        } catch {}
        
        Write-LicenseLog "Trial start recorded: $($TrialStart.ToString('yyyy-MM-dd'))"
    } catch {
        Write-LicenseLog "ERROR: Failed to set trial start: $($_.Exception.Message)"
    }
}

function Get-TrialStartMultiLocation {
    param([string]$MachineId)
    $locations = @()
    
    try {
        $trialFile = Join-Path $licenseDir 'trial.dat'
        if (Test-Path $trialFile) {
            $data = Get-Content $trialFile -Raw | ConvertFrom-Json
            $locations += @{
                Source = "APPDATA"
                Date = [datetime]$data.Start
                Hash = $data.Hash
            }
        }
    } catch {}
    
    try {
        $regPath = "HKCU:\Software\ADATT"
        if (Test-Path $regPath) {
            $startVal = Get-ItemProperty -Path $regPath -Name "TrialStart" -ErrorAction SilentlyContinue
            $hashVal = Get-ItemProperty -Path $regPath -Name "TrialHash" -ErrorAction SilentlyContinue
            if ($startVal -and $hashVal) {
                $locations += @{
                    Source = "Registry"
                    Date = [datetime]$startVal.TrialStart
                    Hash = $hashVal.TrialHash
                }
            }
        }
    } catch {}
    
    if ($locations.Count -eq 0) { return $null }
    
    $firstDate = $locations[0].Date
    $validHash = $false
    
    foreach ($loc in $locations) {
        $expectedHash = Get-TrialStartHash -TrialStart $loc.Date -MachineId $MachineId
        if ($loc.Hash -eq $expectedHash) {
            $validHash = $true
        }
    }
    
    if (-not $validHash) {
        Write-LicenseLog "ERROR: Trial tampering detected"
        return $null
    }
    
    return $firstDate
}

function Test-HardwareChange {
    param($License)
    if (-not $License.hardwareFingerprint) { return $false }
    $currentFingerprint = Get-HardwareFingerprint
    if ($License.hardwareFingerprint -eq $currentFingerprint) { return $false }
    if (-not $License.hardwareChangeCount) { $License.hardwareChangeCount = 0 }
    Write-LicenseLog "Hardware change detected"
    return $true
}

function Set-LicenseFile($obj) {
    $json = $obj | ConvertTo-Json -Depth 5 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    try {
        $prot = [System.Security.Cryptography.ProtectedData]::Protect($bytes,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        $b64  = [Convert]::ToBase64String($prot)
        Set-Content -Path $licenseFile -Value $b64 -Encoding ASCII
    } catch {
        Set-Content -Path $licenseFile -Value $json
    }
}

function Get-LicenseFile {
    if (Test-Path $licenseFile) {
        try {
            $raw = (Get-Content $licenseFile -Raw)
            try {
                $buf = [Convert]::FromBase64String($raw)
                $plain = [System.Security.Cryptography.ProtectedData]::Unprotect($buf,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser)
                $txt = [System.Text.Encoding]::UTF8.GetString($plain)
                return $txt | ConvertFrom-Json
            } catch {
                return $raw | ConvertFrom-Json
            }
        } catch { return $null }
    }
    return $null
}

function Invoke-LicenseValidation {
    param([string]$LicenseKey, [string]$MachineId, [string]$HardwareFingerprint)
    $body = @{ 
        licenseKey = $LicenseKey
        machineId = $MachineId
        hardwareFingerprint = $HardwareFingerprint
        version = "1.4"
    } | ConvertTo-Json
    
    try {
        Write-LicenseLog "Validating license with server..."
        # Hash license key for secure logging
        $keyHash = [System.Security.Cryptography.SHA256]::Create().ComputeHash([System.Text.Encoding]::UTF8.GetBytes($LicenseKey))
        $keyHashStr = [BitConverter]::ToString($keyHash).Replace('-','').Substring(0,16)
        Write-LicenseLog "License Key Hash: $keyHashStr"
        Write-LicenseLog "Machine ID: $($MachineId.Substring(0,[Math]::Min(8,$MachineId.Length)))..."
        $resp = Invoke-RestMethod -Uri $LemonSqueezyActivationUrl -Method Post -Body $body -ContentType 'application/json' -TimeoutSec $ValidationTimeoutSeconds
        Write-LicenseLog "Validation response: Valid=$($resp.valid), Status=$($resp.status), Message=$($resp.message)"
        if ($resp.activationCount -ne $null) {
            Write-LicenseLog "Activations: $($resp.activationCount)/$($resp.maxActivations)"
        }
        return $resp
    } catch {
        Write-LicenseLog "ERROR: License validation failed: $($_.Exception.Message)"
        if ($_.Exception.Response) {
            Write-LicenseLog "HTTP Status: $($_.Exception.Response.StatusCode)"
        }
        return $null
    }
}

#endregion

#region ----- Trial/License Validation (Run Before UI) -----
Write-LicenseLog "=== ADATT Starting - License Check ==="

$license = Get-LicenseFile
$now = Get-Date
$machineId = Get-MachineId
$hardwareFingerprint = Get-HardwareFingerprint

if (-not $license) {
    # First run: start trial with tamper-proof storage
    Write-LicenseLog "First run detected - starting trial"
    $license = @{ 
        trialStart = $now
        licensed = $false
        machineId = $machineId
        hardwareFingerprint = $hardwareFingerprint
        firstRun = $true
    }
    Set-TrialStartMultiLocation -TrialStart $now -MachineId $machineId
    Set-LicenseFile $license
}

# Validate trial start hasn't been tampered with (skip on first run)
if (-not $license.licensed -and -not $license.firstRun) {
    $storedTrialStart = Get-TrialStartMultiLocation -MachineId $machineId
    if ($null -eq $storedTrialStart) {
        Write-LicenseLog "WARNING: Trial data not found - attempting recovery"
        if ($license.trialStart) {
            $recoveredStart = [datetime]$license.trialStart
            Write-LicenseLog "Recovering trial start from license file: $($recoveredStart.ToString('yyyy-MM-dd'))"
            Set-TrialStartMultiLocation -TrialStart $recoveredStart -MachineId $machineId
            $storedTrialStart = $recoveredStart
        } else {
            Write-LicenseLog "ERROR: Trial data corrupted"
            Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
            [System.Windows.Forms.MessageBox]::Show(
                "Trial validation failed. The trial data appears to be corrupted.`n`nPlease contact support or purchase a license.",
                "Trial Validation Error",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            )
            exit 1
        }
    }
    
    # Check for time manipulation (allow 24-hour tolerance for clock differences between computers)
    $timeDifference = ($storedTrialStart - $now).TotalHours
    if ($timeDifference -gt 24) {
        Write-LicenseLog "ERROR: Time manipulation detected - trial start is $([Math]::Round($timeDifference, 1)) hours in the future"
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
        [System.Windows.Forms.MessageBox]::Show(
            "System time validation failed. Please ensure your system clock is set correctly.`n`nTrial start date is $([Math]::Round($timeDifference, 1)) hours ahead of current system time.",
            "Time Validation Error",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        )
        exit 1
    } elseif ($timeDifference -gt 0) {
        Write-LicenseLog "WARNING: Minor clock difference detected - trial start is $([Math]::Round($timeDifference, 1)) hours in the future (within tolerance)"
    }
    
    # Update license with validated trial start
    $licenseHash = @{}
    $license.PSObject.Properties | ForEach-Object { $licenseHash[$_.Name] = $_.Value }
    $licenseHash.trialStart = $storedTrialStart
    $license = [PSCustomObject]$licenseHash
    Set-LicenseFile $license
} elseif (-not $license.licensed -and $license.firstRun) {
    # First run - clear the flag
    Write-LicenseLog "First run completed - clearing flag"
    $licenseHash = @{}
    $license.PSObject.Properties | ForEach-Object { $licenseHash[$_.Name] = $_.Value }
    $licenseHash.firstRun = $false
    $license = [PSCustomObject]$licenseHash
    Set-LicenseFile $license
}

if ($license.licensed) {
    # Licensed mode - check revalidation
    Write-LicenseLog "Licensed mode - checking validation status"
    
    # Check hardware changes
    if (Test-HardwareChange -License $license) {
        $licenseHash = @{}
        $license.PSObject.Properties | ForEach-Object { $licenseHash[$_.Name] = $_.Value }
        if (-not $licenseHash.hardwareChangeCount) { $licenseHash.hardwareChangeCount = 0 }
        $licenseHash.hardwareChangeCount++
        
        if ($licenseHash.hardwareChangeCount -gt $MaxHardwareChanges) {
            Write-LicenseLog "ERROR: Too many hardware changes - reactivation required"
            Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
            [System.Windows.Forms.MessageBox]::Show(
                "Significant hardware changes detected.`n`nYour license needs to be reactivated.",
                "Reactivation Required",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            $licenseHash.licensed = $false
            $licenseHash.requiresReactivation = $true
            $license = [PSCustomObject]$licenseHash
            Set-LicenseFile $license
        } else {
            Write-LicenseLog "Hardware change $($licenseHash.hardwareChangeCount)/$MaxHardwareChanges allowed"
            $licenseHash.hardwareFingerprint = Get-HardwareFingerprint
            $license = [PSCustomObject]$licenseHash
            Set-LicenseFile $license
        }
    }
    
    # Check revalidation (every 7 days)
    $lastValidated = if ($license.lastValidated) { [datetime]$license.lastValidated } else { $now.AddDays(-8) }
    $daysSinceValidation = ($now - $lastValidated).Days
    
    if ($daysSinceValidation -ge $LicenseRevalidationDays) {
        Write-LicenseLog "Revalidation required (last: $($lastValidated.ToString('yyyy-MM-dd')))"
        $validationResult = Invoke-LicenseValidation -LicenseKey $license.licenseKey -MachineId $machineId -HardwareFingerprint $hardwareFingerprint
        
        if ($validationResult -and $validationResult.valid -eq $true -and $validationResult.status -eq 'active') {
            Write-LicenseLog "Revalidation successful"
            $licenseHash = @{
                licensed = $license.licensed
                licenseKey = $license.licenseKey
                machineId = $license.machineId
                hardwareFingerprint = $license.hardwareFingerprint
                lastValidated = $now
                licenseStatus = 'active'
            }
            $license = [PSCustomObject]$licenseHash
            Set-LicenseFile $license
        } elseif ($validationResult -and $validationResult.status -in @('cancelled','refunded','expired')) {
            Write-LicenseLog "ERROR: License revoked - Status: $($validationResult.status)"
            Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
            [System.Windows.Forms.MessageBox]::Show(
                "Your license has been $($validationResult.status).`n`nPlease contact support or purchase a new license.",
                "License $($validationResult.status)",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Error
            )
            exit 1
        } else {
            # Offline grace period
            $daysSinceLastValid = ($now - $lastValidated).Days
            if ($daysSinceLastValid -le $script:OFFLINE_GRACE_DAYS) {
                Write-LicenseLog "WARNING: Offline mode - $daysSinceLastValid days"
                $global:ADATT_OfflineMode = $true
                $global:ADATT_OfflineDaysLeft = $script:OFFLINE_GRACE_DAYS - $daysSinceLastValid
            } else {
                Write-LicenseLog "ERROR: Offline grace period expired"
                Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
                [System.Windows.Forms.MessageBox]::Show(
                    "License validation required.`n`nYou have been offline for $daysSinceLastValid days (maximum: $($script:OFFLINE_GRACE_DAYS)).`n`nPlease connect to the internet.",
                    "Online Validation Required",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Warning
                )
                exit 1
            }
        }
    }
    
    # Licensed - clear trial banner
    $global:ADATT_TrialBanner = $null
    $global:ADATT_DaysLeft = $null
} else {
    # Trial mode - calculate days left
    $trialStart = if ($license.trialStart) { [datetime]$license.trialStart } else { $now }
    $daysUsed = ($now - $trialStart).Days
    $daysLeft = $script:TRIAL_DAYS - $daysUsed
    
    Write-LicenseLog "Trial mode: $daysUsed days used, $daysLeft days remaining"
    
    if ($daysLeft -le 0) {
        # Trial expired - set flag but allow UI to load
        Write-LicenseLog "Trial expired - loading UI with limited access"
        $global:ADATT_TrialExpired = $true
        $global:ADATT_TrialBanner = "? TRIAL EXPIRED - Activate License"
        $global:ADATT_DaysLeft = 0
    } else {
        # Set trial banner globals
        Write-LicenseLog "Trial active: $daysLeft days remaining"
        $global:ADATT_TrialBanner = "Trial: $daysLeft days left"
        $global:ADATT_DaysLeft = $daysLeft
        
        # Set warning level for color coding
        if ($daysLeft -le 1) {
            $global:ADATT_TrialWarning = "URGENT"
        } elseif ($daysLeft -le 3) {
            $global:ADATT_TrialWarning = "HIGH"
        } elseif ($daysLeft -le 7) {
            $global:ADATT_TrialWarning = "MEDIUM"
        }
    }
}

#endregion

#region ----- WinForms & DPI -----
Add-Type -AssemblyName System.Windows.Forms | Out-Null
Add-Type -AssemblyName System.Drawing | Out-Null

# Make process DPI-aware
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class DpiAwareness {
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
}
"@
[void][DpiAwareness]::SetProcessDPIAware()
[System.Windows.Forms.Application]::EnableVisualStyles()

function Enable-DoubleBuffer {
  param([Parameter(Mandatory)][System.Windows.Forms.Control]$Control)
  try {
    $pi = $Control.GetType().GetProperty('DoubleBuffered',[System.Reflection.BindingFlags]'NonPublic,Instance')
    if ($pi) { $pi.SetValue($Control,$true,$null) }
  } catch {}
}

function Attach-Background {
  param([Parameter(Mandatory)][System.Windows.Forms.Form]$Form,
        [string]$ImagePath)
  $script:_BgImg = $null
  if ($ImagePath -and (Test-Path $ImagePath)) {
    $script:_BgImg = [System.Drawing.Image]::FromFile($ImagePath)
  }
  $Form.add_Paint({
    param($s,$e)
    $g = $e.Graphics
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $rect = $s.ClientRectangle
    if ($script:_BgImg) {
      $img = $script:_BgImg
      $ratio = $img.Width / $img.Height
      $w = $rect.Width
      $h = [int]($w / $ratio)
      if ($h -lt $rect.Height) { $h = $rect.Height; $w = [int]($h * $ratio) }
      $x = -[int](($w - $rect.Width)/2); $y = -[int](($h - $rect.Height)/2)
      $g.DrawImage($img,[System.Drawing.Rectangle]::new($x,$y,$w,$h))
      $overlay = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(96,0,0,0))
      $g.FillRectangle($overlay,$rect); $overlay.Dispose()
    } else {
      # Modern gradient background - deep blue to cyan
      $topColor    = [System.Drawing.Color]::FromArgb(255,10,25,47)    # Deep navy blue
      $midColor    = [System.Drawing.Color]::FromArgb(255,13,71,161)   # Rich blue
      $bottomColor = [System.Drawing.Color]::FromArgb(255,0,150,199)   # Vibrant cyan
      
      # Create multi-stop gradient for smooth transition
      $br = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect,$topColor,$bottomColor,45)
      $blend = New-Object System.Drawing.Drawing2D.ColorBlend
      $blend.Colors = @($topColor, $midColor, $bottomColor)
      $blend.Positions = @(0.0, 0.5, 1.0)
      $br.InterpolationColors = $blend
      $g.FillRectangle($br,$rect)
      $br.Dispose()
      
      # Add accent gradient overlay for depth
      $accentRect = [System.Drawing.Rectangle]::new(0, 0, $rect.Width, [int]($rect.Height * 0.3))
      $accentBr = New-Object System.Drawing.Drawing2D.LinearGradientBrush($accentRect,
        [System.Drawing.Color]::FromArgb(40,0,150,255),
        [System.Drawing.Color]::FromArgb(0,0,150,255),
        90)
      $g.FillRectangle($accentBr,$accentRect)
      $accentBr.Dispose()
      
      # Enhanced vignette with smoother edges
      $path = New-Object System.Drawing.Drawing2D.GraphicsPath
      $ellipse = [System.Drawing.Rectangle]::new([int]($rect.Width*-0.15),[int]($rect.Height*-0.25),
                                                 [int]($rect.Width*1.3),[int]($rect.Height*1.5))
      $path.AddEllipse($ellipse)
      $pbr = New-Object System.Drawing.Drawing2D.PathGradientBrush($path)
      $pbr.CenterColor    = [System.Drawing.Color]::FromArgb(0,0,0,0)
      $pbr.SurroundColors = ,([System.Drawing.Color]::FromArgb(90,0,0,30))
      $g.FillRectangle($pbr,$rect)
      $pbr.Dispose()
      $path.Dispose()
      
      # Add subtle grid pattern for tech feel
      $gridPen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(8,255,255,255), 1)
      $gridSpacing = 50
      for ($x = 0; $x -lt $rect.Width; $x += $gridSpacing) {
        $g.DrawLine($gridPen, $x, 0, $x, $rect.Height)
      }
      for ($y = 0; $y -lt $rect.Height; $y += $gridSpacing) {
        $g.DrawLine($gridPen, 0, $y, $rect.Width, $y)
      }
      $gridPen.Dispose()
    }
  })
  $Form.add_FormClosed({ if ($script:_BgImg) { $script:_BgImg.Dispose() } })
}

#endregion

#region ----- Small UI helpers -----
function New-Label([string]$Text,[int]$x,[int]$y,[int]$w=0,[int]$h=0,[int]$fs=10,[bool]$bold=$false,[System.Drawing.Color]$fore) {
  $lbl = New-Object System.Windows.Forms.Label
  $lbl.Text = $Text
  $lbl.AutoSize = $true
  $lbl.Left=$x; $lbl.Top=$y
  $lbl.ForeColor = $(if ($fore) { $fore } else { [System.Drawing.Color]::Gainsboro })
  $style = [System.Drawing.FontStyle]::Regular
  if ($bold) { $style = [System.Drawing.FontStyle]::Bold }
  $lbl.Font = New-Object System.Drawing.Font("Segoe UI",$fs,$style)
  if ($w -gt 0) { $lbl.Width = $w; $lbl.AutoSize = $false }
  if ($h -gt 0) { $lbl.Height = $h }
  return $lbl
}
function New-TextBox([int]$x,[int]$y,[int]$w=300,[string]$placeholder='') {
  $tb = New-Object System.Windows.Forms.TextBox
  $tb.Left=$x; $tb.Top=$y; $tb.Width=$w
  $tb.Font = New-Object System.Drawing.Font("Segoe UI",10)
  if ($placeholder) { 
    $tb.Text = $placeholder
    $tb.Tag = 'placeholder'
    $tb.ForeColor = [System.Drawing.Color]::Gray
  }
  $tb.add_GotFocus({ 
    if ($this.Tag -eq 'placeholder') { 
      $this.Text=''
      $this.Tag=$null
      $this.ForeColor = [System.Drawing.Color]::Black
    }
  })
  $tb.add_LostFocus({
    if ([string]::IsNullOrWhiteSpace($this.Text) -and $placeholder) {
      $this.Text = $placeholder
      $this.Tag = 'placeholder'
      $this.ForeColor = [System.Drawing.Color]::Gray
    }
  })
  return $tb
}
function New-Button([string]$Text,[int]$x,[int]$y,[int]$w=140,[int]$h=36,[System.Drawing.Color]$bg,[System.Drawing.Color]$fg) {
  $btn = New-Object System.Windows.Forms.Button
  $btn.Text = $Text
  $btn.Left=$x; $btn.Top=$y; $btn.Width=$w; $btn.Height=$h
  $btn.Font = New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
  $btn.BackColor = $(if ($bg) { $bg } else { [System.Drawing.Color]::FromArgb(60,80,160) })
  $btn.ForeColor = $(if ($fg) { $fg } else { [System.Drawing.Color]::White })
  $btn.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $btn.FlatAppearance.BorderSize = 0
  $btn.Cursor = [System.Windows.Forms.Cursors]::Hand
  return $btn
}
function New-GroupBox([string]$Text,[int]$x,[int]$y,[int]$w,[int]$h) {
  $gb = New-Object System.Windows.Forms.GroupBox
  $gb.Text = $Text
  $gb.Left=$x; $gb.Top=$y; $gb.Width=$w; $gb.Height=$h
  $gb.ForeColor = [System.Drawing.Color]::White
  $gb.BackColor = [System.Drawing.Color]::FromArgb(22,35,49)
  $gb.Font = New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
  return $gb
}
#endregion

#region ----- Form Skeleton -----
$form = New-Object System.Windows.Forms.Form
$form.Text = "$BrandName - $BrandSub"
# Add trial banner to form title if in trial mode
if ($global:ADATT_TrialBanner) {
    $form.Text = "{0} ({1})" -f $form.Text, $global:ADATT_TrialBanner.Replace('Trial:','Trial -').Trim()
}
$form.StartPosition = 'CenterScreen'
$form.Width = 1200
$form.Height = 820
$form.MinimumSize = New-Object System.Drawing.Size(1000,700)
$form.KeyPreview = $true
$form.add_KeyDown({
  if ($_.KeyCode -eq 'Escape') { $form.Close() }
})

Attach-Background -Form $form -ImagePath $BackgroundImagePath

# Add Buy License button if trial expired (only if trial expired or no license and not currently licensed)
$license = Get-LicenseFile
$now = Get-Date
$trialStartLocal = $null
if ($license -and $license.trialStart) { try { $trialStartLocal = [datetime]$license.trialStart } catch {} }
$trialExpired = ($license -and $license.licensed -ne $true -and $trialStartLocal -and (($now - $trialStartLocal).Days -ge $script:TRIAL_DAYS))
$needsBuyButton = (($null -eq $license) -or $trialExpired) -and (-not $license.licensed)

if ($needsBuyButton) {
    $btnBuyLicense = New-Object System.Windows.Forms.Button
    $btnBuyLicense.Text = "Buy License"
    $btnBuyLicense.Size = New-Object System.Drawing.Size(140,36)
    $btnBuyLicense.Font = New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
    $btnBuyLicense.ForeColor = [System.Drawing.Color]::White
    $btnBuyLicense.BackColor = [System.Drawing.Color]::FromArgb(255,60,160,60)
    $btnBuyLicense.Margin = New-Object System.Windows.Forms.Padding(6)
    $btnBuyLicense.Add_Click({ Start-Process $BuyUrl })
    $btnBuyLicense.Visible = $true
    $global:btnBuyLicense = $btnBuyLicense
    Write-LicenseLog "Buy License button shown (trial expired or no license)"
} else {
    $global:btnBuyLicense = $null
    Write-LicenseLog "Buy License button hidden (license active)"
}

# Header
$hdr = New-Object System.Windows.Forms.Panel
$hdr.Left = 0; $hdr.Top = 0; $hdr.Width = $form.ClientSize.Width; $hdr.Height = 110
$hdr.Anchor = 'Top,Left,Right'
$hdr.BackColor = [System.Drawing.Color]::FromArgb(70,0,0,0)
$form.Controls.Add($hdr); Enable-DoubleBuffer $hdr

$lblTitle = New-Label -Text "$BrandName" -x 24 -y 16 -fs 28 -bold $true
$hdr.Controls.Add($lblTitle)
$lblSub = New-Label -Text $BrandSub -x 26 -y 70 -fs 12 -bold $false -fore ([System.Drawing.Color]::White)
$hdr.Controls.Add($lblSub)

$btnBuy = New-Button -Text 'Buy License' -x ($hdr.Width-160) -y 50 -w 130 -h 36 -bg ([System.Drawing.Color]::FromArgb(58,174,131)) -fg ([System.Drawing.Color]::White)
$btnBuy.Anchor = 'Top,Right'
$btnBuy.add_Click({ Start-Process $BuyUrl })
$hdr.Controls.Add($btnBuy)

$btnActivate = New-Button -Text 'Activate License' -x ($hdr.Width-300) -y 50 -w 130 -h 32 -bg ([System.Drawing.Color]::FromArgb(59,107,177)) -fg ([System.Drawing.Color]::White)
$btnActivate.Anchor = 'Top,Right'
$hdr.Controls.Add($btnActivate)

# Hide both buttons if already licensed
if ($license -and $license.licensed -eq $true) {
    Write-LicenseLog "Hiding buttons on startup: licensed=$($license.licensed)"
    $btnBuy.Visible = $false
    $btnActivate.Visible = $false
    Write-LicenseLog "License buttons hidden (already licensed)"
} else {
    Write-LicenseLog "License buttons visible: licensed=$($license.licensed -eq $true), license exists=$($license -ne $null)"
}

# Add compact offline mode indicator below Activate button if applicable
if ($global:ADATT_OfflineMode) {
    $script:offlineHeader = New-Object System.Windows.Forms.Label
    $script:offlineHeader.Text = "? Offline Mode: $($global:ADATT_OfflineDaysLeft) days left"
    $script:offlineHeader.Font = New-Object System.Drawing.Font("Segoe UI",9,[System.Drawing.FontStyle]::Bold)
    $script:offlineHeader.ForeColor = [System.Drawing.Color]::White
    $script:offlineHeader.BackColor = [System.Drawing.Color]::FromArgb(255,200,100,0)
    $script:offlineHeader.AutoSize = $false
    $script:offlineHeader.Width = 200
    $script:offlineHeader.Height = 24
    $script:offlineHeader.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $script:offlineHeader.Location = [System.Drawing.Point]::new($hdr.Width-210, 20)
    $script:offlineHeader.Anchor = 'Top,Right'
    $script:offlineHeader.Padding = New-Object System.Windows.Forms.Padding(4,2,4,2)
    $hdr.Controls.Add($script:offlineHeader)
    $script:offlineHeader.BringToFront()
}

# Main panel
$main = New-Object System.Windows.Forms.Panel
$main.Left = 20; $main.Top = 120; $main.Width = $form.ClientSize.Width-40; $main.Height = $form.ClientSize.Height-180
$main.Anchor = 'Top,Bottom,Left,Right'
$main.BackColor = [System.Drawing.Color]::FromArgb(26,38,52)
$form.Controls.Add($main); Enable-DoubleBuffer $main

# Show trial expired banner if applicable
if ($global:ADATT_TrialExpired) {
    $expiredBanner = New-Object System.Windows.Forms.Panel
    $expiredBanner.Left = 20
    $expiredBanner.Top = 120
    $expiredBanner.Width = $form.ClientSize.Width - 40
    $expiredBanner.Height = 80
    $expiredBanner.Anchor = 'Top,Left,Right'
    $expiredBanner.BackColor = [System.Drawing.Color]::FromArgb(220,197,83,83)
    $form.Controls.Add($expiredBanner)
    
    $lblExpired = New-Object System.Windows.Forms.Label
    $lblExpired.Text = "? YOUR 14-DAY TRIAL HAS ENDED"
    $lblExpired.Font = New-Object System.Drawing.Font("Segoe UI",16,[System.Drawing.FontStyle]::Bold)
    $lblExpired.ForeColor = [System.Drawing.Color]::White
    $lblExpired.AutoSize = $false
    $lblExpired.Width = $expiredBanner.Width - 20
    $lblExpired.Height = 30
    $lblExpired.Left = 10
    $lblExpired.Top = 10
    $lblExpired.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $expiredBanner.Controls.Add($lblExpired)
    
    $lblExpiredSub = New-Object System.Windows.Forms.Label
    $lblExpiredSub.Text = "Click 'Activate License' above to unlock full access | Lifetime from `$175 (LAUNCH20 discount)"
    $lblExpiredSub.Font = New-Object System.Drawing.Font("Segoe UI",11)
    $lblExpiredSub.ForeColor = [System.Drawing.Color]::White
    $lblExpiredSub.AutoSize = $false
    $lblExpiredSub.Width = $expiredBanner.Width - 20
    $lblExpiredSub.Height = 30
    $lblExpiredSub.Left = 10
    $lblExpiredSub.Top = 45
    $lblExpiredSub.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $expiredBanner.Controls.Add($lblExpiredSub)
    
    # Adjust main panel position
    $main.Top = 210
    $main.Height = $form.ClientSize.Height - 270
}

# Section: User Access Termination
$gbUser = New-GroupBox -Text 'User Access Termination' -x 16 -y 14 -w ($main.Width-32) -h 170
$gbUser.Anchor = 'Top,Left,Right'
$main.Controls.Add($gbUser)

$lblNote = New-Label -Text 'Authorized use only. All actions are logged for audit and compliance' -x 14 -y 24 -fs 10 -bold $true -fore ([System.Drawing.Color]::Gainsboro)
$gbUser.Controls.Add($lblNote)

$lblTerm = New-Label -Text "Terminated user (sAMAccountName or UPN)" -x 14 -y 56 -fs 10 -bold $true -fore ([System.Drawing.Color]::Gainsboro)
$gbUser.Controls.Add($lblTerm)
$lblTermExample = New-Label -Text "Ex. jdoe or jdoe@company.com" -x 14 -y 74 -fs 9 -bold $true -fore ([System.Drawing.Color]::FromArgb(255,215,0))
$gbUser.Controls.Add($lblTermExample)
$tbTerm = New-Object System.Windows.Forms.TextBox
$tbTerm.Left = 320; $tbTerm.Top = 56; $tbTerm.Width = 360
$tbTerm.Font = New-Object System.Drawing.Font("Segoe UI",10)
$tbTerm.TabIndex = 0
$tooltip = New-Object System.Windows.Forms.ToolTip
$tooltip.SetToolTip($tbTerm, 'Enter the sAMAccountName or UPN (email) of the user to terminate')
$gbUser.Controls.Add($tbTerm)

$lblContact = New-Label -Text 'Contact / Manager 
 (auto-populated from manager)' -x 14 -y 100 -fs 10 -bold $true -fore ([System.Drawing.Color]::Gainsboro)
$gbUser.Controls.Add($lblContact)

# Contact display label (replaces textbox) - Auto-populated, read-only
$script:lblContactValue = New-Object System.Windows.Forms.Label
$script:lblContactValue.Text = ""
$script:lblContactValue.Font = New-Object System.Drawing.Font("Segoe UI",11)
$script:lblContactValue.ForeColor = [System.Drawing.Color]::FromArgb(100,200,255)
$script:lblContactValue.AutoSize = $false
$script:lblContactValue.Size = New-Object System.Drawing.Size(360,28)
$script:lblContactValue.Location = New-Object System.Drawing.Point(320,85)
$script:lblContactValue.TextAlign = 'MiddleLeft'
$script:lblContactValue.BackColor = [System.Drawing.Color]::FromArgb(35,35,35)
$script:lblContactValue.BorderStyle = 'FixedSingle'
$gbUser.Controls.Add($script:lblContactValue)

# Auto-populate manager when terminated user is entered
$tbTerm.Add_TextChanged({
    $script:lblContactValue.Text = ""
    $script:lblContactValue.ForeColor = [System.Drawing.Color]::FromArgb(100,200,255)
    
    $sam = $tbTerm.Text.Trim()
    if ($sam) {
        try {
            $user = Get-ADUser -Identity $sam -Properties Manager -ErrorAction Stop
            if ($user.Manager) {
                try {
                    $mgr = Get-ADUser -Identity $user.Manager -Properties DisplayName,SamAccountName -ErrorAction Stop
                    $script:lblContactValue.Text = "$($mgr.DisplayName) ($($mgr.SamAccountName))"
                    $script:lblContactValue.ForeColor = [System.Drawing.Color]::FromArgb(100,255,100)
                    $script:lblContactValue.Tag = $mgr.SamAccountName  # Store for later use
                } catch {
                    $script:lblContactValue.Text = "Manager not found"
                    $script:lblContactValue.ForeColor = [System.Drawing.Color]::FromArgb(255,150,100)
                }
            } else {
                $script:lblContactValue.Text = "No manager assigned"
                $script:lblContactValue.ForeColor = [System.Drawing.Color]::FromArgb(180,180,180)
            }
        } catch {
            # User not found or error - keep silent during typing
        }
    }
})

# Primary actions
# Add Buy License button if trial expired or no license
if ($global:btnBuyLicense) {
    $global:btnBuyLicense.Location = New-Object System.Drawing.Point(($gbUser.Width-920), 120)
    $global:btnBuyLicense.Anchor = 'Top,Right'
    $global:btnBuyLicense.TabIndex = 1
    $tooltip.SetToolTip($global:btnBuyLicense, 'Purchase a license to continue using ADATT after trial expiration')
    $gbUser.Controls.Add($global:btnBuyLicense)
}

$btnTerminate = New-Button -Text 'Terminate Access' -x ($gbUser.Width-810) -y 120 -w 170 -h 36 -bg ([System.Drawing.Color]::FromArgb(197,83,83)) -fg ([System.Drawing.Color]::White)
$btnTerminate.Anchor = 'Top,Right'
$btnTerminate.TabIndex = 2
$tooltip.SetToolTip($btnTerminate, 'Disable account, convert mailbox to shared, and configure auto-reply')
$gbUser.Controls.Add($btnTerminate)

# Disable if trial expired
if ($global:ADATT_TrialExpired) {
    $btnTerminate.Enabled = $false
    $btnTerminate.BackColor = [System.Drawing.Color]::FromArgb(120,120,120)
    $tooltip.SetToolTip($btnTerminate, 'Trial expired - Activate license to use this feature')
}

$btnResetMFA = New-Button -Text 'Reset MFA' -x ($gbUser.Width-620) -y 120 -w 140 -h 36 -bg ([System.Drawing.Color]::FromArgb(239,160,76)) -fg ([System.Drawing.Color]::White)
$btnResetMFA.Anchor = 'Top,Right'
$btnResetMFA.TabIndex = 3
$tooltip.SetToolTip($btnResetMFA, 'Remove all MFA authentication methods for the specified user')
$gbUser.Controls.Add($btnResetMFA)

# Disable if trial expired
if ($global:ADATT_TrialExpired) {
    $btnResetMFA.Enabled = $false
    $btnResetMFA.BackColor = [System.Drawing.Color]::FromArgb(120,120,120)
    $tooltip.SetToolTip($btnResetMFA, 'Trial expired - Activate license to use this feature')
}

$btnSignOut = New-Button -Text 'Sign Out Sessions' -x ($gbUser.Width-460) -y 120 -w 160 -h 36 -bg ([System.Drawing.Color]::FromArgb(178,102,255)) -fg ([System.Drawing.Color]::White)
$btnSignOut.Anchor = 'Top,Right'
$btnSignOut.TabIndex = 4
$tooltip.SetToolTip($btnSignOut, 'Sign out user from all M365 sessions')
$gbUser.Controls.Add($btnSignOut)

# Disable if trial expired
if ($global:ADATT_TrialExpired) {
    $btnSignOut.Enabled = $false
    $btnSignOut.BackColor = [System.Drawing.Color]::FromArgb(120,120,120)
    $tooltip.SetToolTip($btnSignOut, 'Trial expired - Activate license to use this feature')
}

$btnClear = New-Button -Text 'Clear' -x ($gbUser.Width-280) -y 120 -w 120 -h 36 -bg ([System.Drawing.Color]::FromArgb(59,107,177)) -fg ([System.Drawing.Color]::White)
$btnClear.Anchor = 'Top,Right'
$btnClear.TabIndex = 5
$tooltip.SetToolTip($btnClear, 'Clear all input fields')
$gbUser.Controls.Add($btnClear)
$btnClear.Add_Click({
    $tbTerm.Text = ""
    if ($script:lblContactValue) {
        $script:lblContactValue.Text = ""
        $script:lblContactValue.ForeColor = [System.Drawing.Color]::FromArgb(100,200,255)
        $script:lblContactValue.Tag = $null
    }
    # Reset bulk preview and file path
    $lblChosen.Text = "No file selected"
    $lblChosen.ForeColor = [System.Drawing.Color]::Gainsboro
    $grid.Rows.Clear()
    $btnRun.Enabled = $false
    $stLabel.Text = "Ready"
    $stLabel.ForeColor = [System.Drawing.Color]::FromArgb(100,220,100)
    try { $tbTerm.Focus() } catch {}
})

$btnHelp = New-Button -Text 'Help' -x ($gbUser.Width-140) -y 120 -w 140 -h 36 -bg ([System.Drawing.Color]::FromArgb(120,120,120)) -fg ([System.Drawing.Color]::White)
$btnHelp.Anchor = 'Top,Right'
$btnHelp.TabIndex = 6
$tooltip.SetToolTip($btnHelp, 'View detailed help and usage instructions')
$gbUser.Controls.Add($btnHelp)

# Section: Bulk Preview
$gbBulk = New-GroupBox -Text 'Bulk Preview' -x 16 -y ($gbUser.Bottom+12) -w ($main.Width-32) -h ($main.Height - $gbUser.Height - 28 - 64)
$gbBulk.Anchor = 'Top,Bottom,Left,Right'
$main.Controls.Add($gbBulk)

$lblBulkHint = New-Label -Text "Upload a TXT/CSV list of users for offboarding (min 2 and max 100). We'll validate against AD and show preview" `
                -x 14 -y 24 -fs 9 -bold $true -fore ([System.Drawing.Color]::Gainsboro)
$gbBulk.Controls.Add($lblBulkHint)

$btnChoose = New-Button -Text 'Choose File...' -x 16 -y 52 -w 140 -h 30 -bg ([System.Drawing.Color]::FromArgb(88,99,109)) -fg ([System.Drawing.Color]::White)
$btnChoose.TabIndex = 6
$tooltip.SetToolTip($btnChoose, 'Select a TXT or CSV file containing user accounts (one per line)')
$gbBulk.Controls.Add($btnChoose)

$lblChosen = New-Label -Text 'No file selected' -x 170 -y 58 -fs 9 -bold $true -fore ([System.Drawing.Color]::Gainsboro)
$gbBulk.Controls.Add($lblChosen)

# DataGridView for preview
$grid = New-Object System.Windows.Forms.DataGridView
$grid.Left = 16; $grid.Top = 90
$grid.Width = $gbBulk.Width-32; $grid.Height = $gbBulk.Height-150
$grid.Anchor = 'Top,Bottom,Left,Right'
$grid.ReadOnly = $true
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.AutoSizeColumnsMode = 'Fill'
$grid.BackgroundColor = [System.Drawing.Color]::FromArgb(20,32,45)
$grid.BorderStyle = 'None'
$grid.ColumnHeadersDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(17,52,69)
$grid.ColumnHeadersDefaultCellStyle.ForeColor = [System.Drawing.Color]::White
$grid.ColumnHeadersDefaultCellStyle.Font = New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
$grid.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(30,42,56)
$grid.DefaultCellStyle.ForeColor = [System.Drawing.Color]::White
$grid.DefaultCellStyle.SelectionBackColor = [System.Drawing.Color]::FromArgb(59,107,177)
$grid.DefaultCellStyle.SelectionForeColor = [System.Drawing.Color]::White
$grid.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(26,38,52)
$grid.AlternatingRowsDefaultCellStyle.ForeColor = [System.Drawing.Color]::White
$grid.EnableHeadersVisualStyles = $false
$grid.RowHeadersVisible = $false
$grid.GridColor = [System.Drawing.Color]::FromArgb(50,60,70)
$grid.Columns.Add('sam','sAMAccountName')   | Out-Null
$grid.Columns.Add('dn','DisplayName')       | Out-Null
$grid.Columns.Add('upn','UserPrincipalName') | Out-Null
$grid.Columns.Add('status','Status')        | Out-Null
$gbBulk.Controls.Add($grid); Enable-DoubleBuffer $grid

# Bottom buttons (bulk confirm)
$btnRun = New-Button -Text 'Run Bulk Offboarding' -x ($gbBulk.Width-280) -y ($gbBulk.Height-50) -w 240 -h 34 -bg ([System.Drawing.Color]::FromArgb(58,174,131)) -fg ([System.Drawing.Color]::White)
$btnRun.Anchor = 'Bottom,Right'
$btnRun.Enabled = $false
$gbBulk.Controls.Add($btnRun)

# Disable bulk operations if trial expired
if ($global:ADATT_TrialExpired) {
    $btnChoose.Enabled = $false
    $btnChoose.BackColor = [System.Drawing.Color]::FromArgb(60,60,60)
    $lblBulkHint.Text = "Trial expired - Activate license to use bulk offboarding (min 2 and max 100)"
    $lblBulkHint.ForeColor = [System.Drawing.Color]::FromArgb(255,180,100)
}

# Footer / status
$footer = New-Object System.Windows.Forms.StatusStrip
$footer.BackColor = [System.Drawing.Color]::FromArgb(14,36,56)
$form.Controls.Add($footer)
$footer.Dock = 'Bottom'

# Add "Support:" label
$supportTextLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$supportTextLabel.Text = "Support:"
$supportTextLabel.ForeColor = [System.Drawing.Color]::FromArgb(140,140,140)
$footer.Items.Add($supportTextLabel) | Out-Null

# Add Discord link
$discordLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$discordLabel.Text = "ADATT-DISCORD"
$discordLabel.ForeColor = [System.Drawing.Color]::FromArgb(100,180,255)
$discordLabel.IsLink = $true
$discordLabel.LinkBehavior = 'HoverUnderline'
$discordLabel.Add_Click({
    try {
        Start-Process "https://discord.gg/pRU54eMs"
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Discord: https://discord.gg/pRU54eMs", "Discord Link", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
    }
})
$footer.Items.Add($discordLabel) | Out-Null

# Add separator
$separatorLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$separatorLabel.Text = " | Email:"
$separatorLabel.ForeColor = [System.Drawing.Color]::FromArgb(140,140,140)
$footer.Items.Add($separatorLabel) | Out-Null

# Add Email link
$emailLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$emailLabel.Text = "adatt@unifosec.com"
$emailLabel.ForeColor = [System.Drawing.Color]::FromArgb(100,180,255)
$emailLabel.IsLink = $true
$emailLabel.LinkBehavior = 'HoverUnderline'
$emailLabel.Add_Click({
    try {
        Start-Process "mailto:adatt@unifosec.com"
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Email: adatt@unifosec.com", "Email Address", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
    }
})
$footer.Items.Add($emailLabel) | Out-Null

# Add spring to push Ready label to the right
$spring = New-Object System.Windows.Forms.ToolStripStatusLabel
$spring.Spring = $true
$footer.Items.Add($spring) | Out-Null

# Ready status label at the right
$stLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$stLabel.Text = 'Ready'
$stLabel.ForeColor = [System.Drawing.Color]::FromArgb(100,220,100)
$footer.Items.Add($stLabel) | Out-Null

# Resize handlers for responsive alignment
$hdr.add_Resize({
  $btnBuy.Left      = $hdr.Width - 160
  $btnActivate.Left = $hdr.Width - 160
})
$gbUser.add_Resize({
  if ($global:btnBuyLicense -and -not $global:btnBuyLicense.IsDisposed) {
    $global:btnBuyLicense.Left = $gbUser.Width - 1020
  }
  $btnTerminate.Left = $gbUser.Width - 820
  $btnResetMFA.Left  = $gbUser.Width - 620
  $btnSignOut.Left   = $gbUser.Width - 460
  $btnClear.Left     = $gbUser.Width - 280
  $btnHelp.Left      = $gbUser.Width - 140
})
$gbBulk.add_Resize({
  $grid.Width = $gbBulk.Width-32
  $grid.Height = $gbBulk.Height-150
  $btnRun.Left = $gbBulk.Width-280
  $btnRun.Top  = $gbBulk.Height-50
})
#endregion

#region ----- Validation & Stubs (Integrate your logic here) -----

function Test-EntraIdUser {
    <#
    .SYNOPSIS
    Tests if a user exists in Entra ID and returns detailed status
    
    .PARAMETER UserPrincipalName
    The UPN of the user to check
    
    .OUTPUTS
    Hashtable with Exists (bool), User (object), Error (string)
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$UserPrincipalName
    )
    
    if ([string]::IsNullOrWhiteSpace($UserPrincipalName)) {
        return @{ 
            Exists = $false
            User = $null
            Error = 'UserPrincipalName is null or empty'
        }
    }
    
    try {
        # Ensure Graph connectivity
        if (-not (Connect-GraphIfNeeded -RequiredScopes $script:GraphScopes)) {
            return @{ 
                Exists = $false
                User = $null
                Error = 'Microsoft Graph not connected'
            }
        }
        
        $user = Get-MgUser -UserId $UserPrincipalName -ErrorAction Stop
        
        Write-StructuredLog -Message "User verified in Entra ID" -Level 'INFO' -Category 'EntraID' -Data @{
            UPN = $UserPrincipalName
            DisplayName = $user.DisplayName
        }
        
        return @{ 
            Exists = $true
            User = $user
            Error = $null
        }
    } catch {
        Write-StructuredLog -Message "User not found in Entra ID" -Level 'WARN' -Category 'EntraID' -Data @{
            UPN = $UserPrincipalName
            Error = $_.Exception.Message
        }
        
        return @{ 
            Exists = $false
            User = $null
            Error = $_.Exception.Message
        }
    }
}

function Resolve-ADUser {
  param([string]$SamOrDisplay)
  
  if ([string]::IsNullOrWhiteSpace($SamOrDisplay)) { return $null }
  
  try {
      # Try by SAM account name first
      $adUser = Get-ADUser -Filter "SamAccountName -eq '$SamOrDisplay'" -Properties DisplayName,Enabled,UserPrincipalName,Manager,Mail -ErrorAction Stop
      
      if (-not $adUser) {
          # Fallback: try DisplayName exact match
          $adUser = Get-ADUser -Filter "DisplayName -eq '$SamOrDisplay'" -Properties DisplayName,Enabled,UserPrincipalName,Manager,Mail -ErrorAction Stop
      }
      
      if (-not $adUser) { 
          Write-Log "User '$SamOrDisplay' not found in Active Directory" 'WARN'
          return $null 
      }
      
      # Get manager info if available
      $managerSam = $null
      $managerPhone = $null
      if ($adUser.Manager) {
          try {
              $mgr = Get-ADUser -Identity $adUser.Manager -Properties telephoneNumber -ErrorAction SilentlyContinue
              if ($mgr) {
                  $managerSam = $mgr.SamAccountName
                  $managerPhone = $mgr.telephoneNumber
              }
          } catch {
              Write-Log "WARN: Could not retrieve manager info for '$SamOrDisplay': $_" 'WARN'
          }
      }
      
      return [pscustomobject]@{
          SamAccountName   = $adUser.SamAccountName
          DisplayName      = $adUser.DisplayName
          Enabled          = $adUser.Enabled
          UserPrincipalName= $adUser.UserPrincipalName
          ManagerSam       = $managerSam
          ManagerPhone     = $managerPhone
          Mail             = $adUser.Mail
      }
  } catch {
      Write-Log "ERROR: Resolve-ADUser failed for '$SamOrDisplay': $_" 'ERROR'
      return $null
  }
}

function Show-HelpDialog {
  $dlg = New-Object System.Windows.Forms.Form
  $dlg.Text = "$BrandName  Help"
  $dlg.StartPosition = 'CenterParent'
  $dlg.Width = 820; $dlg.Height = 520
  $dlg.BackColor = [System.Drawing.Color]::White
  $dlg.KeyPreview = $true
  $dlg.add_KeyDown({ if ($_.KeyCode -eq 'Escape') { $dlg.Close() } })
  $tb = New-Object System.Windows.Forms.TextBox
  $tb.Multiline = $true; $tb.ReadOnly = $true; $tb.ScrollBars='Vertical'
  $tb.Dock = 'Fill'
  $tb.Font = New-Object System.Drawing.Font("Segoe UI",10)
  $tb.Text = @"
===============================================================
             ADATT - Professional Identity Management
             Active Directory and Azure Termination Tool
                          Version 1.4.0
===============================================================

STREAMLINE YOUR OFFBOARDING WORKFLOW

ADATT automates the complex process of user termination across hybrid 
environments, ensuring consistent, secure, and compliant offboarding 
every time.

KEY CAPABILITIES

[+] Hybrid Environment Support
  Seamlessly manages both on-premises Active Directory and Microsoft 365 
  (Entra ID / Exchange Online) in a single, coordinated workflow.

[+] Comprehensive User Deactivation
  - Disables Active Directory accounts with audit trail
  - Converts Exchange mailboxes to shared for access continuity
  - Removes all group memberships while preserving audit logs
  - Clears sensitive attributes (manager, contacts)
  - Hides users from Global Address List

[+] Advanced Security Features
  - Removes all authentication methods (MFA, FIDO2, Authenticator)
  - Deletes registered devices and access tokens
  - Configurable auto-reply with contact redirection
  - Standalone MFA reset utility for security incidents

[+] Bulk Operations
  Process multiple terminations efficiently from CSV or text files with 
  built-in safeguards, validation, and detailed reporting.

[+] Enterprise-Grade Reliability
  - Elevation detection with automatic UAC prompting
  - Comprehensive error handling and logging
  - Real-time progress tracking
  - Rollback-safe operations with confirmation prompts

LICENSING

30-day free trial included. Flexible licensing options:
  - Solo Admin: 1 device
  - Team: 5 devices  
  - Business: 20+ devices

Licensed version removes trial banner and enables full feature access.

===============================================================

SUPPORT & ASSISTANCE

Email: adatt@unifosec.com
Discord Community: https://discord.gg/tQKW9vem

For technical support, feature requests, or licensing inquiries,
our team is ready to assist.

Developed by Jose Ernest | (c) 2025 UNIFOSEC
"@
  $dlg.Controls.Add($tb)
  $dlg.ShowDialog($form) | Out-Null
}

function Test-EntraIdUpnMismatch {
    <#
    .SYNOPSIS
    Checks if Active Directory UPN matches Entra ID UPN
    
    .PARAMETER AdUpn
    UserPrincipalName from Active Directory
    
    .PARAMETER EntraUser
    Entra ID user object from Get-MgUser
    
    .RETURNS
    Hashtable with IsMismatch (bool) and EntraUpn (string)
    #>
    param(
        [string]$AdUpn,
        [object]$EntraUser
    )
    
    if (-not $EntraUser -or [string]::IsNullOrWhiteSpace($AdUpn)) {
        return @{ IsMismatch = $false; EntraUpn = $null }
    }
    
    $entraUpn = $EntraUser.UserPrincipalName
    $isMismatch = $AdUpn -ne $entraUpn
    
    return @{
        IsMismatch = $isMismatch
        EntraUpn = $entraUpn
    }
}

function Test-GraphUserWritePermission {
    try {
        # Try to get current Graph context
        $context = Get-MgContext -ErrorAction Stop
        if (-not $context) {
            return @{
                HasPermission = $false
                Error = "Not connected to Microsoft Graph. Run Connect-MgGraph first."
                IsRoleIssue = $false
            }
        }
        
        # Check if we have User.ReadWrite.All or Directory.AccessAsUser.All in scopes
        $scopes = $context.Scopes
        $hasWritePermission = $scopes -contains "User.ReadWrite.All" -or 
                              $scopes -contains "Directory.AccessAsUser.All" -or
                              $scopes -contains "Directory.ReadWrite.All"
        
        if (-not $hasWritePermission) {
            return @{
                HasPermission = $false
                Error = "Insufficient Microsoft Graph API scopes. Current scopes: $($scopes -join ', ')`n`nRequired API scopes:`n- User.ReadWrite.All (or)`n- Directory.AccessAsUser.All (or)`n- Directory.ReadWrite.All"
                IsRoleIssue = $false
            }
        }
        
        return @{
            HasPermission = $true
            Error = $null
            IsRoleIssue = $false
        }
    } catch {
        return @{
            HasPermission = $false
            Error = "Error checking Graph permissions: $($_.Exception.Message)"
            IsRoleIssue = $false
        }
    }
}

function Show-AutoReplyDialog {
    param([string]$DefaultMessage, [string]$Title, [System.Windows.Forms.IWin32Window]$Owner)
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = $Title
    $dlg.Size = New-Object System.Drawing.Size(600,300)
    $dlg.StartPosition = 'CenterParent'
    $txt = New-Object System.Windows.Forms.TextBox
    $txt.Multiline = $true; $txt.ScrollBars = 'Vertical'; $txt.Dock = 'Fill'; $txt.Text = $DefaultMessage
    $dlg.Controls.Add($txt)
    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = "OK"; $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK; $btnOK.Dock = 'Bottom'
    $dlg.Controls.Add($btnOK)
    $dlg.AcceptButton = $btnOK; $dlg.CancelButton = $btnOK
    $result = $dlg.ShowDialog($Owner)
    if ($result -eq [System.Windows.Forms.DialogResult]::OK) { return $txt.Text } else { return $null }
}

function Test-UserHasMailbox {
    <#
    .SYNOPSIS
    Tests if a user has an Exchange mailbox with caching for performance
    
    .PARAMETER UserPrincipalName
    The UPN of the user to check
    
    .OUTPUTS
    Boolean indicating if mailbox exists
    #>
    param([string]$UserPrincipalName)
    
    if ([string]::IsNullOrWhiteSpace($UserPrincipalName)) { return $false }
    
    # Initialize cache if needed
    if (-not $script:MailboxCache) {
        $script:MailboxCache = @{}
        $script:MailboxCacheExpiry = (Get-Date).AddMinutes($MailboxCacheExpiryMinutes)
    }
    
    # Refresh cache if expired
    if ((Get-Date) -gt $script:MailboxCacheExpiry) {
        $script:MailboxCache = @{}
        $script:MailboxCacheExpiry = (Get-Date).AddMinutes($MailboxCacheExpiryMinutes)
        Write-StructuredLog -Message "Mailbox cache refreshed" -Level 'DEBUG' -Category 'Performance'
    }
    
    # Return cached result if available
    if ($script:MailboxCache.ContainsKey($UserPrincipalName)) {
        Write-StructuredLog -Message "Mailbox check from cache" -Level 'DEBUG' -Category 'Performance' -Data @{UPN=$UserPrincipalName; Cached=$true}
        return $script:MailboxCache[$UserPrincipalName]
    }
    
    # Check mailbox existence
    try {
        $mailbox = Get-Mailbox -Identity $UserPrincipalName -ErrorAction Stop
        $hasMailbox = $null -ne $mailbox
    } catch {
        $hasMailbox = $false
    }
    
    # Cache result
    $script:MailboxCache[$UserPrincipalName] = $hasMailbox
    Write-StructuredLog -Message "Mailbox existence checked" -Level 'INFO' -Category 'Exchange' -Data @{UPN=$UserPrincipalName; HasMailbox=$hasMailbox}
    
    return $hasMailbox
}

function Assert-ExchangeOnlineConnection {
    <#
    .SYNOPSIS
    Validates Exchange Online connection before operations
    
    .OUTPUTS
    Boolean indicating if connection is available
    #>
    $exoSession = Get-PSSession | Where-Object { 
        $_.ConfigurationName -eq 'Microsoft.Exchange' -and 
        $_.State -eq 'Opened' 
    } | Select-Object -First 1
    
    if (-not $exoSession) {
        Write-StructuredLog -Message "Exchange Online connection not found, attempting connection" -Level 'WARN' -Category 'Exchange'
        if (-not (Connect-EXOIfNeeded)) {
            Write-StructuredLog -Message "Exchange Online connection failed" -Level 'ERROR' -Category 'Exchange'
            return $false
        }
    }
    
    Write-StructuredLog -Message "Exchange Online connection validated" -Level 'DEBUG' -Category 'Exchange'
    return $true
}

#endregion

#region ----- Core Offboarding Function -----

function Remove-UserAuthenticationMethod {
    <#
    .SYNOPSIS
    Removes a single authentication method from a user
    
    .PARAMETER UserId
    The UPN or Object ID of the user
    
    .PARAMETER Method
    The authentication method object to remove
    
    .OUTPUTS
    Boolean indicating success
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$UserId,
        
        [Parameter(Mandatory)]
        [object]$Method
    )
    
    $methodType = $Method.AdditionalProperties['@odata.type']
    
    try {
        switch ($methodType) {
            '#microsoft.graph.fido2AuthenticationMethod' {
                Write-StructuredLog -Message 'Removing FIDO2 authentication method' -Category 'MFA' -Data @{ UserId = $UserId; MethodId = $Method.Id }
                Remove-MgUserAuthenticationFido2Method -UserId $UserId -Fido2AuthenticationMethodId $Method.Id -ErrorAction Stop
            }
            '#microsoft.graph.emailAuthenticationMethod' {
                Write-StructuredLog -Message 'Removing email authentication method' -Category 'MFA' -Data @{ UserId = $UserId; MethodId = $Method.Id }
                Remove-MgUserAuthenticationEmailMethod -UserId $UserId -EmailAuthenticationMethodId $Method.Id -ErrorAction Stop
            }
            '#microsoft.graph.microsoftAuthenticatorAuthenticationMethod' {
                Write-StructuredLog -Message 'Removing Microsoft Authenticator method' -Category 'MFA' -Data @{ UserId = $UserId; MethodId = $Method.Id }
                Remove-MgUserAuthenticationMicrosoftAuthenticatorMethod -UserId $UserId -MicrosoftAuthenticatorAuthenticationMethodId $Method.Id -ErrorAction Stop
            }
            '#microsoft.graph.phoneAuthenticationMethod' {
                Write-StructuredLog -Message 'Removing phone authentication method' -Category 'MFA' -Data @{ UserId = $UserId; MethodId = $Method.Id }
                Remove-MgUserAuthenticationPhoneMethod -UserId $UserId -PhoneAuthenticationMethodId $Method.Id -ErrorAction Stop
            }
            '#microsoft.graph.softwareOathAuthenticationMethod' {
                Write-StructuredLog -Message 'Removing software OATH method' -Category 'MFA' -Data @{ UserId = $UserId; MethodId = $Method.Id }
                Remove-MgUserAuthenticationSoftwareOathMethod -UserId $UserId -SoftwareOathAuthenticationMethodId $Method.Id -ErrorAction Stop
            }
            '#microsoft.graph.temporaryAccessPassAuthenticationMethod' {
                Write-StructuredLog -Message 'Removing temporary access pass method' -Category 'MFA' -Data @{ UserId = $UserId; MethodId = $Method.Id }
                Remove-MgUserAuthenticationTemporaryAccessPassMethod -UserId $UserId -TemporaryAccessPassAuthenticationMethodId $Method.Id -ErrorAction Stop
            }
            '#microsoft.graph.windowsHelloForBusinessAuthenticationMethod' {
                Write-StructuredLog -Message 'Removing Windows Hello method' -Category 'MFA' -Data @{ UserId = $UserId; MethodId = $Method.Id }
                Remove-MgUserAuthenticationWindowsHelloForBusinessMethod -UserId $UserId -WindowsHelloForBusinessAuthenticationMethodId $Method.Id -ErrorAction Stop
            }
            '#microsoft.graph.passwordAuthenticationMethod' {
                Write-StructuredLog -Message 'Skipping password authentication method (cannot be removed)' -Level 'DEBUG' -Category 'MFA'
                return $true
            }
            Default {
                Write-StructuredLog -Message "Unsupported authentication method type: $methodType" -Level 'WARN' -Category 'MFA'
                return $false
            }
        }
        return $true
    } catch {
        $err = $_.Exception.Message
        if ($err -match '(?i)default') {
            Write-StructuredLog -Message "Cannot remove default authentication method; skipping" -Level 'INFO' -Category 'MFA' -Data @{ Error = $err }
            return $true
        } else {
            Write-StructuredLog -Message "Failed to remove authentication method" -Level 'ERROR' -Category 'MFA' -Data @{ MethodType = $methodType; Error = $err }
            return $false
        }
    }
}

function Do-OffboardCore {
    <#
    .SYNOPSIS
    Performs complete user offboarding in hybrid AD/Entra environment
    
    .PARAMETER TermSam
    SAMAccountName of user to terminate
    
    .PARAMETER ContactSam
    SAMAccountName of contact/manager for forwarding
    
    .PARAMETER AutoReplyMessage
    Custom auto-reply message
    
    .PARAMETER SkipCloud
    Skip cloud operations (Entra ID, Exchange Online)
    
    .PARAMETER BulkMode
    Optimize for bulk processing by reducing verbose logging and checks
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [ValidateLength(1,20)]
        [string]$TermSam,
        
        [Parameter()]
        [ValidateLength(0,20)]
        [string]$ContactSam,
        
        [Parameter()]
        [string]$AutoReplyMessage,
        
        [switch]$SkipCloud,
        
        [switch]$BulkMode
    )
    $result = [pscustomobject]@{ Success=$false; TermSam=$TermSam; Error=$null; AccountType="Unknown" }
    try {
        if (-not $BulkMode) { Write-Log ("INFO: Offboard START for {0}; SkipCloud={1}" -f $TermSam,$SkipCloud) }
        
        # Resolve users - try AD first, then Entra ID for cloud-only users
        $termUser = $null
        $isCloudOnly = $false
        
        try { 
            $termUser = Get-ADUser -Identity $TermSam -Properties SamAccountName,DisplayName,UserPrincipalName,EmailAddress,Description,Enabled -ErrorAction Stop 
        } catch {
            # User not found in AD - check if cloud-only
            if (-not $BulkMode) { Write-Log ("INFO: User {0} not found in AD, checking Entra ID" -f $TermSam) }
            
            try {
                $cloudUser = $null
                
                # Try different search strategies for cloud user
                if ($TermSam -like "*@*") {
                    # UPN or email provided
                    try {
                        $cloudUser = Get-MgUser -Filter "userPrincipalName eq '$TermSam' or mail eq '$TermSam'" -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction Stop
                    } catch {
                        try {
                            $cloudUser = Get-MgUser -UserId $TermSam -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction SilentlyContinue
                        } catch {}
                    }
                } else {
                    # Try mailNickname
                    try {
                        $cloudUser = Get-MgUser -Filter "mailNickname eq '$TermSam'" -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction Stop
                    } catch {}
                }
                
                if ($cloudUser) {
                    $termUser = [PSCustomObject]@{
                        SamAccountName = if ($cloudUser.MailNickname) { $cloudUser.MailNickname } else { $TermSam }
                        DisplayName = $cloudUser.DisplayName
                        UserPrincipalName = $cloudUser.UserPrincipalName
                        EmailAddress = if ($cloudUser.Mail) { $cloudUser.Mail } else { $cloudUser.UserPrincipalName }
                        Description = "Cloud-only user"
                        Enabled = $cloudUser.AccountEnabled
                    }
                    $isCloudOnly = $true
                    if (-not $BulkMode) { Write-Log ("INFO: Found cloud-only user {0} in Entra ID" -f $cloudUser.UserPrincipalName) }
                } else {
                    throw "User '$TermSam' not found in Active Directory or Entra ID"
                }
            } catch {
                throw "User '$TermSam' not found: $($_.Exception.Message)"
            }
        }
        
        $contactUser = $null
        if ($ContactSam) {
            try { $contactUser = Get-ADUser -Identity $ContactSam -Properties SamAccountName,DisplayName,UserPrincipalName,TelephoneNumber -ErrorAction Stop } catch { $contactUser = $null }
        }

        # Check if user exists in Entra ID (unless cloud is already being skipped globally)
        $upn = $termUser.UserPrincipalName
        $entraExists = $isCloudOnly  # Cloud-only users obviously exist in Entra
        $entraUser = $null
        
        # Determine account type for reporting
        if ($isCloudOnly) {
            $result.AccountType = "Cloud-Only"
        } elseif ($entraExists) {
            $result.AccountType = "Hybrid"
        } else {
            $result.AccountType = "On-Premises"
        }
        
        if (-not $isCloudOnly -and -not $SkipCloud -and ![string]::IsNullOrWhiteSpace($upn)) {
            # Skip individual Entra checks in bulk mode if skipCloud is already set
            if (-not $BulkMode) {
                $entraCheck = Test-EntraIdUser -UserPrincipalName $upn
                $entraExists = $entraCheck.Exists
                $entraUser = $entraCheck.User
                
                if ($entraExists) {
                    Write-Log ("INFO: User {0} found in Entra ID, will perform cloud operations" -f $upn)
                } else {
                    Write-Log ("INFO: User {0} not found in Entra ID, will skip cloud operations (on-prem only)" -f $upn)
                }
            } else {
                # In bulk mode, assume cloud operations are available if not explicitly skipped
                $entraExists = $true
            }
        }

        $alreadyTerminated = ($termUser.Enabled -eq $false)
        if ($SkipCloud -and $alreadyTerminated) {
            $result.Success = $true
            return $result
        }

        # Disable account (CRITICAL - must succeed)
        if (-not $alreadyTerminated) {
            if (-not $isCloudOnly) {
                # Hybrid or on-prem user - disable in AD
                try {
                    Disable-ADAccount -Identity $termUser.SamAccountName -ErrorAction Stop
                    if (-not $BulkMode) { Write-Log ("INFO: AD account disabled for {0}" -f $TermSam) }
                } catch {
                    throw "Failed to disable AD account: $($_.Exception.Message)"
                }
            } else {
                # Cloud-only user - disable in Entra ID
                try {
                    Update-MgUser -UserId $termUser.UserPrincipalName -AccountEnabled:$false -ErrorAction Stop
                    if (-not $BulkMode) { Write-Log ("INFO: Entra ID account disabled for {0}" -f $termUser.UserPrincipalName) }
                } catch {
                    throw "Failed to disable Entra ID account: $($_.Exception.Message)"
                }
            }
        }

        # Update description (non-critical, skip for cloud-only users)
        if (-not $isCloudOnly) {
            try {
                $currentLoginUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
                $currentDateTime = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
                $existingDescription = $termUser.Description
                $newDescription = if ($existingDescription) { "$existingDescription | Disabled by $currentLoginUser on $currentDateTime" } else { "Disabled by $currentLoginUser on $currentDateTime" }
                Set-ADUser -Identity $termUser.SamAccountName -Description $newDescription -ErrorAction Stop
                if (-not $BulkMode) { Write-Log ("INFO: Description updated for {0}" -f $TermSam) }
            } catch {
                if (-not $BulkMode) { Write-Log ("WARN: Failed to update description for {0}: {1}" -f $TermSam, $_.Exception.Message) }
            }
        }

        # Clear manager (non-critical, skip for cloud-only users)
        if (-not $isCloudOnly) {
            try {
                Set-ADUser -Identity $termUser.SamAccountName -Clear manager -ErrorAction Stop
                if (-not $BulkMode) { Write-Log ("INFO: Manager cleared for {0}" -f $TermSam) }
            } catch {
                if (-not $BulkMode) { Write-Log ("WARN: Failed to clear manager for {0}: {1}" -f $TermSam, $_.Exception.Message) }
            }
        }

        # Exchange operations - only if user exists in Entra ID (all non-critical)
        # In BulkMode, skip slow Exchange operations to maximize speed
        if (-not $SkipCloud -and $entraExists -and -not $BulkMode) {
            if (-not (Connect-EXOIfNeeded)) { 
                Write-Log ("WARN: Exchange Online connection failed for {0}" -f $TermSam)
            } else {
                # Check if mailbox exists before attempting Exchange operations
                $hasMailbox = $false
                try {
                    $mailbox = Get-Mailbox -Identity $termUser.UserPrincipalName -ErrorAction Stop
                    $hasMailbox = $true
                } catch {
                    Write-Log ("INFO: No mailbox found for {0}, skipping Exchange operations" -f $TermSam)
                }
                
                if ($hasMailbox) {
                    # Convert mailbox to shared (non-critical)
                    try {
                        Set-Mailbox -Identity $termUser.UserPrincipalName -Type Shared -ErrorAction Stop
                        Write-Log ("INFO: Mailbox converted to shared for {0}" -f $TermSam)
                    } catch {
                        Write-Log ("WARN: Failed to convert mailbox for {0}: {1}" -f $TermSam, $_.Exception.Message)
                    }

                    # Hide from GAL via EXO (non-critical)
                    try {
                        Set-Mailbox -Identity $termUser.UserPrincipalName -HiddenFromAddressListsEnabled $true -ErrorAction Stop
                        Write-Log ("INFO: Hidden from GAL (EXO) for {0}" -f $TermSam)
                    } catch {
                        Write-Log ("WARN: Failed to hide from GAL (EXO) for {0}: {1}" -f $TermSam, $_.Exception.Message)
                    }

                    # Hide from GAL via AD attribute (non-critical, often fails, skip for cloud-only users)
                    if (-not $isCloudOnly) {
                        try {
                            Get-ADUser -Identity $termUser.SamAccountName | Set-ADObject -Replace @{ msExchHideFromAddressLists=$true } -ErrorAction Stop
                            Write-Log ("INFO: Hidden from GAL (AD) for {0}" -f $TermSam)
                        } catch {
                            Write-Log ("WARN: Failed to hide from GAL (AD) for {0}: {1}" -f $TermSam, $_.Exception.Message)
                        }
                    }
                }
            }
        } elseif (-not $SkipCloud -and -not $entraExists) {
            if (-not $BulkMode) { Write-Log ("INFO: Skipped EXO mailbox/GAL operations for {0} (on-prem only user)" -f $TermSam) }
        }
        
        # Remove Office 365 licenses (non-critical)
        if (-not $SkipCloud -and $entraExists -and -not $BulkMode) {
            if (Connect-GraphIfNeeded -RequiredScopes $script:GraphScopes) {
                try {
                    $userId = if ($termUser.UserPrincipalName) { $termUser.UserPrincipalName } elseif ($termUser.EmailAddress) { $termUser.EmailAddress } else { $null }
                    if ($userId) {
                        $licenses = Get-MgUserLicenseDetail -UserId $userId -ErrorAction Stop
                        if ($licenses) {
                            foreach ($license in $licenses) {
                                try {
                                    Set-MgUserLicense -UserId $userId -RemoveLicenses @($license.SkuId) -AddLicenses @() -ErrorAction Stop
                                    Write-Log ("INFO: Removed license {0} from {1}" -f $license.SkuPartNumber, $TermSam)
                                } catch {
                                    Write-Log ("WARN: Failed to remove license {0} from {1}: {2}" -f $license.SkuPartNumber, $TermSam, $_.Exception.Message)
                                }
                            }
                        }
                    }
                } catch {
                    Write-Log ("WARN: Failed to process licenses for {0}: {1}" -f $TermSam, $_.Exception.Message)
                }
            }
        }

        # Build auto-reply if not provided
        if (-not $AutoReplyMessage) {
            $TerminateFullName = $termUser.DisplayName
            $ContactInfo = if ($contactUser) { $contactUser.DisplayName } else { $null }
            $Contactemail = if ($contactUser) { $contactUser.UserPrincipalName } else { $null }
            $ContactPhone = if ($contactUser) { $contactUser.TelephoneNumber } else { $null }
            $AutoReplyMessage = if ($ContactInfo -and $Contactemail) {
                "Thank you for contacting $TerminateFullName. This message is to inform you that $TerminateFullName is no longer a member of the Organization. For any official matters please contact $ContactInfo at $Contactemail" + $(if ($ContactPhone) { " or $ContactPhone" } else { "" }) + ". Thank you."
            } else {
                "Thank you for your message. The mailbox you have reached is no longer monitored."
            }
        }

        # Set auto-reply - only if user exists in Entra ID (non-critical)
        # Skip in BulkMode to maximize speed
        if (-not $SkipCloud -and $entraExists -and -not $BulkMode) {
            try {
                Set-MailboxAutoReplyConfiguration -Identity $termUser.UserPrincipalName -AutoReplyState Enabled -InternalMessage $AutoReplyMessage -ExternalMessage $AutoReplyMessage -ErrorAction Stop
                Write-Log ("INFO: EXO auto-reply set for {0}" -f $TermSam)
            } catch {
                Write-Log ("WARN: Failed to set auto-reply for {0}: {1}" -f $TermSam, $_.Exception.Message)
            }
        } elseif (-not $SkipCloud -and -not $entraExists) {
            if (-not $BulkMode) { Write-Log ("INFO: Skipped EXO auto-reply for {0} (on-prem only user)" -f $TermSam) }
        }

        # Remove group memberships (primary group not included, skip for cloud-only users)
        if (-not $isCloudOnly) {
            try {
                $groups = Get-ADUser -Identity $termUser.SamAccountName -Properties MemberOf -ErrorAction Stop | Select-Object -ExpandProperty MemberOf -ErrorAction SilentlyContinue
                foreach ($group in @($groups)) {
                    if ($group) { Remove-ADGroupMember -Identity $group -Members $termUser.SamAccountName -Confirm:$false -ErrorAction Stop }
                }
            } catch {}
            Write-Log ("INFO: AD group removal complete for {0}" -f $TermSam)
        }

        # Graph clean-up - only if user exists in Entra ID
        # Skip in BulkMode to maximize speed - these are non-critical cleanup operations
        if (-not $SkipCloud -and $entraExists -and -not $BulkMode) {
            $userId = if ($termUser.UserPrincipalName) { $termUser.UserPrincipalName } elseif ($termUser.EmailAddress) { $termUser.EmailAddress } else { $null }
            if ($userId -and (Connect-GraphIfNeeded -RequiredScopes $script:GraphScopes)) {
                try {
                    $devices = Get-MgUserRegisteredDevice -UserId $userId -ErrorAction Stop
                    foreach ($device in @($devices)) { try { Remove-MgDevice -DeviceId $device.Id -ErrorAction Stop } catch {} }
                } catch {}

                try {
                    $methods = Get-MgUserAuthenticationMethod -UserId $userId -ErrorAction Stop
                    foreach ($m in @($methods)) { 
                        Remove-UserAuthenticationMethod -UserId $userId -Method $m | Out-Null
                    }
                    try { $oathExtra = Get-MgUserAuthenticationSoftwareOathMethod -UserId $userId -ErrorAction Stop; foreach($ox in @($oathExtra)){ try { Remove-MgUserAuthenticationSoftwareOathMethod -UserId $userId -SoftwareOathAuthenticationMethodId $ox.Id -ErrorAction Stop } catch {} } } catch {}
                } catch {}
            }
            Write-Log ("INFO: Graph device/auth cleanup complete for {0}" -f $TermSam)
        } elseif (-not $SkipCloud -and -not $entraExists) {
            if (-not $BulkMode) { Write-Log ("INFO: Skipped Graph device/auth cleanup for {0} (on-prem only user)" -f $TermSam) }
        }

        $result.Success = $true
        Write-Log ("INFO: Offboard SUCCESS for {0}" -f $TermSam)
        return $result
    } catch {
        $result.Error = $_.Exception.Message
        Write-Log ("ERROR: Offboard FAILED for {0}: {1}" -f $TermSam, $_.Exception.Message)
        return $result
    }
}
#endregion

#region ----- Wire Up: Single Termination -----
$btnTerminate.Add_Click({

    try {
        $sam = $null
        $contact = $null
        if ($null -ne $tbTerm -and $tbTerm -is [System.Windows.Forms.TextBox]) {
            $sam = $tbTerm.Text.Trim()
        }
        # Get contact from the label's Tag (set by the TextChanged event)
        if ($script:lblContactValue -and $script:lblContactValue.Tag) {
            $contact = $script:lblContactValue.Tag
        }

        # Only require terminated user SAMAccountName or UPN
        if (-not $sam) {
            [System.Windows.Forms.MessageBox]::Show("Terminated user sAMAccountName or UPN must be provided.","Input required",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
            if ($null -ne $tbTerm -and $tbTerm -is [System.Windows.Forms.TextBox]) { $tbTerm.Focus() }
            return
        }

        # Defensive AD lookup - get terminated user with manager property
        $termUser = $null
        $isCloudOnly = $false
        
        try {
            $termUser = Get-ADUser -Filter "SamAccountName -eq '$sam'" -Properties SamAccountName,DisplayName,UserPrincipalName,EmailAddress,Description,Enabled,Manager -ErrorAction Stop
        } catch {
            $errMsg = $_.Exception.Message
            Add-Content -Path $logFilePath -Value ("{0} - INFO: AD lookup failed for {1}: {2}" -f (Get-Date), $sam, $errMsg)
            
            # Check if AD is unreachable (critical error) vs user not found
            if ($errMsg -match 'Active Directory Web Services|Unable to find a default server|ADServerDownException') {
                [System.Windows.Forms.MessageBox]::Show("Cannot reach an Active Directory server (ADWS). Verify network/domain connectivity and try again.","AD server unreachable",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
                $tbTerm.Focus()
                return
            }
        }

        if (-not $termUser) {
            # User not found in AD - check Entra ID for cloud-only user
            Add-Content -Path $logFilePath -Value ("{0} - INFO: User not found in AD, checking Entra ID: {1}" -f (Get-Date), $sam)
            
            try {
                $cloudUser = $null
                
                # Strategy 1: If input contains @, treat as UPN or email
                if ($sam -like "*@*") {
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: Input contains @, searching by UPN or email: {1}" -f (Get-Date), $sam)
                    try {
                        $cloudUser = Get-MgUser -Filter "userPrincipalName eq '$sam' or mail eq '$sam'" -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction Stop
                    } catch {
                        # Filter may fail, try individual lookups
                        try {
                            $cloudUser = Get-MgUser -UserId $sam -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction SilentlyContinue
                        } catch {}
                    }
                } 
                
                # Strategy 2: If no @ or not found yet, try multiple approaches
                if (-not $cloudUser) {
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: Searching Entra ID by mailNickname: {1}" -f (Get-Date), $sam)
                    try {
                        # Try mailNickname (often matches SAM account)
                        $cloudUser = Get-MgUser -Filter "mailNickname eq '$sam'" -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction Stop
                    } catch {}
                }
                
                # Strategy 3: Try constructing UPN with AD domain
                if (-not $cloudUser -and $sam -notlike "*@*") {
                    $domain = (Get-ADDomain -ErrorAction SilentlyContinue).DNSRoot
                    if ($domain) {
                        $upnGuess = "$sam@$domain"
                        Add-Content -Path $logFilePath -Value ("{0} - INFO: Trying constructed UPN: {1}" -f (Get-Date), $upnGuess)
                        try {
                            $cloudUser = Get-MgUser -UserId $upnGuess -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction SilentlyContinue
                        } catch {}
                    }
                }
                
                # Strategy 4: Last resort - search by displayName starts with
                if (-not $cloudUser -and $sam -notlike "*@*") {
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: Trying displayName search: {1}" -f (Get-Date), $sam)
                    try {
                        $users = Get-MgUser -Filter "startswith(displayName,'$sam')" -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -Top 5 -ErrorAction Stop
                        if ($users -and $users.Count -eq 1) {
                            $cloudUser = $users[0]
                            Add-Content -Path $logFilePath -Value ("{0} - INFO: Found single match by displayName" -f (Get-Date))
                        } elseif ($users -and $users.Count -gt 1) {
                            Add-Content -Path $logFilePath -Value ("{0} - WARN: Multiple users found matching displayName, cannot auto-select" -f (Get-Date))
                        }
                    } catch {}
                }
                
                if ($cloudUser) {
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: Found cloud-only user in Entra ID: {1} (UPN: {2})" -f (Get-Date), $cloudUser.DisplayName, $cloudUser.UserPrincipalName)
                    
                    # Create a pseudo AD user object for cloud-only user
                    $termUser = [PSCustomObject]@{
                        SamAccountName = if ($cloudUser.MailNickname) { $cloudUser.MailNickname } else { $sam }
                        DisplayName = $cloudUser.DisplayName
                        UserPrincipalName = $cloudUser.UserPrincipalName
                        EmailAddress = if ($cloudUser.Mail) { $cloudUser.Mail } else { $cloudUser.UserPrincipalName }
                        Description = "Cloud-only user"
                        Enabled = $cloudUser.AccountEnabled
                        Manager = $null
                    }
                    $isCloudOnly = $true
                } else {
                    Add-Content -Path $logFilePath -Value ("{0} - WARN: User not found in AD or Entra ID: {1}" -f (Get-Date), $sam)
                    [System.Windows.Forms.MessageBox]::Show("User account not found in Active Directory or Entra ID:`n$sam`n`nTried searching by:`n- User Principal Name (UPN)`n- Email address`n- Mail nickname`n- Display name`n`nPlease verify the input and try again.","User not found",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
                    return
                }
            } catch {
                $cloudErr = $_.Exception.Message
                Add-Content -Path $logFilePath -Value ("{0} - ERROR: Entra ID lookup failed: {1}" -f (Get-Date), $cloudErr)
                [System.Windows.Forms.MessageBox]::Show("User not found in Active Directory.`n`nAttempted to check Entra ID but encountered an error:`n$cloudErr`n`nPlease verify Graph connection (Connect-MgGraph) and permissions.","Lookup Error",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
                return
            }
        }

        # Check if user is already disabled
        if ($termUser.Enabled -eq $false) {
            $accountType = if ($isCloudOnly) { "Entra ID" } else { "Active Directory" }
            [System.Windows.Forms.MessageBox]::Show("User '$($termUser.SamAccountName)' is already disabled in $accountType.`n`nCannot terminate an already disabled account.", "Account Already Disabled", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
            Add-Content -Path $logFilePath -Value ("{0} - WARN: Termination blocked - account already disabled: {1}" -f (Get-Date), $termUser.SamAccountName)
            
            # Reset form
            $tbTerm.Text = ""
            if ($script:lblContactValue) {
                $script:lblContactValue.Text = ""
                $script:lblContactValue.ForeColor = [System.Drawing.Color]::FromArgb(100,200,255)
                $script:lblContactValue.Tag = $null
            }
            try { $tbTerm.Focus() } catch {}
            return
        }

        # Check if user exists in Entra ID before proceeding
        $upn = $termUser.UserPrincipalName
        $entraExists = $false
        $entraUser = $null
        $upnMismatchWarning = ""
        
        if (![string]::IsNullOrWhiteSpace($upn)) {
            $entraCheck = Test-EntraIdUser -UserPrincipalName $upn
            $entraExists = $entraCheck.Exists
            $entraUser = $entraCheck.User
            
            # Check for UPN mismatch if found in Entra ID
            if ($entraExists -and -not $isCloudOnly) {
                $mismatchCheck = Test-EntraIdUpnMismatch -AdUpn $upn -EntraUser $entraUser
                if ($mismatchCheck.IsMismatch) {
                    $upnMismatchWarning = "`n`n⚠️ WARNING: UPN mismatch detected!`nAD UPN: $upn`nEntra UPN: $($mismatchCheck.EntraUpn)`n`nCloud operations will use: $($mismatchCheck.EntraUpn)"
                    Add-Content -Path $logFilePath -Value ("{0} - WARN: UPN mismatch for {1}: AD={2}, Entra={3}" -f (Get-Date), $termUser.SamAccountName, $upn, $mismatchCheck.EntraUpn)
                }
            }
            
            if (-not $entraExists) {
                # Show warning that cloud operations will be skipped
                $result = [System.Windows.Forms.MessageBox]::Show(
                    "User '$($termUser.SamAccountName)' ($upn) was not found in Entra ID.`n`nPossible reasons:`n- User not synced to cloud`n- Different UPN in Entra ID`n- User is on-premises only`n`nCloud operations (mailbox conversion, GAL hiding, MFA removal) will be skipped.`n`nDo you want to continue with on-premises termination only?",
                    "User Not Found in Entra ID",
                    [System.Windows.Forms.MessageBoxButtons]::YesNo,
                    [System.Windows.Forms.MessageBoxIcon]::Warning
                )
                
                if ($result -ne [System.Windows.Forms.DialogResult]::Yes) {
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: User cancelled termination due to Entra ID absence" -f (Get-Date))
                    return
                }
            }
        } else {
            # No UPN - user is on-prem only
            Add-Content -Path $logFilePath -Value ("{0} - INFO: User {1} has no UPN - on-premises only account" -f (Get-Date), $termUser.SamAccountName)
            $result = [System.Windows.Forms.MessageBox]::Show(
                "User '$($termUser.SamAccountName)' does not have a UserPrincipalName.`n`nThis is an on-premises only account. Cloud operations will be skipped.`n`nDo you want to continue with on-premises termination only?",
                "On-Premises Only Account",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            
            if ($result -ne [System.Windows.Forms.DialogResult]::Yes) {
                Add-Content -Path $logFilePath -Value ("{0} - INFO: User cancelled on-prem only termination" -f (Get-Date))
                return
            }
        }

        # Auto-populate contact from manager if not provided
        if (-not $contact -and $termUser.Manager) {
            try {
                # Extract SAMAccountName from manager DN
                $managerUser = Get-ADUser -Identity $termUser.Manager -Properties SamAccountName,DisplayName -ErrorAction Stop
                $contact = $managerUser.SamAccountName
                Add-Content -Path $logFilePath -Value ("{0} - INFO: Auto-populated contact from manager: {1} ({2})" -f (Get-Date), $contact, $managerUser.DisplayName)
                # Update the contact label UI
                if ($script:lblContactValue) {
                    $script:lblContactValue.Text = "$($managerUser.DisplayName) ($($managerUser.SamAccountName))"
                    $script:lblContactValue.ForeColor = [System.Drawing.Color]::FromArgb(100,255,100)
                    $script:lblContactValue.Tag = $contact
                }
            } catch {
                Add-Content -Path $logFilePath -Value ("{0} - WARN: Could not retrieve manager for auto-populate: {1}" -f (Get-Date), $_.Exception.Message)
                # Continue without contact - it's optional
            }
        }

        # Lookup contact user if provided
        $contactUser = $null
        if ($contact) {
            try {
                $contactUser = Get-ADUser -Filter "SamAccountName -eq '$contact'" -Properties SamAccountName,DisplayName,UserPrincipalName,TelephoneNumber -ErrorAction Stop
            } catch {
                $errMsg = $_.Exception.Message
                Add-Content -Path $logFilePath -Value ("{0} - ERROR: AD lookup for contact user failed: {1}" -f (Get-Date), $errMsg)
                if ($errMsg -match 'Active Directory Web Services|Unable to find a default server|ADServerDownException') {
                    [System.Windows.Forms.MessageBox]::Show("Cannot reach an Active Directory server (ADWS). Verify network/domain connectivity and try again.","AD server unreachable",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
                } else {
                    [System.Windows.Forms.MessageBox]::Show("Error looking up contact user:`n$errMsg","AD lookup error",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
                }
                return
            }

            if (-not $contactUser) {
                Add-Content -Path $logFilePath -Value ("{0} - WARN: Contact account not found: {1}" -f (Get-Date), $contact)
                [System.Windows.Forms.MessageBox]::Show("Contact account not found in AD:`n$contact","User not found",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
                return
            }
        }

        # Both users validated ? update UI and log; proceed with worker invocation as needed
        # Update UI and log
        if ($null -ne $script:statusLabel -and $script:statusLabel -is [System.Windows.Forms.Label]) {
            if ($contactUser) {
                $script:statusLabel.Text = ("Validated: {0}  |  Contact: {1}" -f $termUser.SamAccountName, $contactUser.SamAccountName)
            } else {
                $script:statusLabel.Text = ("Validated: {0}  |  Contact: <none>" -f $termUser.SamAccountName)
            }
        }
        if ($null -ne $script:labelInternal -and $script:labelInternal -is [System.Windows.Forms.Label]) {
            $script:labelInternal.Text = ("{0} - Ready to offboard {1} (DisplayName: {2})" -f (Get-Date), $termUser.SamAccountName, ($termUser.DisplayName -or '<no display name>'))
        }
        
        if ($contactUser) {
            Add-Content -Path $logFilePath -Value ("{0} - INFO: Validated users: {1} (terminated), {2} (contact)" -f (Get-Date), $termUser.SamAccountName, $contactUser.SamAccountName)
        } else {
            Add-Content -Path $logFilePath -Value ("{0} - INFO: Validated user: {1} (terminated), no contact specified" -f (Get-Date), $termUser.SamAccountName)
        }

        # Show confirmation dialog before proceeding
        $accountType = if ($isCloudOnly) { "Cloud-Only (Entra ID)" } elseif ($entraExists) { "Hybrid (AD + Entra ID)" } else { "On-Premises (AD Only)" }
        $confirmMsg = "Are you sure you want to terminate access for:`n`n"
        $confirmMsg += "User: $($termUser.DisplayName)`n"
        $confirmMsg += "Account: $($termUser.SamAccountName)`n"
        if ($termUser.UserPrincipalName) {
            $confirmMsg += "UPN: $($termUser.UserPrincipalName)`n"
        }
        $confirmMsg += "Type: $accountType`n"
        if ($contactUser) {
            $confirmMsg += "Contact: $($contactUser.DisplayName) ($($contactUser.SamAccountName))`n"
        }
        $confirmMsg += "`nThis will:`n"
        if (-not $isCloudOnly) {
            $confirmMsg += "• Disable AD account`n"
        }
        if ($entraExists -or $isCloudOnly) {
            $confirmMsg += "• Disable Entra ID account`n"
            $confirmMsg += "• Remove MFA methods`n"
            $confirmMsg += "• Revoke all sessions`n"
            $confirmMsg += "• Remove registered devices`n"
            $confirmMsg += "• Remove licenses`n"
        }
        if ($upnMismatchWarning) {
            $confirmMsg += $upnMismatchWarning
        }
        
        $confirmResult = [System.Windows.Forms.MessageBox]::Show(
            $confirmMsg,
            "Confirm Termination",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
        
        if ($confirmResult -ne [System.Windows.Forms.DialogResult]::Yes) {
            Add-Content -Path $logFilePath -Value ("{0} - INFO: User cancelled termination for: {1}" -f (Get-Date), $termUser.SamAccountName)
            return
        }

        # Proceed with termination - Entra ID verification already done above
        # Disable the terminated user account
            $disableSuccess = $false
            $descriptionSuccess = $false
            $managerSuccess = $false
            $mailboxSuccess = $false
            $galSuccess = $false
            $errors = @()

            if (-not $isCloudOnly) {
                # Step 1: Disable AD account (CRITICAL - must succeed for hybrid users)
                try {
                    Disable-ADAccount -Identity $termUser.SamAccountName -ErrorAction Stop
                    $disableSuccess = $true
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: Disabled AD account: {1}" -f (Get-Date), $termUser.SamAccountName)
                } catch {
                    $disableErr = $_.Exception.Message
                    Add-Content -Path $logFilePath -Value ("{0} - ERROR: Failed to disable account: {1} - {2}" -f (Get-Date), $termUser.SamAccountName, $disableErr)
                    [System.Windows.Forms.MessageBox]::Show("CRITICAL: Failed to disable AD account:`n$disableErr`n`nTermination aborted.","Disable Error",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
                    return
                }

                # Step 2: Update description (non-critical)
                try {
                    $currentLoginUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
                    $currentDateTime = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
                    $existingDescription = $termUser.Description
                    $newDescription = if ($existingDescription) {
                        "$($existingDescription) | Disabled by $currentLoginUser on $currentDateTime"
                    } else {
                        "Disabled by $currentLoginUser on $currentDateTime"
                    }
                    Set-ADUser -Identity $termUser.SamAccountName -Description $newDescription -ErrorAction Stop
                    $descriptionSuccess = $true
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: Updated description for: {1}" -f (Get-Date), $termUser.SamAccountName)
                } catch {
                    $errors += "Description update failed: $($_.Exception.Message)"
                    Add-Content -Path $logFilePath -Value ("{0} - WARN: Failed to update description: {1} - {2}" -f (Get-Date), $termUser.SamAccountName, $_.Exception.Message)
                }

                # Step 3: Clear manager (non-critical)
                try {
                    Set-ADUser -Identity $termUser.SamAccountName -Clear manager -ErrorAction Stop
                    $managerSuccess = $true
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: Cleared manager for: {1}" -f (Get-Date), $termUser.SamAccountName)
                } catch {
                    $errors += "Clear manager failed: $($_.Exception.Message)"
                    Add-Content -Path $logFilePath -Value ("{0} - WARN: Failed to clear manager: {1} - {2}" -f (Get-Date), $termUser.SamAccountName, $_.Exception.Message)
                }
            } else {
                # Cloud-only user - disable in Entra ID
                Add-Content -Path $logFilePath -Value ("{0} - INFO: Processing cloud-only user: {1}" -f (Get-Date), $termUser.SamAccountName)
                
                try {
                    Update-MgUser -UserId $termUser.UserPrincipalName -AccountEnabled:$false -ErrorAction Stop
                    $disableSuccess = $true
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: Disabled Entra ID account: {1}" -f (Get-Date), $termUser.UserPrincipalName)
                } catch {
                    $disableErr = $_.Exception.Message
                    Add-Content -Path $logFilePath -Value ("{0} - ERROR: Failed to disable Entra ID account: {1} - {2}" -f (Get-Date), $termUser.UserPrincipalName, $disableErr)
                    
                    # Check if this is an authorization/role issue
                    if ($disableErr -match "Authorization_RequestDenied|Insufficient privileges|Access is denied|Forbidden") {
                        # This is an Azure AD role issue, not a scope issue
                        $errorMsg = "CRITICAL: Cannot disable Entra ID user - Insufficient Azure AD role permissions.`n`n" +
                                    "Error: $disableErr`n`n" +
                                    "CAUSE: Your account lacks the required Azure AD administrative role.`n`n" +
                                    "Graph API scopes (User.ReadWrite.All) only grant API access.`n" +
                                    "You also need an Azure AD role to actually disable users.`n`n" +
                                    "Required Azure AD Roles (one of):`n" +
                                    "• User Administrator`n" +
                                    "• Privileged Authentication Administrator`n" +
                                    "• Global Administrator`n`n" +
                                    "SOLUTION:`n" +
                                    "1. Go to Azure Portal (portal.azure.com)`n" +
                                    "2. Navigate to: Entra ID > Roles and administrators`n" +
                                    "3. Find 'User Administrator' role`n" +
                                    "4. Add your account as a member`n" +
                                    "5. Wait a few minutes for the role to take effect`n" +
                                    "6. Disconnect and reconnect to Graph`n" +
                                    "7. Try termination again`n`n" +
                                    "Alternatively, ask your Global Administrator to perform this termination.`n`n" +
                                    "Termination aborted."
                    } else {
                        $errorMsg = "CRITICAL: Failed to disable Entra ID account:`n`n$disableErr`n`nTermination aborted."
                    }
                    [System.Windows.Forms.MessageBox]::Show($errorMsg,"Disable Error",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
                    return
                }
                
                # Mark description and manager as success (not applicable for cloud-only)
                $descriptionSuccess = $true
                $managerSuccess = $true
            }
            
            # Step 4 & 5: Cloud operations (only if user exists in Entra ID AND has mailbox)
            $mailboxOperationsSkipped = $false
            if ($entraExists -or $isCloudOnly) {
                # Check if mailbox exists first
                $hasMailbox = Test-UserHasMailbox -UserPrincipalName $termUser.UserPrincipalName
                
                if (-not $hasMailbox) {
                    $mailboxOperationsSkipped = $true
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: User {1} has no Exchange mailbox, skipping mailbox operations" -f (Get-Date), $termUser.SamAccountName)
                    Write-StructuredLog -Message "Skipping Exchange operations - no mailbox assigned" -Level 'INFO' -Category 'Exchange' -Data @{User=$termUser.SamAccountName}
                } else {
                    # Validate Exchange Online connection
                    if (-not (Assert-ExchangeOnlineConnection)) {
                        $errors += "Exchange Online connection unavailable - mailbox operations skipped"
                        Write-StructuredLog -Message "EXO connection unavailable, skipping mailbox operations" -Level 'WARN' -Category 'Exchange' -Data @{User=$termUser.SamAccountName}
                    } else {
                        # Convert mailbox to shared (non-critical)
                        try {
                            Set-Mailbox -Identity $termUser.EmailAddress -Type Shared -ErrorAction Stop
                            $mailboxSuccess = $true
                            Add-Content -Path $logFilePath -Value ("{0} - INFO: Converted mailbox to shared for: {1}" -f (Get-Date), $termUser.SamAccountName)
                        } catch {
                            $errors += "Mailbox conversion failed: $($_.Exception.Message)"
                            Add-Content -Path $logFilePath -Value ("{0} - WARN: Failed to convert mailbox: {1} - {2}" -f (Get-Date), $termUser.SamAccountName, $_.Exception.Message)
                        }

                        # Hide from GAL (non-critical, different approach for cloud-only vs hybrid)
                        try {
                            if (-not $isCloudOnly) {
                                # Hybrid user - update AD attribute
                                Get-ADUser -Identity $termUser.SamAccountName | Set-ADObject -Replace @{msExchHideFromAddressLists=$true} -ErrorAction Stop
                            } else {
                                # Cloud-only user - update Exchange Online directly
                                Set-Mailbox -Identity $termUser.EmailAddress -HiddenFromAddressListsEnabled $true -ErrorAction Stop
                            }
                            $galSuccess = $true
                            Add-Content -Path $logFilePath -Value ("{0} - INFO: Hidden from GAL: {1}" -f (Get-Date), $termUser.SamAccountName)
                        } catch {
                            $errors += "Hide from GAL failed: $($_.Exception.Message)"
                            Add-Content -Path $logFilePath -Value ("{0} - WARN: Failed to hide from GAL: {1} - {2}" -f (Get-Date), $termUser.SamAccountName, $_.Exception.Message)
                        }
                    }
                }
            }

            # Show warnings if any non-critical operations failed
            if ($errors.Count -gt 0) {
                $warningMsg = "Account disabled successfully, but some operations failed:`n`n" + ($errors -join "`n")
                [System.Windows.Forms.MessageBox]::Show($warningMsg,"Partial Success",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
            }
           
            # Compose default auto-reply message
            $TerminateFullName = $termUser.DisplayName
            if ($contactUser) {
                $ContactInfo = $contactUser.DisplayName
                $Contactemail = $contactUser.UserPrincipalName
                $ContactPhone = $contactUser.TelephoneNumber
                $defaultAutoReply = "Thank you for contacting $TerminateFullName. This message is to inform you that $TerminateFullName is no longer a member of the Organization. For any official matters please contact $ContactInfo at $Contactemail" + $(if ($ContactPhone) { " or $ContactPhone" } else { "" }) + ". Thank you."
            } else {
                $defaultAutoReply = "Thank you for contacting $TerminateFullName. This message is to inform you that $TerminateFullName is no longer a member of the Organization. Thank you."
            }

            # Set auto-reply for the terminated user (only if user exists in Entra ID AND has a mailbox)
            $autoReplySet = $false
            if (($entraExists -or $isCloudOnly) -and -not $mailboxOperationsSkipped) {
                # Check if mailbox exists using cached function (re-check in case it wasn't checked above)
                if (-not $hasMailbox) {
                    $hasMailbox = Test-UserHasMailbox -UserPrincipalName $termUser.UserPrincipalName
                }

                if ($hasMailbox) {
                    # Mailbox exists, proceed with auto-reply
                    $dialogTitle = "Edit auto-reply message"
                    if ($upnMismatchWarning) {
                        $dialogTitle += " - UPN Mismatch Detected"
                    }
                    $AutoReplyMessage = Show-AutoReplyDialog -DefaultMessage $defaultAutoReply -Title $dialogTitle -Owner $form
                    if ($null -eq $AutoReplyMessage) {
                        [System.Windows.Forms.MessageBox]::Show("Operation cancelled by user.", "Cancelled")
                        return
                    }
                    
                    # Show UPN mismatch warning if present
                    if ($upnMismatchWarning) {
                        $result = [System.Windows.Forms.MessageBox]::Show(
                            "UPN Mismatch Detected$upnMismatchWarning`n`nDo you want to continue?",
                            "UPN Mismatch Warning",
                            [System.Windows.Forms.MessageBoxButtons]::YesNo,
                            [System.Windows.Forms.MessageBoxIcon]::Warning
                        )
                        if ($result -ne [System.Windows.Forms.DialogResult]::Yes) {
                            return
                        }
                    }
                    
                    if ([string]::IsNullOrWhiteSpace($AutoReplyMessage)) { $AutoReplyMessage = $defaultAutoReply }

                    # Display the chosen auto-reply in a label below (create if not exists)
                    if (-not $script:AutoReplyDisplayLabel) {
                        $lblDisplay = New-Object System.Windows.Forms.Label
                        $lblDisplay.Text = $AutoReplyMessage
                        $lblDisplay.Font = New-Object System.Drawing.Font("Segoe UI",10)
                        $lblDisplay.ForeColor = [System.Drawing.Color]::White
                        $lblDisplay.AutoSize = $true
                        $lblDisplay.Location = New-Object System.Drawing.Point(20,420)
                        $form.Controls.Add($lblDisplay)
                        $script:AutoReplyDisplayLabel = $lblDisplay
                    } else {
                        $script:AutoReplyDisplayLabel.Text = $AutoReplyMessage
                    }

                    try {
                        Set-MailboxAutoReplyConfiguration -Identity $termUser.UserPrincipalName -AutoReplyState Enabled -InternalMessage $AutoReplyMessage -ExternalMessage $AutoReplyMessage -ErrorAction Stop
                        $autoReplySet = $true
                        Add-Content -Path $logFilePath -Value ("{0} - INFO: Set auto-reply for {1}" -f (Get-Date), $termUser.UserPrincipalName)
                    } catch {
                        $arErr = $_.Exception.Message
                        Add-Content -Path $logFilePath -Value ("{0} - WARN: Failed to set auto-reply for {1} - {2}" -f (Get-Date), $termUser.UserPrincipalName, $arErr)
                        $warnResult = [System.Windows.Forms.MessageBox]::Show("Failed to set auto-reply:`n`n$arErr`n`nContinue with termination?","Auto-reply Warning",[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)
                        if ($warnResult -ne [System.Windows.Forms.DialogResult]::Yes) {
                            [System.Windows.Forms.MessageBox]::Show("Termination cancelled by user.","Cancelled",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information)
                            return
                        }
                    }
                } else {
                    # No mailbox found - skip auto-reply and notify user
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: User {1} has no mailbox, proceeding with AD-only termination" -f (Get-Date), $termUser.SamAccountName)
                }
                
                # Show waiting label (regardless of mailbox/auto-reply status)
                if (-not $script:WaitingLabel) {
                    $WaitingLabel = New-Object System.Windows.Forms.Label
                    $WaitingLabel.Text = "Waiting for access termination to complete..."
                    $WaitingLabel.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
                    $WaitingLabel.ForeColor = [System.Drawing.Color]::LimeGreen
                    $WaitingLabel.AutoSize = $true
                    $WaitingLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
                    $WaitingLabel.Location = New-Object System.Drawing.Point(20,460)
                    $form.Controls.Add($WaitingLabel)
                    $script:WaitingLabel = $WaitingLabel
                } else {
                    $script:WaitingLabel.Text = "Waiting for access termination to complete..."
                    $script:WaitingLabel.Visible = $true
                }
                $form.Refresh()
            } else {
                Add-Content -Path $logFilePath -Value ("{0} - INFO: Skipped auto-reply for {1} (on-prem only user)" -f (Get-Date), $termUser.SamAccountName)
            }


            # Remove all group memberships except Domain Users (skip for cloud-only users)
            if (-not $isCloudOnly) {
                try {
                    # Get primary group ID to avoid removing it
                    $primaryGroupId = (Get-ADUser -Identity $termUser.SamAccountName -Properties PrimaryGroupID).PrimaryGroupID
                    $primaryGroup = Get-ADGroup -Filter "ObjectSID -like '*-$primaryGroupId'"
                    
                    $groups = Get-ADUser -Identity $termUser.SamAccountName -Property MemberOf | Select-Object -ExpandProperty MemberOf
                    $removedCount = 0
                    foreach ($group in $groups) {
                        # Skip if this is the primary group
                        if ($primaryGroup -and $group -eq $primaryGroup.DistinguishedName) {
                            Write-StructuredLog -Message "Skipping primary group removal" -Level 'DEBUG' -Category 'ActiveDirectory' -Data @{Group=$group}
                            continue
                        }
                        
                        try {
                            Remove-ADGroupMember -Identity $group -Members $termUser.SamAccountName -Confirm:$false -ErrorAction Stop
                            $removedCount++
                        } catch {
                            Write-StructuredLog -Message "Failed to remove group membership" -Level 'WARN' -Category 'ActiveDirectory' -Data @{Group=$group; Error=$_.Exception.Message}
                        }
                    }
                    Write-StructuredLog -Message "Group memberships removed" -Level 'INFO' -Category 'ActiveDirectory' -Data @{
                        User = $termUser.SamAccountName
                        TotalGroups = $groups.Count
                        RemovedCount = $removedCount
                    }
                } catch {
                    $groupErr = $_.Exception.Message
                    Add-Content -Path $logFilePath -Value ("{0} - ERROR: Failed to remove group memberships for {1} - {2}" -f (Get-Date), $termUser.SamAccountName, $groupErr)
                    [System.Windows.Forms.MessageBox]::Show("Failed to remove group memberships:`n$groupErr","Group Removal Error",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
                }
            } else {
                Add-Content -Path $logFilePath -Value ("{0} - INFO: Skipped AD group removal for cloud-only user: {1}" -f (Get-Date), $termUser.SamAccountName)
                Write-StructuredLog -Message "Skipping AD group removal - cloud-only user" -Level 'INFO' -Category 'EntraID' -Data @{User=$termUser.SamAccountName}
            }

            $TerminatEmail = $termUser.EmailAddress

            # Remove devices and auth methods only if user exists in Entra ID
            if (($entraExists -or $isCloudOnly) -and -not [string]::IsNullOrWhiteSpace($TerminatEmail)) { 
                $userId = $TerminatEmail 

                if (-not [string]::IsNullOrWhiteSpace($userId)) {
                    try {
                        $devices = Get-MgUserRegisteredDevice -UserId $userId
                        if ($devices) {
                            foreach ($device in $devices) {
                                try { 
                                    Remove-MgDevice -DeviceId $device.Id 
                                    Write-StructuredLog -Message "Device removed" -Level 'INFO' -Category 'EntraID' -Data @{DeviceId=$device.Id; User=$userId}
                                } catch { 
                                    Write-StructuredLog -Message "Failed to remove device" -Level 'WARN' -Category 'EntraID' -Data @{DeviceId=$device.Id; User=$userId; Error=$_.Exception.Message}
                                }
                            }
                        } else { 
                            Write-StructuredLog -Message "No registered devices found" -Level 'INFO' -Category 'EntraID' -Data @{User=$userId}
                        }
                    } catch {
                        Write-StructuredLog -Message "Device enumeration failed" -Level 'WARN' -Category 'EntraID' -Data @{User=$userId; Error=$_.Exception.Message}
                    }
                } else {
                    Write-StructuredLog -Message "Skipping device removal - empty userId" -Level 'DEBUG' -Category 'EntraID'
                }

                if (-not [string]::IsNullOrWhiteSpace($userId)) {
                    try {
                        $methods = Get-MgUserAuthenticationMethod -UserId $userId
                        $count = 0
                        if ($methods) { $count = $methods.Count }
                        Write-StructuredLog -Message "Authentication methods found" -Level 'INFO' -Category 'MFA' -Data @{User=$userId; Count=$count}

                        if ($methods) {
                            foreach ($authMethod in $methods) {
                                Remove-UserAuthenticationMethod -UserId $userId -Method $authMethod | Out-Null
                            }
                        }

                        Write-StructuredLog -Message "Rechecking authentication methods" -Level 'DEBUG' -Category 'MFA' -Data @{User=$userId}
                        $methods = Get-MgUserAuthenticationMethod -UserId $userId
                        $count2 = 0
                        if ($methods) { $count2 = $methods.Count }
                        Write-StructuredLog -Message "Authentication methods remaining after cleanup" -Level 'INFO' -Category 'MFA' -Data @{User=$userId; Count=$count2}
                    } catch {
                        Write-StructuredLog -Message "Authentication method cleanup failed" -Level 'WARN' -Category 'MFA' -Data @{User=$userId; Error=$_.Exception.Message}
                    }
                } else {
                    Write-StructuredLog -Message "Skipping authentication method cleanup - empty userId" -Level 'DEBUG' -Category 'MFA'
                }
            } else {
                if (!$entraExists -and !$isCloudOnly) {
                    Add-Content -Path $logFilePath -Value ("{0} - INFO: Skipped device and MFA removal for {1} (on-prem only user)" -f (Get-Date), $termUser.SamAccountName)
                    Write-StructuredLog -Message "Skipping device and auth cleanup - on-premises only user" -Level 'INFO' -Category 'Hybrid' -Data @{User=$termUser.SamAccountName}
                } else {
                    Write-StructuredLog -Message "Skipping device and auth cleanup - empty email address" -Level 'DEBUG' -Category 'Hybrid' -Data @{User=$termUser.SamAccountName}
                }
            }

            # Export single termination to CSV report
            try {
                if (-not (Test-Path $ReportFolder)) {
                    New-Item -Path $ReportFolder -ItemType Directory -Force | Out-Null
                }
                
                $csvPath = Join-Path $ReportFolder $SingleTerminationReport
                $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
                $completionTime = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
                
                $reportItem = [PSCustomObject]@{
                    SamAccountName = $termUser.SamAccountName
                    DisplayName = $termUser.DisplayName
                    UserPrincipalName = $termUser.UserPrincipalName
                    Status = "Disabled"
                    DisabledBy = $currentUser
                    DisabledDate = $completionTime
                    AccountType = if ($isCloudOnly) { "Cloud-Only (Entra ID)" } elseif ($entraExists) { "Hybrid (AD + Entra ID)" } else { "On-Premises Only (AD)" }
                    CloudOperations = if ($mailboxOperationsSkipped) { "Completed (No Mailbox)" } elseif ($entraExists -or $isCloudOnly) { "Completed" } else { "Skipped (On-Prem Only)" }
                    ContactUser = if ($contactUser) { $contactUser.SamAccountName } else { "N/A" }
                }
                
                # Append to existing file or create new one
                if (Test-Path $csvPath) {
                    $reportItem | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8 -Append
                } else {
                    $reportItem | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
                }
                
                Add-Content -Path $logFilePath -Value ("{0} - INFO: Single termination report updated: {1}" -f (Get-Date), $csvPath)
            } catch {
                Add-Content -Path $logFilePath -Value ("{0} - ERROR: Failed to export single termination report: {1}" -f (Get-Date), $_.Exception.Message)
            }

            # Show message box to inform operator at the very end
            $TerminateFullName = $termUser.DisplayName
            if ($isCloudOnly) {
                # Cloud-only user termination
                $statusDetails = @()
                $statusDetails += "✓ Entra ID account disabled"
                
                if ($mailboxOperationsSkipped) {
                    $statusDetails += ""
                    $statusDetails += "ℹ️ Exchange operations skipped:"
                    $statusDetails += "  Account exists in Entra ID but has no Exchange mailbox assigned."
                    $statusDetails += "  Mailbox conversion, GAL hiding, and auto-reply not needed."
                } else {
                    if ($mailboxSuccess) { $statusDetails += "✓ Mailbox converted to shared" }
                    if ($autoReplySet) { $statusDetails += "✓ Auto-reply configured" }
                    if ($galSuccess) { $statusDetails += "✓ Hidden from GAL" }
                }
                
                $statusMsg = "Cloud-only user account terminated: $TerminateFullName`n`nOperations completed:`n" + ($statusDetails -join "`n")
                [System.Windows.Forms.MessageBox]::Show($statusMsg, "Access Terminated (Cloud-Only)", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
                
                # Reset form after termination
                $tbTerm.Text = ""
                if ($script:lblContactValue) {
                    $script:lblContactValue.Text = ""
                    $script:lblContactValue.ForeColor = [System.Drawing.Color]::FromArgb(100,200,255)
                    $script:lblContactValue.Tag = $null
                }
                $lblChosen.Text = "No file selected"
                $lblChosen.ForeColor = [System.Drawing.Color]::Gainsboro
                $grid.Rows.Clear()
                $btnRun.Enabled = $false
                $stLabel.Text = "Ready"
                $stLabel.ForeColor = [System.Drawing.Color]::FromArgb(100,220,100)
                try { $tbTerm.Focus() } catch {}
            } elseif ($entraExists) {
                # Hybrid user termination (AD + Entra)
                # Build status message based on what actually happened
                $statusDetails = @()
                $statusDetails += "✓ AD account disabled"
                
                if ($mailboxOperationsSkipped) {
                    $statusDetails += ""
                    $statusDetails += "ℹ️ Exchange operations skipped:"
                    $statusDetails += "  Account exists in Entra ID but has no Exchange mailbox assigned."
                    $statusDetails += "  Mailbox conversion, GAL hiding, and auto-reply not needed."
                } else {
                    if ($mailboxSuccess) { $statusDetails += "✓ Mailbox converted to shared" }
                    if ($autoReplySet) { $statusDetails += "✓ Auto-reply configured" }
                    if ($galSuccess) { $statusDetails += "✓ Hidden from GAL" }
                }
                
                $statusMsg = "User account terminated: $TerminateFullName`n`nOperations completed:`n" + ($statusDetails -join "`n")
                if ($errors.Count -eq 0) {
                    $statusMsg += "`n`nIf ADATT isn't running under a tiered admin account, manually move the terminated user into the Disabled OU."
                }
                [System.Windows.Forms.MessageBox]::Show($statusMsg, "Access Terminated", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
                
                # Reset form after termination
                $tbTerm.Text = ""
                if ($script:lblContactValue) {
                    $script:lblContactValue.Text = ""
                    $script:lblContactValue.ForeColor = [System.Drawing.Color]::FromArgb(100,200,255)
                    $script:lblContactValue.Tag = $null
                }
                $lblChosen.Text = "No file selected"
                $lblChosen.ForeColor = [System.Drawing.Color]::Gainsboro
                $grid.Rows.Clear()
                $btnRun.Enabled = $false
                $stLabel.Text = "Ready"
                $stLabel.ForeColor = [System.Drawing.Color]::FromArgb(100,220,100)
                try { $tbTerm.Focus() } catch {}
            } else {
                # On-prem only user termination
                [System.Windows.Forms.MessageBox]::Show("User account $TerminateFullName has been disabled (on-premises only).`n`nNote: User was not found in Entra ID, so cloud operations (mailbox, GAL, MFA) were skipped.`n`nIf ADATT isn't running under a tiered admin account, manually move the terminated user into the Disabled OU.", "Access Terminated (On-Prem Only)", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
                
                # Reset form after termination
                $tbTerm.Text = ""
                if ($script:lblContactValue) {
                    $script:lblContactValue.Text = ""
                    $script:lblContactValue.ForeColor = [System.Drawing.Color]::FromArgb(100,200,255)
                    $script:lblContactValue.Tag = $null
                }
                $lblChosen.Text = "No file selected"
                $lblChosen.ForeColor = [System.Drawing.Color]::Gainsboro
                $grid.Rows.Clear()
                $btnRun.Enabled = $false
                $stLabel.Text = "Ready"
                $stLabel.ForeColor = [System.Drawing.Color]::FromArgb(100,220,100)
                try { $tbTerm.Focus() } catch {}
            }

    } catch {
        Add-Content -Path $logFilePath -Value ("{0} - ERROR: Unexpected error in Submit handler: {1}" -f (Get-Date), $_)
        [System.Windows.Forms.MessageBox]::Show("Unexpected error: $($_)","Error",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
    }
})

#endregion

#region ----- Bulk Offboarding Workflow -----
$bulkList = New-Object System.Collections.Generic.List[Object]

$btnChoose.add_Click({
  try {
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Title = "Select bulk termination input file"
    $ofd.Filter = "Text / CSV (*.txt;*.csv)|*.txt;*.csv|All Files (*.*)|*.*"
    if ($ofd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
    
    $lblChosen.Text = $ofd.FileName
    $stLabel.Text = "Parsing file?"
    $grid.Rows.Clear()
    $bulkList.Clear()

    # Build list of candidate sAMAccountNames from TXT or CSV (using ADATT.ps1 logic)
    $entries = @()
    $searchHint = $null
    try {
        $ext = [System.IO.Path]::GetExtension($ofd.FileName)
    } catch { $ext = $null }
    
    if ($ext -and $ext.Equals('.csv',[System.StringComparison]::OrdinalIgnoreCase)) {
        try {
            $csv = Import-Csv -LiteralPath $ofd.FileName -ErrorAction Stop
            if ($csv) {
                $allCols = $csv | Get-Member -MemberType NoteProperty
                $col = $null
                $searchHint = $null
                
                # Try SamAccountName first
                $samCol = ($allCols | Where-Object { $_.Name -ieq 'SamAccountName' } | Select-Object -First 1).Name
                if ($samCol) {
                    $hasValues = $csv | Where-Object { $null -ne $_.$samCol -and $_.$samCol -ne '' -and ($_.$samCol).ToString().Trim() -ne '' } | Select-Object -First 1
                    if ($hasValues) {
                        $col = $samCol
                        $searchHint = 'SamAccountName'
                    }
                }
                
                # Try Username variations if SamAccountName not found or empty
                if (-not $col) {
                    $userCol = ($allCols | Where-Object { $_.Name -imatch '^(UserName|Username|User|Sam|Account|AccountName)$' } | Select-Object -First 1).Name
                    if ($userCol) {
                        $hasValues = $csv | Where-Object { $null -ne $_.$userCol -and $_.$userCol -ne '' -and ($_.$userCol).ToString().Trim() -ne '' } | Select-Object -First 1
                        if ($hasValues) {
                            $col = $userCol
                            $searchHint = 'SamAccountName'
                        }
                    }
                }
                
                # Try DisplayName if no SamAccountName-like column found or all empty
                if (-not $col) {
                    $dispCol = ($allCols | Where-Object { $_.Name -ieq 'DisplayName' } | Select-Object -First 1).Name
                    if ($dispCol) {
                        $hasValues = $csv | Where-Object { $null -ne $_.$dispCol -and $_.$dispCol -ne '' -and ($_.$dispCol).ToString().Trim() -ne '' } | Select-Object -First 1
                        if ($hasValues) {
                            $col = $dispCol
                            $searchHint = 'DisplayName'
                        }
                    }
                }
                
                if ($col) {
                    $entries = @($csv | ForEach-Object { 
                        if ($null -ne $_.$col -and $_.$col -ne '') {
                            $val = ($_.$col).ToString().Trim()
                            if ($val -ne '') { $val }
                        }
                    } | Where-Object { $_ -and $_.Length -gt 0 })
                } else {
                    # Fall back: if CSV has a single column, use it
                    $cols = ($csv | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name)
                    if ($cols.Count -eq 1) {
                        $only = $cols[0]
                        $entries = @($csv | ForEach-Object { 
                            if ($null -ne $_.$only -and $_.$only -ne '') {
                                $val = ($_.$only).ToString().Trim()
                                if ($val -ne '') { $val }
                            }
                        } | Where-Object { $_ -and $_.Length -gt 0 })
                    } else {
                        $formatMsg = "CSV file must include a column named: SamAccountName, Username, or DisplayName.`n`nYour CSV has multiple columns but none are recognized."
                        [System.Windows.Forms.MessageBox]::Show($formatMsg,"CSV Format Error",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
                        $stLabel.Text = "Ready"
                        return
                    }
                }
            }
        } catch {
            $errorMsg = $_.Exception.Message
            [System.Windows.Forms.MessageBox]::Show("Failed to parse CSV file.`n`nError: $errorMsg","CSV Parsing Error",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
            $stLabel.Text = "Ready"
            return
        }
    } else {
        # TXT mode: one sAMAccountName per line; skip common header names
        $entries = Get-Content -LiteralPath $ofd.FileName -ErrorAction Stop |
                   ForEach-Object { $_.Trim() } |
                   Where-Object { $_ -and ($_ -notmatch '^(?i)SamAccountName$') } |
                   Select-Object -Unique
    }

    if (-not $entries -or $entries.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("The selected file is empty or contains no valid entries.","File Empty",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information)
        $stLabel.Text = "Ready"
        return
    }

    # Resolve each entry as sAMAccountName and collect OK candidates
    $okUsers = New-Object System.Collections.Generic.List[object]
    $skips   = New-Object System.Collections.Generic.List[object]
    foreach($line in $entries){
        try {
            $u = $null
            if ($searchHint -eq 'DisplayName') {
                try {
                    $matches = Get-ADUser -Filter "DisplayName -eq '$line'" -Properties SamAccountName,DisplayName,UserPrincipalName,TelephoneNumber -ErrorAction Stop
                    if ($matches -is [System.Array]) {
                        if ($matches.Count -eq 1) { $u = $matches[0] } else { $u = $null; $skips.Add([pscustomobject]@{ Input=$line; Reason='Ambiguous DisplayName' }); continue }
                    } else { $u = $matches }
                } catch { $u = $null }
            } elseif ($searchHint -eq 'SamAccountName' -or (-not $searchHint)) {
                if ($line -match '@') {
                    try { $u = Get-ADUser -Filter "UserPrincipalName -eq '$line'" -Properties SamAccountName,DisplayName,UserPrincipalName,TelephoneNumber -ErrorAction Stop } catch { $u = $null }
                } elseif ($line -match '\s') {
                    try {
                        $matches = Get-ADUser -Filter "DisplayName -eq '$line'" -Properties SamAccountName,DisplayName,UserPrincipalName,TelephoneNumber -ErrorAction Stop
                        if ($matches -is [System.Array]) {
                            if ($matches.Count -eq 1) { $u = $matches[0] } else { $u = $null; $skips.Add([pscustomobject]@{ Input=$line; Reason='Ambiguous DisplayName' }); continue }
                        } else { $u = $matches }
                    } catch { $u = $null }
                }
                if (-not $u) {
                    try { $u = Get-ADUser -Filter "SamAccountName -eq '$line'" -Properties SamAccountName,DisplayName,UserPrincipalName,TelephoneNumber -ErrorAction Stop } catch { $u = $null }
                }
            }
            if ($u) {
                $okUsers.Add([pscustomobject]@{
                    Sam = $u.SamAccountName
                    DisplayName = $u.DisplayName
                    Telephone = $u.TelephoneNumber
                    UPN = $u.UserPrincipalName
                })
            } else {
                $skips.Add([pscustomobject]@{ Input=$line; Reason='Not found' })
            }
        } catch {
            $skips.Add([pscustomobject]@{ Input=$line; Reason=$_.Exception.Message })
        }
    }

    # Check for already disabled accounts
    $alreadyDisabled = @()
    $activeUsers = [System.Collections.ArrayList]::new()
    
    foreach ($user in $okUsers) {
        try {
            $adUser = Get-ADUser -Identity $user.Sam -Properties Enabled -ErrorAction Stop
            $isAlreadyDisabled = ($adUser.Enabled -eq $false)
            
            if ($isAlreadyDisabled) {
                $alreadyDisabled += [pscustomobject]@{
                    Sam = $user.Sam
                    DisplayName = $user.DisplayName
                    Reason = "Account already disabled"
                }
            } else {
                [void]$activeUsers.Add($user)
            }
        } catch {
            [void]$activeUsers.Add($user)
        }
    }
    
    # If there are already disabled accounts, show them
    if ($alreadyDisabled.Count -gt 0) {
        $disabledList = ($alreadyDisabled | ForEach-Object { "  - $($_.Sam) ($($_.DisplayName)): $($_.Reason)" }) -join "`r`n"
        $disabledMessage = "The following $($alreadyDisabled.Count) account(s) are already disabled:`r`n`r`n$disabledList`r`n`r`n"
        
        if ($activeUsers.Count -eq 0) {
            [System.Windows.Forms.MessageBox]::Show(
                "$disabledMessage`r`nAll accounts in the bulk file are already disabled. No accounts to process.",
                "Bulk Termination - Already Disabled",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            # Clear the grid and reset state
            $grid.Rows.Clear()
            $script:bulkList.Clear()
            $btnRun.Enabled = $false
            $btnChoose.Text = 'Choose File...'
            $lblChosen.Text = 'No file selected'
            $stLabel.Text = "Ready"
            return
        } else {
            $result = [System.Windows.Forms.MessageBox]::Show(
                "$disabledMessage`r`n$($activeUsers.Count) active account(s) remain to be processed.`r`n`r`nDo you want to continue with the active accounts only?",
                "Bulk Termination - Some Already Disabled",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            )
            
            if ($result -ne [System.Windows.Forms.DialogResult]::Yes) {
                # Reset form and clear bulk preview when clicking No
                $grid.Rows.Clear()
                $script:bulkList.Clear()
                $btnRun.Enabled = $false
                $btnChoose.Text = 'Choose File...'
                $lblChosen.Text = 'No file selected'
                $lblChosen.ForeColor = [System.Drawing.Color]::Gainsboro
                $stLabel.Text = "Ready"
                $stLabel.ForeColor = [System.Drawing.Color]::FromArgb(100,220,100)
                return
            }
        }
    }
    
    # Always use active users list
    $okUsers = $activeUsers

    # Enforce bulk limits: minimum 2, maximum 100
    $okCount = $okUsers.Count
    if ($okCount -lt $MinBulk) {
        $errorMsg = "At least $MinBulk valid accounts are required for bulk termination.`n`nProvided: $($entries.Count)`nValid found: $okCount"
        if ($skips.Count -gt 0) {
            $skipDetails = ($skips | ForEach-Object { "  - '$($_.Input)': $($_.Reason)" }) -join "`n"
            $errorMsg += "`n`nAccounts not found:`n$skipDetails"
        }
        [System.Windows.Forms.MessageBox]::Show($errorMsg,"Bulk termination",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information)
        # Reset file selection UI
        $btnChoose.Text = 'Choose File...'
        $lblChosen.Text = 'No file selected'
        $btnRun.Enabled = $false
        $stLabel.Text = "Ready"
        return
    }
    
    $truncated = $false
    if ($okCount -gt $MaxBulk) {
        $okUsers = [System.Collections.ArrayList]@($okUsers | Select-Object -First $MaxBulk)
        $truncated = $true
        [System.Windows.Forms.MessageBox]::Show("You selected $okCount accounts. Only the first $MaxBulk will be loaded.","Truncated to $MaxBulk",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
    }

    # Populate grid with validated users
    foreach($it in $okUsers){
        $grid.Rows.Add($it.Sam, $it.DisplayName, $it.UPN, 'Ready') | Out-Null
        $bulkList.Add($it) | Out-Null
    }

    # Show summary
    $validCount = $grid.Rows.Count
    $summaryMsg = "Loaded $validCount user(s) ready to terminate."
    
    if ($skips.Count -gt 0) { 
        $summaryMsg += "`n`n? Skipped $($skips.Count) (not found or ambiguous):"
        foreach ($skip in $skips) {
            $summaryMsg += "`n  - $($skip.Input): $($skip.Reason)"
        }
    }
    
    if ($alreadyDisabled.Count -gt 0) { 
        $summaryMsg += "`n`n? Skipped $($alreadyDisabled.Count) (already disabled):"
        foreach ($disabled in $alreadyDisabled) {
            $summaryMsg += "`n  - $($disabled.Sam) ($($disabled.DisplayName))"
        }
    }
    
    if ($truncated) { $summaryMsg += "`n`n? Truncated to maximum $MaxBulk accounts" }
    
    [System.Windows.Forms.MessageBox]::Show($summaryMsg, "Import Complete",
        [System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null

    # Enable run button
    $btnRun.Enabled = $true
    $stLabel.Text = "Preview ready: $validCount user(s) to terminate - Click 'Run Bulk Offboarding' to proceed"
    $stLabel.ForeColor = [System.Drawing.Color]::LightGreen
    
  } catch {
    Write-Log $_ 'ERROR'
    [System.Windows.Forms.MessageBox]::Show("Failed to parse file: $($_.Exception.Message)","Error",
      [System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    $stLabel.Text = "Error"
  }
})

# Run bulk - Process users already loaded in grid (no file selection, no confirmation)
$btnRun.add_Click({
    try {
        # Check if grid has users
        if ($grid.Rows.Count -lt $MinBulk) {
            [System.Windows.Forms.MessageBox]::Show("Need at least $MinBulk valid accounts to proceed.`n`nPlease click 'Choose File...' to load users first.","No Users Loaded",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
            return
        }
        
        # Collect users from grid
        $bulkItems = @()
        foreach ($row in $grid.Rows) {
            $sam = $row.Cells[$GridColumns.SamAccountName].Value
            $displayName = $row.Cells[$GridColumns.DisplayName].Value
            $upn = $row.Cells[$GridColumns.UserPrincipalName].Value
            
            # Find user in bulkList to get telephone number
            $userInfo = $bulkList | Where-Object { $_.Sam -eq $sam } | Select-Object -First 1
            $phone = if ($userInfo) { $userInfo.Telephone } else { $null }
            
            # Build per-user auto-reply
            $name = if ($displayName) { $displayName } else { $sam }
            $auto = "Thank you for contacting $name. This message is to inform you that $name is no longer a member of the Organization." + $(if ($phone) { " For any official matters please call $phone." } else { "" }) + " Thank you."
            
            $bulkItems += [pscustomobject]@{ TermSam=$sam; AutoReply=$auto }
        }
        
        # Preflight connections: EXO required for cloud steps; Graph optional
        $skipCloud = $false
        try { if (-not (Connect-EXOIfNeeded)) { $skipCloud = $true } } catch { $skipCloud = $true }
        try { $null = Connect-GraphIfNeeded -RequiredScopes $script:GraphScopes } catch {}
        
        # Disable buttons during bulk and update status
        if ($btnTerminate -and -not $btnTerminate.IsDisposed) { $btnTerminate.Enabled = $false }
        if ($btnRun -and -not $btnRun.IsDisposed) { $btnRun.Enabled = $false }
        $stLabel.Text = "Bulk processing $($bulkItems.Count) accounts..."
        
        # Simple progress overlay
        $overlay = New-Object System.Windows.Forms.Form
        $overlay.Text = "Bulk Termination Progress"
        $overlay.StartPosition = 'CenterParent'
        $overlay.Width = 520; $overlay.Height = 200
        $overlay.FormBorderStyle = 'FixedDialog'
        $overlay.ControlBox = $false
        
        $lblStatus = New-Object System.Windows.Forms.Label
        $lblStatus.Text = "Starting bulk termination..."
        $lblStatus.Left = 16; $lblStatus.Top = 16; $lblStatus.Width = 480; $lblStatus.Height = 40
        $lblStatus.Font = New-Object System.Drawing.Font("Segoe UI",10)
        $overlay.Controls.Add($lblStatus)
        
        $lblCurrent = New-Object System.Windows.Forms.Label
        $lblCurrent.Text = "Preparing..."
        $lblCurrent.Left = 16; $lblCurrent.Top = 60; $lblCurrent.Width = 480; $lblCurrent.Height = 40
        $lblCurrent.Font = New-Object System.Drawing.Font("Segoe UI",9)
        $lblCurrent.ForeColor = [System.Drawing.Color]::FromArgb(100,100,100)
        $overlay.Controls.Add($lblCurrent)
        
        $pb = New-Object System.Windows.Forms.ProgressBar
        $pb.Left=16; $pb.Top=110; $pb.Width=480; $pb.Height=24
        $pb.Minimum=0; $pb.Maximum=$bulkItems.Count; $pb.Value=0
        $overlay.Controls.Add($pb)
        
        $lblProgress = New-Object System.Windows.Forms.Label
        $lblProgress.Text = "0 / $($bulkItems.Count)"
        $lblProgress.Left = 16; $lblProgress.Top = 140; $lblProgress.Width = 480; $lblProgress.Height = 20
        $lblProgress.Font = New-Object System.Drawing.Font("Segoe UI",9)
        $lblProgress.TextAlign = 'MiddleCenter'
        $overlay.Controls.Add($lblProgress)
        
        $overlay.Show($form) | Out-Null
        [System.Windows.Forms.Application]::DoEvents()
        
        # Process all items synchronously with UI updates
        $script:BulkResults = @{
            Total = $bulkItems.Count
            Success = 0
            Failed = 0
            Items = New-Object System.Collections.Generic.List[object]
        }
        
        # Process each item with minimal UI updates for maximum speed
        for ($i = 0; $i -lt $bulkItems.Count; $i++) {
            $currentItem = $bulkItems[$i]
            
            # Update UI every 10 accounts, or every account for small batches (< 20), or on last account
            $updateFrequency = if ($bulkItems.Count -lt 20) { 1 } else { 10 }
            $shouldUpdateUI = (($i % $updateFrequency) -eq 0) -or ($i -eq ($bulkItems.Count - 1))
            
            if ($shouldUpdateUI) {
                # Batch update all UI elements at once
                $lblStatus.Text = "Processing account $($i + 1) of $($bulkItems.Count)"
                $lblCurrent.Text = "Current: $($currentItem.TermSam)"
                $pb.Value = $i
                $lblProgress.Text = "$i / $($bulkItems.Count)"
                [System.Windows.Forms.Application]::DoEvents()
            }
            
            # Update grid status silently (no DoEvents)
            $grid.Rows[$i].Cells[$GridColumns.Status].Value = 'Processing...'
            
            # Execute the termination with BulkMode flag for optimization
            try {
                $result = Do-OffboardCore -TermSam $currentItem.TermSam -AutoReplyMessage $currentItem.AutoReply -SkipCloud:$skipCloud -BulkMode
                
                if ($result.Success) {
                    $script:BulkResults.Success++
                    $grid.Rows[$i].Cells[$GridColumns.Status].Value = 'Success'
                    $grid.Rows[$i].Cells[$GridColumns.Status].Style.ForeColor = [System.Drawing.Color]::LightGreen
                    $script:BulkResults.Items.Add([pscustomobject]@{
                        TermSam = $currentItem.TermSam
                        Success = $true
                        Error = $null
                    })
                } else {
                    $script:BulkResults.Failed++
                    $grid.Rows[$i].Cells[$GridColumns.Status].Value = 'Failed'
                    $grid.Rows[$i].Cells[$GridColumns.Status].Style.ForeColor = [System.Drawing.Color]::Red
                    $script:BulkResults.Items.Add([pscustomobject]@{
                        TermSam = $currentItem.TermSam
                        Success = $false
                        Error = $result.Error
                    })
                }
            } catch {
                $script:BulkResults.Failed++
                $errMsg = $_.Exception.Message
                $grid.Rows[$i].Cells[$GridColumns.Status].Value = 'Failed'
                $grid.Rows[$i].Cells[$GridColumns.Status].Style.ForeColor = [System.Drawing.Color]::Red
                $script:BulkResults.Items.Add([pscustomobject]@{
                    TermSam = $currentItem.TermSam
                    Success = $false
                    Error = $errMsg
                })
            }
        }
        
        # Final progress update
        $pb.Value = $bulkItems.Count
        $lblProgress.Text = "$($bulkItems.Count) / $($bulkItems.Count)"
        $lblStatus.Text = "Phase 1 Complete - AD accounts disabled!"
        $lblCurrent.Text = "Success: $($script:BulkResults.Success), Failed: $($script:BulkResults.Failed)"
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 500
        
        # Check if any accounts have mailboxes before proceeding to Phase 2
        $shouldRunPhase2 = $false
        $mailboxCheckReason = ""
        
        if ($script:BulkResults.Success -gt 0 -and -not $skipCloud) {
            $lblStatus.Text = "Checking for mailboxes..."
            $lblCurrent.Text = "Verifying Exchange mailbox existence for all accounts"
            [System.Windows.Forms.Application]::DoEvents()
            
            # Batch check mailbox existence for all successfully disabled accounts
            $accountsWithMailboxes = 0
            $accountsChecked = 0
            $upnsToCheck = @()
            
            # Collect UPNs from successful terminations
            foreach ($item in $script:BulkResults.Items) {
                if ($item.Success) {
                    $accountsChecked++
                    try {
                        $termUser = Get-ADUser -Identity $item.TermSam -Properties UserPrincipalName -ErrorAction Stop
                        if ($termUser.UserPrincipalName) {
                            $upnsToCheck += $termUser.UserPrincipalName
                        }
                    } catch {
                        # Could not retrieve user details
                    }
                }
            }
            
            # Batch mailbox check (more efficient for large operations)
            if ($upnsToCheck.Count -gt 0) {
                try {
                    # Check mailboxes in batch using filter
                    # For small batches (<10), check individually. For larger, use batch approach.
                    if ($upnsToCheck.Count -lt 10) {
                        # Individual checks for small batches
                        foreach ($upn in $upnsToCheck) {
                            try {
                                $mailbox = Get-Mailbox -Identity $upn -ErrorAction Stop
                                if ($mailbox) { $accountsWithMailboxes++ }
                            } catch {
                                # No mailbox
                            }
                        }
                    } else {
                        # Batch check for efficiency (10+ accounts)
                        try {
                            $allMailboxes = Get-Mailbox -ResultSize Unlimited -ErrorAction Stop | Where-Object { $upnsToCheck -contains $_.UserPrincipalName }
                            $accountsWithMailboxes = $allMailboxes.Count
                        } catch {
                            # Fallback to individual checks if batch fails
                            foreach ($upn in $upnsToCheck) {
                                try {
                                    $mailbox = Get-Mailbox -Identity $upn -ErrorAction Stop
                                    if ($mailbox) { $accountsWithMailboxes++ }
                                } catch { }
                            }
                        }
                    }
                } catch {
                    Write-Log "WARN: Mailbox batch check failed, skipping Phase 2: $($_.Exception.Message)"
                }
            }
            
            if ($accountsWithMailboxes -eq 0) {
                $mailboxCheckReason = "Phase 2 skipped: All $accountsChecked successfully disabled accounts exist in AD but have no Exchange mailboxes assigned. Exchange/Graph cleanup operations are not needed."
                $shouldRunPhase2 = $false
                Write-Log ("INFO: $mailboxCheckReason")
            } else {
                $mailboxCheckReason = "Phase 2 proceeding: $accountsWithMailboxes out of $accountsChecked accounts have mailboxes"
                $shouldRunPhase2 = $true
                Write-Log ("INFO: $mailboxCheckReason")
            }
        }
        
        # Phase 2: Exchange Online and Graph cleanup for successfully disabled accounts
        if ($shouldRunPhase2) {
            $lblStatus.Text = "Starting Phase 2: Exchange & Graph cleanup..."
            $lblCurrent.Text = "Processing mailbox conversions, auto-replies, and device cleanup"
            $pb.Value = 0
            $pb.Maximum = $script:BulkResults.Success
            [System.Windows.Forms.Application]::DoEvents()
            
            $phase2Count = 0
            $licensesRemoved = 0
            $mailboxesProcessed = 0
            $devicesRemoved = 0
            foreach ($item in $script:BulkResults.Items) {
                if ($item.Success) {
                    $phase2Count++
                    
                    # Update progress every 10 accounts
                    if (($phase2Count % 10) -eq 0 -or $phase2Count -eq $script:BulkResults.Success) {
                        $lblStatus.Text = "Phase 2: Processing $phase2Count of $($script:BulkResults.Success)"
                        $lblCurrent.Text = "Current: $($item.TermSam) - Mailbox & cleanup"
                        $pb.Value = $phase2Count
                        [System.Windows.Forms.Application]::DoEvents()
                    }
                    
                    # Get user details for Phase 2 operations
                    try {
                        $termUser = Get-ADUser -Identity $item.TermSam -Properties UserPrincipalName,DisplayName -ErrorAction Stop
                        $upn = $termUser.UserPrincipalName
                        
                        if ($upn) {
                            # Check if mailbox exists before Exchange operations
                            $hasMailbox = $false
                            try {
                                $mailbox = Get-Mailbox -Identity $upn -ErrorAction Stop
                                $hasMailbox = $true
                            } catch {}
                            
                            if ($hasMailbox) {
                                $mailboxesProcessed++
                                # Exchange operations
                                try {
                                    Set-Mailbox -Identity $upn -Type Shared -ErrorAction Stop
                                } catch {}
                                
                                try {
                                    Set-Mailbox -Identity $upn -HiddenFromAddressListsEnabled $true -ErrorAction Stop
                                } catch {}
                                
                                # Auto-reply from original bulk item
                                $bulkItem = $bulkItems | Where-Object { $_.TermSam -eq $item.TermSam } | Select-Object -First 1
                                if ($bulkItem -and $bulkItem.AutoReply) {
                                    try {
                                        Set-MailboxAutoReplyConfiguration -Identity $upn -AutoReplyState Enabled -InternalMessage $bulkItem.AutoReply -ExternalMessage $bulkItem.AutoReply -ErrorAction Stop
                                    } catch {}
                                }
                            }
                            
                            # Graph cleanup and license removal with retry logic
                            if (Connect-GraphIfNeeded -RequiredScopes $script:GraphScopes) {
                                # Remove Office 365 licenses with retry
                                try {
                                    $licenses = Invoke-GraphWithRetry -ScriptBlock {
                                        Get-MgUserLicenseDetail -UserId $upn -ErrorAction Stop
                                    }
                                    if ($licenses) {
                                        foreach ($license in $licenses) {
                                            try {
                                                Invoke-GraphWithRetry -ScriptBlock {
                                                    Set-MgUserLicense -UserId $upn -RemoveLicenses @($license.SkuId) -AddLicenses @() -ErrorAction Stop
                                                }
                                                $licensesRemoved++
                                            } catch {
                                                Write-Log "WARN: Failed to remove license $($license.SkuId) from $upn"
                                            }
                                        }
                                    }
                                } catch {
                                    Write-Log "WARN: Failed to get licenses for $upn"
                                }
                                
                                # Remove devices with retry
                                try {
                                    $devices = Invoke-GraphWithRetry -ScriptBlock {
                                        Get-MgUserRegisteredDevice -UserId $upn -ErrorAction Stop
                                    }
                                    foreach ($device in @($devices)) {
                                        try { 
                                            Invoke-GraphWithRetry -ScriptBlock {
                                                Remove-MgDevice -DeviceId $device.Id -ErrorAction Stop
                                            }
                                            $devicesRemoved++
                                        } catch {
                                            Write-Log "WARN: Failed to remove device $($device.Id) for $upn"
                                        }
                                    }
                                } catch {
                                    Write-Log "WARN: Failed to get devices for $upn"
                                }
                                
                                # Remove MFA methods with retry
                                try {
                                    $methods = Invoke-GraphWithRetry -ScriptBlock {
                                        Get-MgUserAuthenticationMethod -UserId $upn -ErrorAction Stop
                                    }
                                    foreach ($m in @($methods)) {
                                        try {
                                            Remove-UserAuthenticationMethod -UserId $upn -Method $m | Out-Null
                                        } catch {
                                            Write-Log "WARN: Failed to remove auth method for $upn"
                                        }
                                    }
                                } catch {
                                    Write-Log "WARN: Failed to get auth methods for $upn"
                                }
                            }
                        }
                    } catch {
                        # Phase 2 errors are non-critical, continue processing
                    }
                }
            }
            
            $lblStatus.Text = "Phase 2 Complete!"
            $lblCurrent.Text = "Mailboxes: $mailboxesProcessed | Licenses: $licensesRemoved | Devices: $devicesRemoved"
            $pb.Value = $script:BulkResults.Success
            [System.Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 500
        } elseif ($script:BulkResults.Success -gt 0 -and -not $skipCloud -and $mailboxCheckReason) {
            # Phase 2 was skipped due to no mailboxes
            $lblStatus.Text = "Phase 2 Skipped"
            $lblCurrent.Text = "No mailboxes found - Exchange/Graph cleanup not needed"
            [System.Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 1000
        }
        
        $overlay.Close(); $overlay.Dispose()
        
        # Re-enable buttons
        if ($btnTerminate -and -not $btnTerminate.IsDisposed) { $btnTerminate.Enabled = $true }
        if ($btnRun -and -not $btnRun.IsDisposed) { $btnRun.Enabled = $true }
        $stLabel.Text = "Ready"
        
        # Generate detailed CSV report
        try {
            $reportData = @()
            $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
            $completionTime = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            
            foreach ($item in $script:BulkResults.Items) {
                $reportItem = [PSCustomObject]@{
                    SamAccountName = $item.TermSam
                    AccountType = if ($item.AccountType) { $item.AccountType } else { "Unknown" }
                    Status = if ($item.Success) { "Disabled" } else { "Failed" }
                    DisabledBy = if ($item.Success) { $currentUser } else { "N/A" }
                    DisabledDate = if ($item.Success) { $completionTime } else { "N/A" }
                    ErrorMessage = if ($item.Success) { "" } else { $item.Error }
                }
                $reportData += $reportItem
            }
            
            # Auto-export to CSV - Ensure report folder exists
            if (-not (Test-Path $ReportFolder)) {
                New-Item -Path $ReportFolder -ItemType Directory -Force | Out-Null
            }
            
            $csvPath = Join-Path $ReportFolder $BulkTerminationReport
            
            # Append to existing file or create new one
            if (Test-Path $csvPath) {
                $reportData | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8 -Append
            } else {
                $reportData | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
            }
            
            # Show summary with report option
            $phaseMsg = if ($skipCloud) { 
                "Phase 1 (AD Operations)" 
            } elseif (-not $shouldRunPhase2 -and $mailboxCheckReason) {
                "Phase 1 (AD Operations)`r`n`r`n$mailboxCheckReason"
            } else { 
                "Phase 1 (AD) + Phase 2 (Exchange/Graph)" 
            }
            
            $result = [System.Windows.Forms.MessageBox]::Show(
                "Bulk termination complete ($phaseMsg).`r`n`r`nTotal: $($script:BulkResults.Total)`r`nSuccess: $($script:BulkResults.Success)`r`nFailed: $($script:BulkResults.Failed)`r`n`r`nReport saved to:`r`n$csvPath`r`n`r`nDo you want to view the detailed report?",
                "Bulk Termination Complete",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Information
            )
            
            # Show GridView if user clicks Yes
            if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
                $reportData | Out-GridView -Title "Bulk Termination Report - $completionTime" -Wait
            }
            
        } catch {
            Write-Log "ERROR: Failed to generate bulk report: $($_.Exception.Message)"
            [System.Windows.Forms.MessageBox]::Show(
                "Bulk termination complete.`r`n`r`nTotal: $($script:BulkResults.Total)`r`nSuccess: $($script:BulkResults.Success)`r`nFailed: $($script:BulkResults.Failed)",
                "Bulk Termination Complete",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            )
        }
        
        # Clear the grid and reset state to prevent re-running the same bulk file
        $grid.Rows.Clear()
        $script:bulkList.Clear()
        $btnRun.Enabled = $false
        $btnChoose.Text = 'Choose File...'
        $lblChosen.Text = 'No file selected'
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Bulk processing error: $($_.Exception.Message)","Bulk termination",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
        if ($btnTerminate -and -not $btnTerminate.IsDisposed) { $btnTerminate.Enabled = $true }
        if ($btnRun -and -not $btnRun.IsDisposed) { $btnRun.Enabled = $true }
        $stLabel.Text = "Error"
    }
})
#endregion

#region ----- Other Buttons -----
$btnResetMFA.add_Click({
   # Ensure Graph connectivity for auth method operations
    if (-not (Connect-GraphIfNeeded -RequiredScopes $script:GraphScopes)) {
        [System.Windows.Forms.MessageBox]::Show("Microsoft Graph connection is required to reset MFA.", "Graph Not Connected", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
        return
    }
    # Prompt for SAMAccountName
    $inputForm = New-Object System.Windows.Forms.Form
    $inputForm.Text = "Reset MFA - Enter SAMAccountName"
    $inputForm.Size = New-Object System.Drawing.Size(400,160)
    $inputForm.StartPosition = 'CenterParent'
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = "Enter the SAMAccountName of the user to reset MFA:"; $lbl.AutoSize = $true; $lbl.Location = New-Object System.Drawing.Point(16,16)
    $txt = New-Object System.Windows.Forms.TextBox
    $txt.Location = New-Object System.Drawing.Point(16,48); $txt.Width = 340
    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = "OK"; $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK; $btnOK.Location = New-Object System.Drawing.Point(80,90)
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "Cancel"; $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel; $btnCancel.Location = New-Object System.Drawing.Point(200,90)
    $inputForm.Controls.AddRange(@($lbl,$txt,$btnOK,$btnCancel))
    $inputForm.AcceptButton = $btnOK; $inputForm.CancelButton = $btnCancel
    $result = $inputForm.ShowDialog($form)
    if ($result -ne [System.Windows.Forms.DialogResult]::OK) { return }
    if ([string]::IsNullOrWhiteSpace($txt.Text)) {
        [System.Windows.Forms.MessageBox]::Show("Please enter a SAMAccountName.", "Input Required", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
        return
    }
    $sam = $txt.Text.Trim()
    
    # Try to find user in AD first, then Entra ID for cloud-only users
    $adUser = $null
    $isCloudOnly = $false
    
    try {
        $adUser = Get-ADUser -Identity $sam -Properties SamAccountName,DisplayName,UserPrincipalName,Enabled -ErrorAction Stop
    } catch {
        # User not found in AD - check if cloud-only
        try {
            $cloudUser = $null
            
            # Try different search strategies for cloud user
            if ($sam -like "*@*") {
                # UPN or email provided
                try {
                    $cloudUser = Get-MgUser -Filter "userPrincipalName eq '$sam' or mail eq '$sam'" -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction Stop
                } catch {
                    try {
                        $cloudUser = Get-MgUser -UserId $sam -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction SilentlyContinue
                    } catch {}
                }
            } else {
                # Try mailNickname
                try {
                    $cloudUser = Get-MgUser -Filter "mailNickname eq '$sam'" -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction Stop
                } catch {}
            }
            
            if ($cloudUser) {
                # Create pseudo-AD user object for cloud-only user
                $adUser = [PSCustomObject]@{
                    SamAccountName = if ($cloudUser.MailNickname) { $cloudUser.MailNickname } else { $sam }
                    DisplayName = $cloudUser.DisplayName
                    UserPrincipalName = $cloudUser.UserPrincipalName
                    Enabled = $cloudUser.AccountEnabled
                }
                $isCloudOnly = $true
            } else {
                [System.Windows.Forms.MessageBox]::Show("User '$sam' not found in Active Directory or Entra ID.", "User Not Found", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
                return
            }
        } catch {
            [System.Windows.Forms.MessageBox]::Show("User '$sam' not found in Active Directory or Entra ID.`n`nError: $($_.Exception.Message)", "User Not Found", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
            return
        }
    }
    
    # Check if user is already disabled
    if ($adUser.Enabled -eq $false) {
        $accountTypeMsg = if ($isCloudOnly) { "Entra ID" } else { "Active Directory" }
        [System.Windows.Forms.MessageBox]::Show("User '$sam' is already disabled in $accountTypeMsg.`n`nCannot reset MFA for disabled accounts.", "Account Disabled", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
        return
    }
    
    # Get UPN for Entra ID operations
    $upn = $adUser.UserPrincipalName
    if ([string]::IsNullOrWhiteSpace($upn)) {
        [System.Windows.Forms.MessageBox]::Show("User '$sam' does not have a UserPrincipalName.`n`nMFA reset requires a valid UPN that exists in Entra ID.", "Missing UPN", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        return
    }
    
    # Verify user exists in Entra ID (skip for cloud-only users as they're already verified)
    if (-not $isCloudOnly) {
        try {
            $entraUser = Get-MgUser -UserId $upn -ErrorAction Stop
        } catch {
            [System.Windows.Forms.MessageBox]::Show("User '$sam' ($upn) was not found in Entra ID (Azure AD).`n`nPossible reasons:`n- User not synced to cloud`n- Different UPN in Entra ID`n`nError: $($_.Exception.Message)", "User Not Found in Entra ID", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
            return
        }
    }
    
    # Confirm before proceeding
    $accountTypeLabel = if ($isCloudOnly) { "Cloud-Only" } else { "Hybrid/On-Premises" }
    $msg = "Are you sure you want to remove MFA for user:`n`nDisplay Name: $($adUser.DisplayName)`nSAM Account: $($adUser.SamAccountName)`nUPN: $upn`nAccount Type: $accountTypeLabel"
    $resp = [System.Windows.Forms.MessageBox]::Show($msg, "Confirm Remove MFA", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($resp -ne [System.Windows.Forms.DialogResult]::Yes) { return }
    # Remove user's MFA mobile device (phone methods)
    $errorMsg = $null
    try {
        $methods = Get-MgUserAuthenticationMethod -UserId $upn
        $removed = $false
        $anyError = $false
        foreach ($method in $methods) {
            $otype = $method.AdditionalProperties['@odata.type']
            try {
                if ($otype -eq '#microsoft.graph.phoneAuthenticationMethod') {
                    Remove-MgUserAuthenticationPhoneMethod -UserId $upn -PhoneAuthenticationMethodId $method.Id -ErrorAction Stop
                    $removed = $true
                } elseif ($otype -eq '#microsoft.graph.windowsHelloForBusinessAuthenticationMethod') {
                    Remove-MgUserAuthenticationWindowsHelloForBusinessMethod -UserId $upn -WindowsHelloForBusinessAuthenticationMethodId $method.Id -ErrorAction Stop
                    $removed = $true
                } elseif ($otype -eq '#microsoft.graph.microsoftAuthenticatorAuthenticationMethod') {
                    Remove-MgUserAuthenticationMicrosoftAuthenticatorMethod -UserId $upn -MicrosoftAuthenticatorAuthenticationMethodId $method.Id -ErrorAction Stop
                    $removed = $true
                }
            } catch {
                $anyError = $true
                $errorMsg = $_.Exception.Message
            }
        }

        # NEW: Explicit OATH TOTP (software OATH) removal (not always surfaced in generic list)
        try {
            $oathLeft = Get-MgUserAuthenticationSoftwareOathMethod -UserId $upn -ErrorAction Stop
            foreach ($o in $oathLeft) {
                try {
                    Remove-MgUserAuthenticationSoftwareOathMethod -UserId $upn -SoftwareOathAuthenticationMethodId $o.Id -ErrorAction Stop
                    $removed = $true
                } catch {
                    $anyError = $true
                    $errorMsg = $_.Exception.Message
                }
            }
        } catch { }  # ignore if endpoint not available / no methods

        if ($removed) {
            $infoMsg = "$($adUser.DisplayName) ($sam)'s MFA mobile devices have been removed. Do you want to require the user to re-register MFA (reset authentication)?"
            $resetResp = [System.Windows.Forms.MessageBox]::Show($infoMsg, "MFA Removed", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Information)
            if ($resetResp -eq [System.Windows.Forms.DialogResult]::Yes) {
                try {
                    try { Revoke-MgUserSignInSession -UserId $upn -ErrorAction Stop } catch {}
                    [System.Windows.Forms.MessageBox]::Show("User's sessions revoked; re-registration depends on tenant policy.", "Authentication Reset", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
                } catch {
                    [System.Windows.Forms.MessageBox]::Show("Failed to revoke sessions: $($_.Exception.Message)", "Reset Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
                }
            } else {
                [System.Windows.Forms.MessageBox]::Show("MFA removal complete. No further action taken.", "Done", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
            }
        } elseif ($anyError) {
            [System.Windows.Forms.MessageBox]::Show("Some MFA mobile devices could not be removed: $errorMsg", "Partial Failure", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
        } else {
            [System.Windows.Forms.MessageBox]::Show("No MFA mobile device found for this user or failed to remove.", "No MFA Device", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Failed to remove MFA: $($_.Exception.Message)" + $(if ($errorMsg) { "`n$errorMsg" } else { "" }), "Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
})

$btnSignOut.add_Click({
    # Ensure Graph connectivity
    if (-not (Connect-GraphIfNeeded -RequiredScopes $script:GraphScopes)) {
        [System.Windows.Forms.MessageBox]::Show("Microsoft Graph connection is required to sign out user sessions.", "Graph Not Connected", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
        return
    }
    
    # Prompt for SAMAccountName
    $inputForm = New-Object System.Windows.Forms.Form
    $inputForm.Text = "Sign Out Sessions - Enter SAMAccountName"
    $inputForm.Size = New-Object System.Drawing.Size(400,160)
    $inputForm.StartPosition = 'CenterParent'
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = "Enter the SAMAccountName of the user to sign out:"; $lbl.AutoSize = $true; $lbl.Location = New-Object System.Drawing.Point(16,16)
    $txt = New-Object System.Windows.Forms.TextBox
    $txt.Location = New-Object System.Drawing.Point(16,48); $txt.Width = 340
    $btnOK = New-Object System.Windows.Forms.Button
    $btnOK.Text = "OK"; $btnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK; $btnOK.Location = New-Object System.Drawing.Point(80,90)
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "Cancel"; $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel; $btnCancel.Location = New-Object System.Drawing.Point(200,90)
    $inputForm.Controls.AddRange(@($lbl,$txt,$btnOK,$btnCancel))
    $inputForm.AcceptButton = $btnOK; $inputForm.CancelButton = $btnCancel
    $result = $inputForm.ShowDialog($form)
    if ($result -ne [System.Windows.Forms.DialogResult]::OK) { return }
    if ([string]::IsNullOrWhiteSpace($txt.Text)) {
        [System.Windows.Forms.MessageBox]::Show("Please enter a SAMAccountName.", "Input Required", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
        return
    }
    $sam = $txt.Text.Trim()
    
    # Try to find user in AD first, then Entra ID for cloud-only users
    $adUser = $null
    $upn = $null
    $isDisabled = $false
    $isCloudOnly = $false
    
    try {
        $adUser = Get-ADUser -Identity $sam -Properties SamAccountName,DisplayName,UserPrincipalName,Enabled -ErrorAction Stop
        $upn = $adUser.UserPrincipalName
        $isDisabled = ($adUser.Enabled -eq $false)
    } catch {
        # User not found in AD - check if cloud-only
        try {
            $cloudUser = $null
            
            # Try different search strategies for cloud user
            if ($sam -like "*@*") {
                # UPN or email provided
                try {
                    $cloudUser = Get-MgUser -Filter "userPrincipalName eq '$sam' or mail eq '$sam'" -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction Stop
                } catch {
                    try {
                        $cloudUser = Get-MgUser -UserId $sam -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction SilentlyContinue
                    } catch {}
                }
            } else {
                # Try mailNickname
                try {
                    $cloudUser = Get-MgUser -Filter "mailNickname eq '$sam'" -Property Id,DisplayName,UserPrincipalName,Mail,AccountEnabled,MailNickname -ErrorAction Stop
                } catch {}
            }
            
            if ($cloudUser) {
                $upn = $cloudUser.UserPrincipalName
                $isDisabled = -not $cloudUser.AccountEnabled
                $isCloudOnly = $true
                $adUser = [PSCustomObject]@{
                    SamAccountName = if ($cloudUser.MailNickname) { $cloudUser.MailNickname } else { $sam }
                    DisplayName = $cloudUser.DisplayName
                    UserPrincipalName = $cloudUser.UserPrincipalName
                    Enabled = $cloudUser.AccountEnabled
                }
            } else {
                [System.Windows.Forms.MessageBox]::Show("User '$sam' not found in Active Directory or Entra ID.`n`nSign out sessions requires the user to exist in Entra ID.", "User Not Found", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
                return
            }
        } catch {
            [System.Windows.Forms.MessageBox]::Show("User '$sam' not found in Active Directory or Entra ID.`n`nSign out sessions requires the user to exist in Entra ID.`n`nError: $($_.Exception.Message)", "User Not Found", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
            return
        }
    }
    
    # Check if user is already disabled
    if ($isDisabled) {
        $accountTypeMsg = if ($isCloudOnly) { "Entra ID" } else { "Active Directory" }
        [System.Windows.Forms.MessageBox]::Show("User '$sam' is already disabled in $accountTypeMsg.`n`nCannot sign out sessions for disabled accounts.", "Account Disabled", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
        return
    }
    
    # Verify UPN exists
    if ([string]::IsNullOrWhiteSpace($upn)) {
        [System.Windows.Forms.MessageBox]::Show("User '$sam' does not have a UserPrincipalName.`n`nSign out sessions requires a valid UPN.", "Missing UPN", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        return
    }
    
    # Verify user exists in Entra ID (skip for cloud-only users as they're already verified)
    $entraUser = $null
    if (-not $isCloudOnly) {
        try {
            $entraUser = Get-MgUser -UserId $upn -ErrorAction Stop
        } catch {
            [System.Windows.Forms.MessageBox]::Show("User '$sam' ($upn) was not found in Entra ID.`n`nSign out sessions requires the user to exist in Entra ID.`n`nError: $($_.Exception.Message)", "User Not Found in Entra ID", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
            return
        }
    }
    
    # Get display name from Entra or AD
    $displayName = if ($entraUser.DisplayName) { $entraUser.DisplayName } elseif ($adUser -and $adUser.DisplayName) { $adUser.DisplayName } else { $sam }
    
    # Confirm before proceeding
    $msg = "Are you sure you want to sign out all M365 sessions for:`n`nDisplay Name: $displayName`nSAM Account: $sam`nUPN: $upn`n`nThis will force the user to sign in again on all devices."
    $resp = [System.Windows.Forms.MessageBox]::Show($msg, "Confirm Sign Out Sessions", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($resp -ne [System.Windows.Forms.DialogResult]::Yes) { return }
    
    # Sign out user from all sessions
    try {
        Revoke-MgUserSignInSession -UserId $upn -ErrorAction Stop
        [System.Windows.Forms.MessageBox]::Show("Successfully signed out $displayName ($sam) from all M365 sessions.`n`nThe user will need to sign in again on all devices.", "Sign Out Complete", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
    } catch {
        [System.Windows.Forms.MessageBox]::Show("Failed to sign out user sessions: $($_.Exception.Message)", "Sign Out Error", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
})

$btnHelp.add_Click({ Show-HelpDialog })

# Activate License (hook your LemonSqueezy/Cloudflare call here)
$btnActivate.add_Click({
 # Show license activation dialog
    $activationForm = New-Object System.Windows.Forms.Form
    $activationForm.Text = "Activate ADATT License"
    $activationForm.Size = New-Object System.Drawing.Size(520,220)
    $activationForm.StartPosition = 'CenterParent'
    $activationForm.FormBorderStyle = 'FixedDialog'
    $activationForm.MaximizeBox = $false
    $activationForm.MinimizeBox = $false
    
    $lblInstruction = New-Object System.Windows.Forms.Label
    $lblInstruction.Text = "Enter your ADATT license key from LemonSqueezy:"
    $lblInstruction.AutoSize = $true
    $lblInstruction.Location = New-Object System.Drawing.Point(16,20)
    $lblInstruction.Font = New-Object System.Drawing.Font("Segoe UI",10)
    
    $txtLicenseKey = New-Object System.Windows.Forms.TextBox
    $txtLicenseKey.Location = New-Object System.Drawing.Point(16,50)
    $txtLicenseKey.Width = 470
    $txtLicenseKey.Font = New-Object System.Drawing.Font("Consolas",11)
    $txtLicenseKey.CharacterCasing = 'Upper'
    
    $lblExample = New-Object System.Windows.Forms.Label
    $lblExample.Text = "Example: 631DC4E2-A5D5-448B-8284-F3513AEBAF8B"
    $lblExample.AutoSize = $true
    $lblExample.Location = New-Object System.Drawing.Point(16,80)
    $lblExample.Font = New-Object System.Drawing.Font("Segoe UI",8)
    $lblExample.ForeColor = [System.Drawing.Color]::Gray
    
    $btnActivateNow = New-Object System.Windows.Forms.Button
    $btnActivateNow.Text = "Activate"
    $btnActivateNow.Location = New-Object System.Drawing.Point(250,120)
    $btnActivateNow.Width = 100
    $btnActivateNow.Font = New-Object System.Drawing.Font("Segoe UI",10,[System.Drawing.FontStyle]::Bold)
    $btnActivateNow.DialogResult = [System.Windows.Forms.DialogResult]::OK
    
    $btnCancelActivation = New-Object System.Windows.Forms.Button
    $btnCancelActivation.Text = "Cancel"
    $btnCancelActivation.Location = New-Object System.Drawing.Point(360,120)
    $btnCancelActivation.Width = 100
    $btnCancelActivation.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    
    $activationForm.Controls.AddRange(@($lblInstruction, $txtLicenseKey, $lblExample, $btnActivateNow, $btnCancelActivation))
    $activationForm.AcceptButton = $btnActivateNow
    $activationForm.CancelButton = $btnCancelActivation
    
    $result = $activationForm.ShowDialog($form)
    
    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        $licenseKey = $txtLicenseKey.Text.Trim()
        
        if ([string]::IsNullOrWhiteSpace($licenseKey)) {
            [System.Windows.Forms.MessageBox]::Show("Please enter a license key.","License Required",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
            return
        }
        
        # Validate license key format (GUID or custom format)
        $isValidFormat = $false
        
        # Check for GUID format (e.g., 631DC4E2-A5D5-448B-8284-F3513AEBAF8B)
        $guidPattern = '^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$'
        if ($licenseKey -match $guidPattern) {
            $isValidFormat = $true
        }
        # Check for custom format with dashes and minimum length
        elseif ($licenseKey.Length -ge $LicenseKeyMinLength -and $licenseKey -match '-' -and $licenseKey -match '^[A-Za-z0-9-]+$') {
            $isValidFormat = $true
        }
        
        if (-not $isValidFormat) {
            [System.Windows.Forms.MessageBox]::Show("Invalid license key format.`n`nAccepted formats:`n� GUID: 631DC4E2-A5D5-448B-8284-F3513AEBAF8B`n� Custom: SOLO-ADMIN-2024-1111-2222-333333333333`n`nLicense keys must contain only letters, numbers, and dashes.","Invalid Format",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
            return
        }
        
        # Show progress message
        $statusMsg = "Validating license with LemonSqueezy..."
        if ($script:statusLabel -and -not $script:statusLabel.IsDisposed) {
            $script:statusLabel.Text = $statusMsg
            $form.Refresh()
        }
        
        # Hash license key for secure logging
        $activationKeyHash = [System.Security.Cryptography.SHA256]::Create().ComputeHash([System.Text.Encoding]::UTF8.GetBytes($licenseKey))
        $activationKeyHashStr = [BitConverter]::ToString($activationKeyHash).Replace('-','').Substring(0,16)
        Write-LicenseLog "User initiated manual license activation: KeyHash=$activationKeyHashStr"
        
        # Generate machine identifiers
        $currentMachineId = Get-MachineId
        $currentHardwareFingerprint = Get-HardwareFingerprint
        
        # Perform validation
        try {
            $validationResult = Invoke-LicenseValidation -LicenseKey $licenseKey -MachineId $currentMachineId -HardwareFingerprint $currentHardwareFingerprint
            
            if ($validationResult -and $validationResult.valid -eq $true) {
                if ($validationResult.status -eq 'expired') {
                    Write-LicenseLog "Activation failed: License expired"
                    [System.Windows.Forms.MessageBox]::Show("License has expired.`n`nExpiry Date: $($validationResult.expiryDate)`n`nPlease renew your license.","License Expired",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
                    return
                }
                
                if ($validationResult.status -eq 'inactive') {
                    Write-LicenseLog "Activation failed: License inactive"
                    [System.Windows.Forms.MessageBox]::Show("License is inactive.`n`nPlease contact support.","License Inactive",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
                    return
                }
                
                if ($validationResult.activationCount -gt $validationResult.maxActivations) {
                    Write-LicenseLog "Activation failed: Limit exceeded ($($validationResult.activationCount)/$($validationResult.maxActivations))"
                    [System.Windows.Forms.MessageBox]::Show("License activation limit reached.`n`nThis license is already active on $($validationResult.activationCount) machine(s) (limit: $($validationResult.maxActivations)).`n`nPlease deactivate on another machine first or contact support.","Activation Limit",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Warning)
                    return
                }
                
                # Success - save license
                Write-LicenseLog "Activation successful: Key=$($licenseKey.Substring(0,8))..., Status=$($validationResult.status)"
                
                # Get existing license or create new one
                $license = Get-LicenseFile
                if (-not $license) {
                    $license = @{
                        licensed = $false
                        licenseKey = $null
                        trialStart = $null
                        firstRun = $true
                        machineId = $null
                        hardwareFingerprint = $null
                        lastValidation = $null
                    }
                } else {
                    # Convert PSCustomObject to hashtable for mutability
                    $license = @{
                        licensed = $license.licensed
                        licenseKey = $license.licenseKey
                        trialStart = $license.trialStart
                        firstRun = $license.firstRun
                        machineId = $license.machineId
                        hardwareFingerprint = $license.hardwareFingerprint
                        lastValidation = $license.lastValidation
                    }
                }
                
                # Update license properties
                $license.licensed = $true
                $license.licenseKey = $licenseKey
                $license.machineId = $currentMachineId
                $license.hardwareFingerprint = $currentHardwareFingerprint
                $license.lastValidation = (Get-Date).ToString('o')
                if ($validationResult.expiryDate) { $license.expiryDate = $validationResult.expiryDate }
                if ($validationResult.activationCount) { $license.activationCount = $validationResult.activationCount }
                if ($validationResult.maxActivations) { $license.maxActivations = $validationResult.maxActivations }
                
                # Convert hashtable to PSCustomObject and save
                $licenseObject = [PSCustomObject]$license
                $licenseObject | ConvertTo-Json -Depth 5 | Out-File -FilePath $script:LICENSE_FILE -Encoding UTF8 -Force
                
                [System.Windows.Forms.MessageBox]::Show("License activated successfully!`n`nStatus: $($validationResult.status)`nActivations: $($validationResult.activationCount) / $($validationResult.maxActivations)`n`nPlease restart ADATT for changes to take effect.","Activation Success",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information)
                
                # Update status label
                if ($script:statusLabel -and -not $script:statusLabel.IsDisposed) {
                    $script:statusLabel.Text = "License activated! Please restart ADATT."
                }
                
                # Hide trial banner if visible
                if ($script:trialHeader -and -not $script:trialHeader.IsDisposed) {
                    $script:trialHeader.Visible = $false
                }
                
                # Hide Buy License button if visible
                if ($global:btnBuyLicense -and -not $global:btnBuyLicense.IsDisposed) {
                    $global:btnBuyLicense.Visible = $false
                }
                
                # Hide header Buy and Activate buttons
                Write-LicenseLog "Hiding header buttons: btnBuy=$($btnBuy -ne $null), btnActivate=$($btnActivate -ne $null)"
                if ($btnBuy -and -not $btnBuy.IsDisposed) {
                    $btnBuy.Visible = $false
                    $hdr.Refresh()  # Force UI update
                    Write-LicenseLog "Buy License button hidden"
                }
                if ($btnActivate -and -not $btnActivate.IsDisposed) {
                    $btnActivate.Visible = $false
                    $hdr.Refresh()  # Force UI update
                    Write-LicenseLog "Activate License button hidden"
                }
                
                # Hide Activate now button (no longer needed after activation)
                if ($script:btnActivateNow -and -not $script:btnActivateNow.IsDisposed) {
                    $script:btnActivateNow.Visible = $false
                }
                
            } else {
                # Validation failed
                $errorMsg = if ($validationResult -and $validationResult.message) { $validationResult.message } else { "Unknown error" }
                $errorStatus = if ($validationResult -and $validationResult.status) { $validationResult.status } else { "unknown" }
                Write-LicenseLog "Activation failed: Status=$errorStatus, Message=$errorMsg"
                
                # Provide helpful message based on error type
                $helpText = ""
                if ($errorMsg -like "*not found*") {
                    $helpText = "`n`nPossible reasons:`n" +
                               "? The license key was mistyped`n" +
                               "? The purchase hasn't been processed yet (wait a few minutes)`n" +
                               "? You're using a test key that wasn't properly configured`n`n" +
                               "Please verify your license key from your purchase email."
                }
                
                [System.Windows.Forms.MessageBox]::Show("License activation failed.`n`nError: $errorMsg$helpText","Activation Failed",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
                
                if ($script:statusLabel -and -not $script:statusLabel.IsDisposed) {
                    $script:statusLabel.Text = "License activation failed."
                }
            }
            
        } catch {
            $errMsg = $_.Exception.Message
            Write-LicenseLog "Activation error: $errMsg"
            [System.Windows.Forms.MessageBox]::Show("Error during license activation.`n`n$errMsg`n`nPlease check your internet connection and try again.","Activation Error",[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error)
            
            if ($script:statusLabel -and -not $script:statusLabel.IsDisposed) {
                $script:statusLabel.Text = "Activation error - check connection."
            }
        }
    }
})

# Add form closing confirmation and cleanup
$form.add_FormClosing({
    param($sender, $e)
    
    # Confirm exit
    $msg = "Are you sure you want to exit? Any unsaved changes will be lost."
    $result = [System.Windows.Forms.MessageBox]::Show(
        $msg,
        "Confirm Exit",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )
    
    if ($result -eq [System.Windows.Forms.DialogResult]::No) {
        $e.Cancel = $true
        return
    }
    
    # Clean up connections
    try {
        Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
        Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
        Write-Log "ADATT closed - connections cleaned up"
    } catch {
        Write-Log "WARN: Error during connection cleanup: $_" 'WARN'
    }
    
    # Stop transcript logging
    try {
        Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
    } catch {
        # Silently ignore transcript errors
    }
})
#endregion

#region ----- Run -----
[void][System.Windows.Forms.Application]::Run($form)
#endregion
# SIG # Begin signature block
# MIIlngYJKoZIhvcNAQcCoIIljzCCJYsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAgctq3hc9TW7/A
# oQNBpwokK6tYdyt/I5V0tsMA9b12QKCCEukwggXdMIIDxaADAgECAgh7LJvTFoAy
# mTANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQGEwJVUzEOMAwGA1UECAwFVGV4YXMx
# EDAOBgNVBAcMB0hvdXN0b24xGDAWBgNVBAoMD1NTTCBDb3Jwb3JhdGlvbjExMC8G
# A1UEAwwoU1NMLmNvbSBSb290IENlcnRpZmljYXRpb24gQXV0aG9yaXR5IFJTQTAe
# Fw0xNjAyMTIxNzM5MzlaFw00MTAyMTIxNzM5MzlaMHwxCzAJBgNVBAYTAlVTMQ4w
# DAYDVQQIDAVUZXhhczEQMA4GA1UEBwwHSG91c3RvbjEYMBYGA1UECgwPU1NMIENv
# cnBvcmF0aW9uMTEwLwYDVQQDDChTU0wuY29tIFJvb3QgQ2VydGlmaWNhdGlvbiBB
# dXRob3JpdHkgUlNBMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA+Q/d
# oyt9y9Aq/uxnhabnLhu6d+Hj9a+k7PpKXZHEV0drGHdrdvL9k+Q9D8IWngtmw1aU
# nheDhc5W7/IW/QBi9SIJVOhlF05BueBPRpeqG8i4bmJeabFf2yoCfvxsyvNB2O3Q
# 6Pw/YUjtsAMUHRAOSxngu07shmX/NvNeZwILnYZVYf16OO3+4hkAt2+hUGJ1dDyg
# +sglkrRueiLH+B6h47LdkTGrKx0E/6VKBDfphaQzK/3i1lU0fBmkSmjHsqjTt8qh
# k4jrwZe8jPkd2SKEJHTHBD1qqSmTzOu4W+H+XyWqNFjIwSNUnRuYEcM4nH49hmyl
# D0CGfAL0XAJPKMuucZ8POsgz/hElNer8usVgPdl8GNWyqdN1eANyIso6wx/vLOUu
# qfqeLLZRRv2vA9bqYGjqhRY2a4XpHsCz3cQk3IAqgUFtlD7I4MmBQQCeXr9/xQiY
# ohgsQkCz+W84J0tOgPQ9gUfgiHzqHM61dVxRLhwrfxpyKOcAtdF0xtfkn60Hk7ZT
# NTX8N+TD9l0WviFz3pIK+KBjaryWkmo++LxlVZve9Q2JJgT8JRqmJWnLwm3KfOJZ
# X5es6+8uyLzXG1k8K8zyGciTaydjGc/86Sb4ynGbf5P+NGeETpnr/LN4CTNwumam
# du0bc+sapQ3EIhMglFYKTixsTrH9z5wJuqIz7YcCAwEAAaNjMGEwHQYDVR0OBBYE
# FN0ECQei9Xp9UlMSkpXuOIAlDaZZMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgw
# FoAU3QQJB6L1en1SUxKSle44gCUNplkwDgYDVR0PAQH/BAQDAgGGMA0GCSqGSIb3
# DQEBCwUAA4ICAQAgGBGUKfsmnRweHnBh8ZVyk3EkrWiTWI4yrxuzcAP8JSt0hZA9
# eGr0uYullzu1GJG7Hqf5QFuR+VWZrx4R0Fwdp2bjsZQHDDI5puobsHnYHZxwROOK
# 3cT5lR+KOEM/AYWlR6c9RrK85SJo93uc2Cw+CiHILTOsv8WBmTF0wXVxxb6x8CNF
# 9J1r/BljnaO8BMYYCyW7U4kPs4BQ3kXuRH+rlHhkmNP2KN2H2HBldPsOuRPrpw9h
# qTKWzN677WNMGLupQPegVG4giHF1GOp6tDRy4CMnd1y2kOqGJUCr7zMPy5+CvqIg
# +/a1LRrmwoWxdA/7yGUCpFIBR91JIsG/2OtrrH7e7GMzFbcjCI/GD41BWt2OxbmP
# 5UU/eNu60htAsf5xTT/ggaK6XrTsFeCT3QgffuFVmQsh3pOeCvvmo0m9NjD+53ey
# oHWXtS2BiBdlIPfakACfyVLMMso1fPU9D9gr1/UmbMkGNJYW6nBZGjJ5eQu2iH8P
# Ukg9v2zYokQu0U63cljTiROV/kSr+NeLG26cvCygW9VqAK9fN+HV+hALmJyG5yaP
# zvDsbopXC4DjTrLAoGNhkLpVaDd0araS25+hhiK2ZScO7LafQmDkZ8K12kELxNOL
# YRu8+h+RK9dEB166KazZxenvU0ha64DxKFghzbAGVfsnP1OQcKkEHlcnuTCCBnIw
# ggRaoAMCAQICCGQzUdPHOJ8IMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVT
# MQ4wDAYDVQQIDAVUZXhhczEQMA4GA1UEBwwHSG91c3RvbjEYMBYGA1UECgwPU1NM
# IENvcnBvcmF0aW9uMTEwLwYDVQQDDChTU0wuY29tIFJvb3QgQ2VydGlmaWNhdGlv
# biBBdXRob3JpdHkgUlNBMB4XDTE2MDYyNDIwNDQzMFoXDTMxMDYyNDIwNDQzMFow
# eDELMAkGA1UEBhMCVVMxDjAMBgNVBAgMBVRleGFzMRAwDgYDVQQHDAdIb3VzdG9u
# MREwDwYDVQQKDAhTU0wgQ29ycDE0MDIGA1UEAwwrU1NMLmNvbSBDb2RlIFNpZ25p
# bmcgSW50ZXJtZWRpYXRlIENBIFJTQSBSMTCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBAJ+DE3OqsMZtIcvbi3qHdNBx3I6Xcprku4g0tN2AA8YvRaR0mr8e
# D1Dqnm1485/6USapPZ3RspRXPvs5iRuRK1bvZ8vmC+MOOYzGNfSMPd0l6QGsF0J9
# WBZA3PnVKEQdlWQwYTpk8pfXc0x9eyMCbfN161U9b6otxK++dKxd/mq2/OpceekP
# Q5y1UgUP7z6xsY/QSa2m40IZVD/zLw6hy3z+E/kjOdolHLg+AEo6bzIwN2Qex651
# B9hV0hjJDoq8o1zwfAqnhYHCDq+PmVzTYCW8g1ppHCUTzXL165yAm9wsZ8TdyQmY
# 1XPrxCGj5TKOPi9SmMZgN2SMsm9KVHIYzCeH+s11omMhTLU9ZP0rpptVryZMYLS5
# XP6rQ72t0BNmUB8L0omm/9eABvHDEQIzM2EX91Yfji87aOcV8XdWSimeA9rCKyZh
# MlugVuVJKY02p/XHUqJWAyAvOHiAvfYGrkE0y5RFvZvHiRgfC7r/qa5qQJkT3e9Q
# 3wG68gTW0DHfNDheV1vIOB5W1KxIpu3/+bjBO+3CJL5EYKd3zdU9mFm0Q+qqYH3N
# wuUv8ev11CDVlzRuXQRrBRHS05KMCSdE7U81MUZ+dBkFYuyJ4+ojcJjk0S/UihMY
# RpNl5Vhz00w9J3oiP8P4o1W3+eaHguxFHsVuOnyxTrmraPebY9WRQbypAgMBAAGj
# gfswgfgwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTdBAkHovV6fVJTEpKV
# 7jiAJQ2mWTAwBggrBgEFBQcBAQQkMCIwIAYIKwYBBQUHMAGGFGh0dHA6Ly9vY3Nw
# cy5zc2wuY29tMBEGA1UdIAQKMAgwBgYEVR0gADATBgNVHSUEDDAKBggrBgEFBQcD
# AzA7BgNVHR8ENDAyMDCgLqAshipodHRwOi8vY3Jscy5zc2wuY29tL3NzbC5jb20t
# cnNhLVJvb3RDQS5jcmwwHQYDVR0OBBYEFFTC/hCVAJPNavXnwNfZsku4jwzjMA4G
# A1UdDwEB/wQEAwIBhjANBgkqhkiG9w0BAQsFAAOCAgEA9Q8mh3CvmaLK9dbJ8I1m
# PTmC04gj2IK/j1SEJ7bTgwfXnieJTYSOVNEg7mBD21dCPMewlfa+zOqjPY5PBsYr
# WYZ/63MbyuVAJuA9b8z2vXHGzX0OIEA51gXSr5QIv3/CUbcrtXuDIfBj2uWc4Wku
# dR1Oy2Ee9aUz3wKdFdntaZNXukZFLoC8Zb7nEj7eR/+QnBCt9laypNT61vwuvJch
# s3aD0pH6BlDRsYAogP7brQ9n7fh93NlwW3q6aLWzSmYXj+fw51fdaf68XuHVjJ8T
# u5WaFft5K4XVbT5nR24bB1z7VEUPFhEuEcOwvLVuHDNXlB7+QjRGjjFQTtszV5X6
# OOTmEturWC5Ft9kiyvRaR0ksKOhPjEI8ZGjp5kOsGZGpxxOCX/xxCje3nVB7PF33
# olKCNeS159MKb2v+jfmk19UdS+d9Ygj42desmUnbtYRBFC72LmCXU0ua/vGIenS6
# nnXp4NqnycwsO3tMCnjPlPc2YLaDPIpUy04NaCqUEXUmFOogN8zreRd2VXhxbeJJ
# ODM32+RsWccjYua8zi5US/1eAyrI3R5LcUTQdT4xYmWLKabtJOF6HYQ0f6QXfLSs
# fT81WMvDvxrdn1RWbUXlU/OIiisxo8o+UNEANOwnCMNnxlzoaL/PLhZluDxm/zuy
# lauajZ3MlPDteFB/7GRHo50wggaOMIIEdqADAgECAhA0kIB3QzUm96iOdKO/QvJs
# MA0GCSqGSIb3DQEBCwUAMHgxCzAJBgNVBAYTAlVTMQ4wDAYDVQQIDAVUZXhhczEQ
# MA4GA1UEBwwHSG91c3RvbjERMA8GA1UECgwIU1NMIENvcnAxNDAyBgNVBAMMK1NT
# TC5jb20gQ29kZSBTaWduaW5nIEludGVybWVkaWF0ZSBDQSBSU0EgUjEwHhcNMjUx
# MjMxMTUxNDMxWhcNMjcxMjMwMTUxNDMxWjB1MQswCQYDVQQGEwJVUzEQMA4GA1UE
# CAwHRmxvcmlkYTEQMA4GA1UEBwwHVGFtYXJhYzEVMBMGA1UECgwMVU5JRk9TRUMg
# TExDMRQwEgYDVQQLDAtJVCBTZWN1cml0eTEVMBMGA1UEAwwMVU5JRk9TRUMgTExD
# MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAt9KTvmKWgNY4xIzXosQa
# MXAA3RdsUdmrFdv6lgtybIk/93+C4EqHkRg+0jx3ybsNXmzSEFrZugZIYGi8s39l
# pq/HV2ME6wLkhF+veDTisE7XJ5AJoCYAgQoQGi+6qkmUK2Q8D8iF50+/MIcjUrPS
# CzF4oVwLWmmB1r8hBGEkIEGOJL/JZCGA/RjF67bGNorACBNdy5igkszgXafzZ7TJ
# noVLD6Hf3D43KcyNarB4EMdsdheF45IkOsHZ9yqY0LP26Y/ECUCYyll37G/S3idi
# CC5b7Ak2Nu8dnVmX6hBL9DKkq9XPgbFvxG53ePR+1+50K3N8TDA4D/pNxUx6nWcT
# JkuL3j/LyIATwwaZLFIQ+IrOqrtuE3ILfF0+XSVF9a45Bz/+Dl6LS1pcCNaz92cI
# jmVH8dJVWvW/f+iQOSsd2YWJQDZziuhdTX/o6Ns4hOQsGez5hjaUwsZmls2KjsSd
# T10Fw/y0FwCXXwMIoJpGSlBaWflG6pASU8Ode6pzlcnbAgMBAAGjggGVMIIBkTAM
# BgNVHRMBAf8EAjAAMB8GA1UdIwQYMBaAFFTC/hCVAJPNavXnwNfZsku4jwzjMHoG
# CCsGAQUFBwEBBG4wbDBIBggrBgEFBQcwAoY8aHR0cDovL2NlcnQuc3NsLmNvbS9T
# U0xjb20tU3ViQ0EtQ29kZVNpZ25pbmctUlNBLTQwOTYtUjEuY2VyMCAGCCsGAQUF
# BzABhhRodHRwOi8vb2NzcHMuc3NsLmNvbTBRBgNVHSAESjBIMAgGBmeBDAEEATA8
# BgwrBgEEAYKpMAEDAwEwLDAqBggrBgEFBQcCARYeaHR0cHM6Ly93d3cuc3NsLmNv
# bS9yZXBvc2l0b3J5MBMGA1UdJQQMMAoGCCsGAQUFBwMDME0GA1UdHwRGMEQwQqBA
# oD6GPGh0dHA6Ly9jcmxzLnNzbC5jb20vU1NMY29tLVN1YkNBLUNvZGVTaWduaW5n
# LVJTQS00MDk2LVIxLmNybDAdBgNVHQ4EFgQUkTZdJRTsRGRLXwXZrN/0K2HJcT0w
# DgYDVR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4ICAQBVoPtmBjb2MJA0shMt
# NA1d7SmuKM3PUbDlL+tS0IbDdQ4PVJIbhfiuYwSz/N9utGUILAdp1vWzKn/opEpa
# Yzarp9JoSK0CtODZcfTINrxz59fsumIycqR7YaE0v9mdWxyzNixzbz+bVUERr0GZ
# MYKC7rr7YA48INDEyd87M3CIbcIdT3bTxmU4Sn65HeXAsEh66heZ+IGhVYSwvtzy
# lvEqvg79l6/JGdPcFqdYiWQTfOYJlEFgu06CgPUGwExmSc037EMg368U4+8wne8y
# bNXtgu5fIAAOG1DhTda3682CJBQpHPe7Tcc6/NbM6eVjMjOfnLMMeQHAWBdxfwk1
# kS28lezRdHGJib2upS5H7xo5O4KTpJl1x8kk6+xpG8w2LncUoLJFC2oIYZUrIJmr
# NYkovbJrJWc8cAQ4eFoByUN2jUDZ3DRAF7dEorrqrdpl53p34LS+CzLa/nmICAaQ
# wfFSCTb3TC/uxE+8jWqd3D/UMHU6zz5T/K7lNr4SVTRWAyE48BREjFLGOzXFz+hu
# 9S1xmHX/mJd5lOJxyGxSXVVkui/raIEKuIBw+Rqk9gDCxha+UzPHEzidIMNN7yCE
# zR5X+93JynQtdiI8X/e/HJep3+p9ytxmSlPetEilrAqrhX9VdXG2U8uBMeLvPULA
# LDEBgr52O0s5EZZos9esdjwF8TGCEgswghIHAgEBMIGMMHgxCzAJBgNVBAYTAlVT
# MQ4wDAYDVQQIDAVUZXhhczEQMA4GA1UEBwwHSG91c3RvbjERMA8GA1UECgwIU1NM
# IENvcnAxNDAyBgNVBAMMK1NTTC5jb20gQ29kZSBTaWduaW5nIEludGVybWVkaWF0
# ZSBDQSBSU0EgUjECEDSQgHdDNSb3qI50o79C8mwwDQYJYIZIAWUDBAIBBQCgga8w
# FAYKKwYBBAGCNwIBDDEGMAShAoAAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC0GCSqGSIb3DQEJNDEgMB4w
# DQYJYIZIAWUDBAIBBQChDQYJKoZIhvcNAQELBQAwLwYJKoZIhvcNAQkEMSIEIM8Q
# tADdd+Y5A83TmY4iQTeU9CTzGx0euWRSn3xLTEcwMA0GCSqGSIb3DQEBCwUABIIB
# gA2QN1S/bUkCJGCTsOeY8xtOP8ALlDyL97O5t2J47RZe/+cQg/mv0f4Qh7lHiQVv
# VdTYXk4L6iQbb7pDlk99YEpF86c6KiXYDIctscE9g87wZW1QjbuQbOQ5xj5I/mQL
# LzaTSgZU7qExzY3teRqj0cRgc9zbkXaE4S3ezBhBUn+eIfByf124Ujj8iv4wHmQi
# 4+4dk2GlHU+x2O2OU3UUhKTz04r8ptucmn7jHT90EAGHevl1gXdZytgJBL3C19sZ
# P+hf8zurjKE6niqinrg8uTQYTrHrytd2z7W/LeAFaNiylIufCTrPuo7TXn8G2/hb
# +h4644m4ZQTNMyIaOHLn0pSGkrHnfbuCHdJe9sEBrgUAGnvtzAy/iRBt0dKbfh03
# lszonwMVzg5ciZPkeklTnEb4NVugEJcERQivEMJ/vrH1Tr7eyYPxQkFnTk9rbbLh
# 8Y5s+KeT14T7k25fChRP+gVemJYympxlCada9kvFFTOA/3zh5/IifBhnvGJALg5i
# pKGCDx0wgg8ZBgorBgEEAYI3AwMBMYIPCTCCDwUGCSqGSIb3DQEHAqCCDvYwgg7y
# AgEDMQ0wCwYJYIZIAWUDBAIBMH8GCyqGSIb3DQEJEAEEoHAEbjBsAgEBBgwrBgEE
# AYKpMAEDBgEwMTANBglghkgBZQMEAgEFAAQgLAGj8iVHUvUkQjvZAAoQa5fjNWhW
# rvHDrqX7IAkgkeMCCGz+0+i5pZCPGA8yMDI2MDEwNDIzNDIyMlowAwIBAQIGAZuL
# Y/QboIIMADCCBPwwggLkoAMCAQICEFparOgaNW60YoaNV33gPccwDQYJKoZIhvcN
# AQELBQAwczELMAkGA1UEBhMCVVMxDjAMBgNVBAgMBVRleGFzMRAwDgYDVQQHDAdI
# b3VzdG9uMREwDwYDVQQKDAhTU0wgQ29ycDEvMC0GA1UEAwwmU1NMLmNvbSBUaW1l
# c3RhbXBpbmcgSXNzdWluZyBSU0EgQ0EgUjEwHhcNMjQwMjE5MTYxODE5WhcNMzQw
# MjE2MTYxODE4WjBuMQswCQYDVQQGEwJVUzEOMAwGA1UECAwFVGV4YXMxEDAOBgNV
# BAcMB0hvdXN0b24xETAPBgNVBAoMCFNTTCBDb3JwMSowKAYDVQQDDCFTU0wuY29t
# IFRpbWVzdGFtcGluZyBVbml0IDIwMjQgRTEwWTATBgcqhkjOPQIBBggqhkjOPQMB
# BwNCAASnYXL1MOl6xIMUlgVC49zonduUbdkyb0piy2i8t3JlQEwA74cjK8g9mRC8
# GH1cAAVMIr8M2HdZpVgkV1LXBLB8o4IBWjCCAVYwHwYDVR0jBBgwFoAUDJ0QJY6a
# pxuZh0PPCH7hvYGQ9M8wUQYIKwYBBQUHAQEERTBDMEEGCCsGAQUFBzAChjVodHRw
# Oi8vY2VydC5zc2wuY29tL1NTTC5jb20tdGltZVN0YW1waW5nLUktUlNBLVIxLmNl
# cjBRBgNVHSAESjBIMDwGDCsGAQQBgqkwAQMGATAsMCoGCCsGAQUFBwIBFh5odHRw
# czovL3d3dy5zc2wuY29tL3JlcG9zaXRvcnkwCAYGZ4EMAQQCMBYGA1UdJQEB/wQM
# MAoGCCsGAQUFBwMIMEYGA1UdHwQ/MD0wO6A5oDeGNWh0dHA6Ly9jcmxzLnNzbC5j
# b20vU1NMLmNvbS10aW1lU3RhbXBpbmctSS1SU0EtUjEuY3JsMB0GA1UdDgQWBBRQ
# TySs77U+YxMjCZIm7Lo6luRdIjAOBgNVHQ8BAf8EBAMCB4AwDQYJKoZIhvcNAQEL
# BQADggIBAJigjwMAkbyrxGRBf0Ih4r+rbCB57lTuwViC6nH2fZSciMogpqSzrSeV
# Z2eIb5vhj9rT7jqWXZn02Fncs4YTrA1QyxJW36yjC4jl5/bsFCaWuXzGXt2Y6Ifp
# //A3Z0sNTMWTTBobmceM3sqnovdX9ToRFP+29r5yQnPcgRTI2PvrVSqLxY9Eyk9/
# 0cviM3W29YBl080ENblRcu3Y8RsfzRtVT/2snuDocRxvRYmd0TPaMgIj2xII651Q
# nPp1hiq9xU0AyovLzbsi5wlR5Ip4i/i8+x+HwYJNety5cYtdWJ7uQP6YaZtW/jNo
# Hp76qNftq/IlSx6xEYBRjFBxHSq2fzhUQ5oBawk2OsZ2j0wOf7q7AqjCt6t/+fbm
# WjrAWYWZGj/RLjltqdFPBpIKqdhjVIxaGgzVhaE/xHKBg4k4DfFZkBYJ9BWuP93T
# m+paWBDwXI7Fg3alGsboErWPWlvwMAmpeJUjeKLZY26JPLt9ZWceTVWuIyujerqb
# 5IMmeqLJm5iFq/Qy4YPGyPiolw5w1k9OeO4ErmS2FKvk1ejvw4SWR+S1VyWnktY4
# 42WaoStxBCCVWZdMWFeB+EpL8uoQNq1MhSt/sIUjUudkyZLIbMVQjj7b6gPXnD6m
# S8FgWiCAhuM1a/hgA+6o1sJWizHdmcpYDhyNzorf9KVRE6iR7rcmMIIG/DCCBOSg
# AwIBAgIQbVIYcIfoI02FYADQgI+TVjANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQG
# EwJVUzEOMAwGA1UECAwFVGV4YXMxEDAOBgNVBAcMB0hvdXN0b24xGDAWBgNVBAoM
# D1NTTCBDb3Jwb3JhdGlvbjExMC8GA1UEAwwoU1NMLmNvbSBSb290IENlcnRpZmlj
# YXRpb24gQXV0aG9yaXR5IFJTQTAeFw0xOTExMTMxODUwMDVaFw0zNDExMTIxODUw
# MDVaMHMxCzAJBgNVBAYTAlVTMQ4wDAYDVQQIDAVUZXhhczEQMA4GA1UEBwwHSG91
# c3RvbjERMA8GA1UECgwIU1NMIENvcnAxLzAtBgNVBAMMJlNTTC5jb20gVGltZXN0
# YW1waW5nIElzc3VpbmcgUlNBIENBIFIxMIICIjANBgkqhkiG9w0BAQEFAAOCAg8A
# MIICCgKCAgEArlEQE9L5PCCgIIXeyVAcZMnh/cXpNP8KfzFI6HJaxV6oYf3xh/dR
# XPu35tDBwhOwPsJjoqgY/Tg6yQGBqt65t94wpx0rAgTVgEGMqGri6vCI6rEtSZVy
# 9vagzTDHcGfFDc0Eu71mTAyeNCUhjaYTBkyANqp9m6IRrYEXOKdd/eREsqVDmhry
# d7dBTS9wbipm+mHLTHEFBdrKqKDM3fPYdBOro3bwQ6OmcDZ1qMY+2Jn1o0l4N9wO
# RrmPcpuEGTOThFYKPHm8/wfoMocgizTYYeDG/+MbwkwjFZjWKwb4hoHT2WK8pvGW
# /OE0Apkrl9CZSy2ulitWjuqpcCEm2/W1RofOunpCm5Qv10T9tIALtQo73GHIlIDU
# 6xhYPH/ACYEDzgnNfwgnWiUmMISaUnYXijp0IBEoDZmGT4RTguiCmjAFF5OVNbY0
# 3BQoBb7wK17SuGswFlDjtWN33ZXSAS+i45My1AmCTZBV6obAVXDzLgdJ1A1ryyXz
# 4prLYyfJReEuhAsVp5VouzhJVcE57dRrUanmPcnb7xi57VPhXnCuw26hw1Hd+ulK
# 3jJEgbc3rwHPWqqGT541TI7xaldaWDo85k4lR2bQHPNGwHxXuSy3yczyOg57Tcqq
# G6cE3r0KR6jwzfaqjTvN695GsPAPY/h2YksNgF+XBnUD9JBtL4c34AcCAwEAAaOC
# AYEwggF9MBIGA1UdEwEB/wQIMAYBAf8CAQAwHwYDVR0jBBgwFoAU3QQJB6L1en1S
# UxKSle44gCUNplkwgYMGCCsGAQUFBwEBBHcwdTBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5zc2wuY29tL3JlcG9zaXRvcnkvU1NMY29tUm9vdENlcnRpZmljYXRpb25B
# dXRob3JpdHlSU0EuY3J0MCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcHMuc3NsLmNv
# bTA/BgNVHSAEODA2MDQGBFUdIAAwLDAqBggrBgEFBQcCARYeaHR0cHM6Ly93d3cu
# c3NsLmNvbS9yZXBvc2l0b3J5MBMGA1UdJQQMMAoGCCsGAQUFBwMIMDsGA1UdHwQ0
# MDIwMKAuoCyGKmh0dHA6Ly9jcmxzLnNzbC5jb20vc3NsLmNvbS1yc2EtUm9vdENB
# LmNybDAdBgNVHQ4EFgQUDJ0QJY6apxuZh0PPCH7hvYGQ9M8wDgYDVR0PAQH/BAQD
# AgGGMA0GCSqGSIb3DQEBCwUAA4ICAQCSGXUNplpCzxkH2fL8lPrAm/AV6USWWi9x
# M91Q5RN7mZN3D8T7cm1Xy7qmnItFukgdtiUzLbQokDJyFTrF1pyLgGw/2hU3FJEy
# wSN8crPsBGo812lyWFgAg0uOwUYw7WJQ1teICycX/Fug0KB94xwxhsvJBiRTpQyh
# u/2Kyu1Bnx7QQBA1XupcmfhbQrK5O3Q/yIi//kN0OkhQEiS0NlyPPYoRboHWC++w
# ogzV6yNjBbKUBrMFxABqR7mkA0x1Kfy3Ud08qyLC5Z86C7JFBrMBfyhfPpKVlIii
# TQuKz1rTa8ZW12ERoHRHcfEjI1EwwpZXXK5J5RcW6h7FZq/cZE9kLRZhvnRKtb+X
# 7CCtLx2h61ozDJmifYvuKhiUg9LLWH0Or9D3XU+xKRsRnfOuwHWuhWch8G7kEmnT
# G9CtD9Dgtq+68KgVHtAWjKk2ui1s1iLYAYxnDm13jMZm0KpRM9mLQHBK5Gb4dFgA
# QwxOFPBslf99hXWgLyYE33vTIi9p0gYqGHv4OZh1ElgGsvyKdUUJkAr5hfbDX6pY
# ScJI8v9VNYm1JEyFAV9x4MpskL6kE2Sy8rOqS9rQnVnIyPWLi8N9K4GZvPit/Oy+
# 8nFL6q5kN2SZbox5d69YYFe+rN1sDD4CpNWwBBTI/q0V4pkgvhL99IV2XasjHZf4
# peSrHdL4RjGCAlcwggJTAgEBMIGHMHMxCzAJBgNVBAYTAlVTMQ4wDAYDVQQIDAVU
# ZXhhczEQMA4GA1UEBwwHSG91c3RvbjERMA8GA1UECgwIU1NMIENvcnAxLzAtBgNV
# BAMMJlNTTC5jb20gVGltZXN0YW1waW5nIElzc3VpbmcgUlNBIENBIFIxAhBaWqzo
# GjVutGKGjVd94D3HMAsGCWCGSAFlAwQCAaCCAWEwGgYJKoZIhvcNAQkDMQ0GCyqG
# SIb3DQEJEAEEMBwGCSqGSIb3DQEJBTEPFw0yNjAxMDQyMzQyMjJaMCgGCSqGSIb3
# DQEJNDEbMBkwCwYJYIZIAWUDBAIBoQoGCCqGSM49BAMCMC8GCSqGSIb3DQEJBDEi
# BCBmzH4lsJVo4BSa33epTqc1WGDE/MilrA6irfV8rjkKkTCByQYLKoZIhvcNAQkQ
# Ai8xgbkwgbYwgbMwgbAEIJ1xf43CN2Wqzl5KsOH1ddeaF9Qc7tj9r+8D/T29iUfn
# MIGLMHekdTBzMQswCQYDVQQGEwJVUzEOMAwGA1UECAwFVGV4YXMxEDAOBgNVBAcM
# B0hvdXN0b24xETAPBgNVBAoMCFNTTCBDb3JwMS8wLQYDVQQDDCZTU0wuY29tIFRp
# bWVzdGFtcGluZyBJc3N1aW5nIFJTQSBDQSBSMQIQWlqs6Bo1brRiho1XfeA9xzAK
# BggqhkjOPQQDAgRGMEQCIHxPWsBJL1GQ4YlotackTEM23Exqycrq8JjP7+O4hbfT
# AiApv1VBFTb1x23Mzpj+nXcaHF65nCEtV2YOU95tnTj8iA==
# SIG # End signature block
